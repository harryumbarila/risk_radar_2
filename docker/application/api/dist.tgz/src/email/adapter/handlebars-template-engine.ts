import { TemplateEngineInterface } from '@/email/template-engine.interface';
import * as fs from 'fs';
import * as path from 'path';
import * as Handlebars from 'handlebars';

export class HandlebarsTemplateEngine implements TemplateEngineInterface {
    render(template: string, context: Record<string, string>): string {
        const templatePath = path.resolve(__dirname, '../..', 'assets/templates/emails', `${template}.hbs`);
        const templateSource = fs.readFileSync(templatePath, 'utf8');
        const handlebarTemplate = Handlebars.compile(templateSource);

        return handlebarTemplate(context);
    }
}
