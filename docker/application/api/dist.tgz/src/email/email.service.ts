import { EmailClientInterface } from '@/shared/webservice/email/email.client.interface';
import { TemplateEngineInterface } from '@/email/template-engine.interface';
import { EmailTemplateMessage } from '@/email/email-template-message';
import { EmailMessage } from '@/shared/webservice/email/email-message';
import { EmailResponse } from '@/shared/webservice/email/email-response';
import { Inject } from '@nestjs/common';
import { EmailClientSymbolToken } from '@/shared/webservice/email/email.constants';
import { TemplateEngineSymbolToken } from '@/email/template-engine.contants';

export class EmailService {
    constructor(
        @Inject(EmailClientSymbolToken) private readonly emailClient: EmailClientInterface,
        @Inject(TemplateEngineSymbolToken) private readonly templateEngine: TemplateEngineInterface,
    ) {}

    async send(dto: EmailTemplateMessage): Promise<EmailResponse> {
        const html = this.templateEngine.render(dto.template, dto.context);

        const emailMessage: EmailMessage = {
            to: dto.to,
            subject: dto.subject,
            body: html,
            context: dto.context,
            attachments: dto.attachments,
        };

        return this.emailClient.send(emailMessage);
    }
}
