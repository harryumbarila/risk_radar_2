export interface TemplateEngineInterface {
    render(template: string, data: Record<string, string>): string;
}
