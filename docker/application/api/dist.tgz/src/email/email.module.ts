import { Module } from '@nestjs/common';
import { EmailService } from '@/email/email.service';
import { EmailClientSymbolToken } from '@/shared/webservice/email/email.constants';
import { AwsSesClient } from '@/shared/webservice/email/adapter/aws-ses.client';
import { TemplateEngineSymbolToken } from '@/email/template-engine.contants';
import { HandlebarsTemplateEngine } from '@/email/adapter/handlebars-template-engine';
import { SmtpClient } from '@/shared/webservice/email/adapter/smtp.client';

@Module({
    providers: [
        EmailService,
        {
            provide: EmailClientSymbolToken,
            useClass: !process.env.EMAIL_CLIENT_PROVIDER || process.env.EMAIL_CLIENT_PROVIDER === 'aws' ? AwsSesClient : SmtpClient,
        },
        {
            provide: TemplateEngineSymbolToken,
            useClass: HandlebarsTemplateEngine,
        },
    ],
    exports: [EmailService],
})
export class EmailModule {}
