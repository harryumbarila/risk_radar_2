import { EmailMessage } from '@/shared/webservice/email/email-message';
import { OmitType, PartialType } from '@nestjs/swagger';

type templateType = 'sign-contract' | 'contract-signed';

export class EmailTemplateMessage extends PartialType(OmitType(EmailMessage, ['body'] as const)) {
    template: templateType;

    constructor(to: string, subject: string, template: templateType, context: { [key: string]: string }, attachments?: any) {
        super();

        this.to = to;
        this.template = template;
        this.subject = subject;
        this.attachments = attachments;
        this.context = context;
    }
}
