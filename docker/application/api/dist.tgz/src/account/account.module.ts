import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Account } from '@/shared/model/account.entity';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { AccountController } from '@/account/account.controller';
import { RegisterAccountUseCase } from '@/account/register-account.usecase';
import { ApiKeysFactory } from '@/shared/model/account/api-keys.factory';
import { AorakiPaymentsClient, AorakiPaymentsSymbolToken } from '@/shared/webservice/aoraki-payments/aoraki-payments.client';

@Module({
    imports: [TypeOrmModule.forFeature([Account])],
    providers: [
        AccountRepository,
        RegisterAccountUseCase,
        ApiKeysFactory,
        {
            provide: AorakiPaymentsSymbolToken,
            useClass: AorakiPaymentsClient,
        },
    ],
    controllers: [AccountController],
})
export class AccountModule {}
