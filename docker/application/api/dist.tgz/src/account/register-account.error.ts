import { DomainError } from '@/shared/model/domain.error';

type ErrorName = 'ERROR' | 'COULD_NOT_REGISTER_ACCOUNT_ALREADY_EXISTS';

export class RegisterAccountError extends DomainError<ErrorName> {}

export class AccountAlreadyExists extends RegisterAccountError {
    public static create(email: string): RegisterAccountError {
        return new this({
            name: 'COULD_NOT_REGISTER_ACCOUNT_ALREADY_EXISTS',
            message: `Could not register account ${email}, please contact CS`,
        });
    }
}
