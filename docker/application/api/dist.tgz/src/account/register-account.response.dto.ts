import { ApiProperty } from '@nestjs/swagger';

export class RegisterAccountResponseDto {
    @ApiProperty()
    sid: string;
    @ApiProperty()
    publishable_key: string;
    @ApiProperty()
    secret_key: string;
    @ApiProperty({ description: 'Authorization Basic Auth - combined signature base64 account_sid:account_secret' })
    account_secret: string;

    constructor(sid: string, publishableKey: string, secretKey: string) {
        this.sid = sid;
        this.secret_key = secretKey;
        this.publishable_key = publishableKey;

        const str = `${this.sid}:${this.secret_key}`;
        this.account_secret = Buffer.from(str).toString('base64');
    }
}
