import { ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Body, Controller, Post, HttpCode, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { RegisterAccountResponseDto } from '@/account/register-account.response.dto';
import { RegisterAccountRequestDto } from '@/account/register-account.request.dto';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { RegisterAccountUseCase } from '@/account/register-account.usecase';
import { INTERNAL_API_HEADER_NAME, InternalApiKeyGuard } from '@/shared/auth/guard/internal-api-key.guard';

@ApiTags('internal-accounts')
@Controller('/v1/internal/accounts')
export class AccountController {
    constructor(private readonly registerAccountUseCase: RegisterAccountUseCase) {}

    @ApiResponse({
        status: HttpStatus.CREATED,
        description: 'Register root account',
        type: RegisterAccountResponseDto,
    })
    @ApiHeader({
        name: INTERNAL_API_HEADER_NAME,
        description: 'Required internal api key',
        required: true,
    })
    @Post()
    @HttpCode(HttpStatus.CREATED)
    @Public()
    @UseGuards(InternalApiKeyGuard)
    async register(@Body() dto: RegisterAccountRequestDto): Promise<RegisterAccountResponseDto> {
        return this.registerAccountUseCase.handle(dto);
    }
}
