import { IsEmail, IsOptional, IsString, MaxLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ACCOUNT_MAX_EMAIL_LENGTH, ACCOUNT_MAX_NAME_LENGTH } from '@/shared/model/account/account.const';

export class RegisterAccountRequestDto {
    @ApiProperty()
    @IsEmail()
    @MaxLength(ACCOUNT_MAX_EMAIL_LENGTH)
    private readonly email: string;

    @ApiPropertyOptional()
    @IsOptional()
    @IsString()
    @MaxLength(ACCOUNT_MAX_NAME_LENGTH)
    readonly name?: string;

    getEmail(): string {
        return this.email.toLowerCase();
    }
}
