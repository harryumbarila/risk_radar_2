import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { RegisterAccountRequestDto } from '@/account/register-account.request.dto';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { Account } from '@/shared/model/account.entity';
import { RegisterAccountResponseDto } from '@/account/register-account.response.dto';
import { ApiKeysFactory } from '@/shared/model/account/api-keys.factory';
import { AorakiPaymentsClientInterface, AorakiPaymentsSymbolToken } from '@/shared/webservice/aoraki-payments/aoraki-payments.client';
import { AccountAlreadyExists } from '@/account/register-account.error';

@Injectable()
export class RegisterAccountUseCase implements UseCaseInterface {
    constructor(
        @InjectPinoLogger(RegisterAccountUseCase.name) private readonly logger: PinoLogger,
        private readonly apiKeysFactory: ApiKeysFactory,
        private readonly accountRepository: AccountRepository,
        @Inject(AorakiPaymentsSymbolToken) private readonly aorakiPaymentsClient: AorakiPaymentsClientInterface,
    ) {}

    async handle(dto: RegisterAccountRequestDto): Promise<RegisterAccountResponseDto> {
        this.logger.info('Registering account', dto);

        const account: Account | null = await this.accountRepository.findOneBy({ email: dto.getEmail() });

        if (account) {
            this.logger.error(`Account for email ${dto.getEmail()} already exists`);
            throw AccountAlreadyExists.create(dto.getEmail());
        }

        const apiKeysRaw = await this.apiKeysFactory.create();
        const savedAccount = await this.accountRepository.save(Account.create(apiKeysRaw.apiKeys, dto.getEmail(), dto.name));

        /**
         * Forward creating account to payments
         */
        await this.aorakiPaymentsClient.createAccount(savedAccount.sid.toString(), apiKeysRaw.rawSecretKey);

        return new RegisterAccountResponseDto(savedAccount.sid.toString(), savedAccount.apiKeys.publishableKey, apiKeysRaw.rawSecretKey);
    }
}
