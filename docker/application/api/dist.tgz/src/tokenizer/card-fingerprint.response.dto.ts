import { ApiProperty } from '@nestjs/swagger';

export class CardFingerprintResponseDto {
    @ApiProperty({ description: 'Card fingerprint' })
    fingerprint: string | null;

    @ApiProperty({ description: 'Card Funding' })
    funding: string;

    constructor(fingerprint: string | null, funding: string) {
        this.fingerprint = fingerprint;
        this.funding = funding;
    }
}
