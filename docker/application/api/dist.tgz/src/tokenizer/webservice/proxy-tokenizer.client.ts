import { ConfigService } from '@nestjs/config';
import { TokenizerConfig } from '@/tokenizer/proxy-tokenizer.controller';
import { ForwardPostLookupResponseDto } from '@/tokenizer/webservice/forward-post-lookup.response.dto';
import { ForwardPostLookupRequestDto } from '@/tokenizer/webservice/forward-post-lookup.request.dto';
import axios, { AxiosResponse } from 'axios';
import { Injectable } from '@nestjs/common';

@Injectable()
export class ProxyTokenizerClient {
    constructor(private configService: ConfigService<TokenizerConfig>) {}

    async forwardPostLookup(
        path: string,
        authorization: string,
        body: ForwardPostLookupRequestDto,
    ): Promise<AxiosResponse<ForwardPostLookupResponseDto>> {
        const lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/api/lookup/${path}`;

        return axios.post<ForwardPostLookupResponseDto>(lookupUrl, body, { headers: { Authorization: authorization } });
    }
}
