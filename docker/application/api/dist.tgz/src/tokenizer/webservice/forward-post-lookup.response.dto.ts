export interface ForwardPostLookupResponseDto {
    status: string;
    msg: string;
    data: {
        bin: string;
        card_brand: string;
        issuing_bank: string;
        card_type: string;
        card_level_generic: string;
        country: string;
        is_surchargeable: boolean;
        payment_method_type: string;
    };
}
