export interface ForwardPostLookupRequestDto {
    type: string;
    type_id: string; // UUID
    bin: string;
}
