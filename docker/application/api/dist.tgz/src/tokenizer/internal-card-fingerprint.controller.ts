import { ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Controller, Get, HttpCode, HttpStatus, NotFoundException, Param, UseGuards } from '@nestjs/common';
import { INTERNAL_API_HEADER_NAME, InternalApiKeyGuard } from '@/shared/auth/guard/internal-api-key.guard';
import { Public } from '@/shared/auth/decorator/public.decorator';

import { CardFingerprintResponseDto } from '@/tokenizer/card-fingerprint.response.dto';
import { CardFingerprintRepository } from '@/shared/model/card-fingerprint/card-fingerprint.repository';
import { FundingType } from '@/shared/model/card-fingerprint/funding-type.enum';

@ApiTags('internal-card-fingerprint')
@Controller(['/api/v1/internal/card_fingerprint', '/v1/internal/card_fingerprint'])
export class InternalCardFingerprintController {
    constructor(private readonly cardFingerprintRepository: CardFingerprintRepository) {}

    @ApiResponse({
        status: HttpStatus.OK,
        description: 'Get card fingerprint',
        type: CardFingerprintResponseDto,
    })
    @ApiHeader({
        name: INTERNAL_API_HEADER_NAME,
        description: 'Required internal api key',
        required: true,
    })
    @Get('search_by_token/:token')
    @HttpCode(HttpStatus.OK)
    @Public()
    @UseGuards(InternalApiKeyGuard)
    async index(@Param('token') token: string): Promise<CardFingerprintResponseDto> {
        const cardFingerprint = await this.cardFingerprintRepository.findOneBy({ token: token });

        if (!cardFingerprint) {
            return new CardFingerprintResponseDto(null, FundingType.UNKNOWN);
        }

        return new CardFingerprintResponseDto(cardFingerprint.fingerprint, cardFingerprint.funding);
    }
}
