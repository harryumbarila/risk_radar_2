import { Injectable } from '@nestjs/common';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { CardFingerprintRepository } from '@/shared/model/card-fingerprint/card-fingerprint.repository';
import { CardFingerprintEncoder } from '@/shared/model/card-fingerprint/card-fingerprint.encoder';
import { CardFingerprint } from '@/shared/model/card-fingerprint.entity';
import { FundingType } from '@/shared/model/card-fingerprint/funding-type.enum';

@Injectable()
export class CreateFingerprintUseCase implements UseCaseInterface {
    constructor(
        private readonly cardFingerprintRepository: CardFingerprintRepository,
        private readonly cardFingerprintEncoder: CardFingerprintEncoder,
    ) {}

    async handle(card: string, token: string, funding: string): Promise<void> {
        const encoded = this.cardFingerprintEncoder.encode(card);

        await this.cardFingerprintRepository.save(CardFingerprint.create(token, encoded, FundingType.parse(funding)));
    }
}
