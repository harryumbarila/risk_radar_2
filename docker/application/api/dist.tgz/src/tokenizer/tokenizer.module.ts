import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CardFingerprint } from '@/shared/model/card-fingerprint.entity';
import { CardFingerprintRepository } from '@/shared/model/card-fingerprint/card-fingerprint.repository';
import { ProxyTokenizerController } from '@/tokenizer/proxy-tokenizer.controller';
import { InternalCardFingerprintController } from '@/tokenizer/internal-card-fingerprint.controller';
import { CreateFingerprintUseCase } from '@/tokenizer/usecase/create-fingerprint.usecase';
import { CardFingerprintEncoder } from '@/shared/model/card-fingerprint/card-fingerprint.encoder';
import { ProxyTokenizerClient } from '@/tokenizer/webservice/proxy-tokenizer.client';

const repositories = [CardFingerprintRepository];
const useCases = [CreateFingerprintUseCase];
const entities = [CardFingerprint];

@Module({
    controllers: [ProxyTokenizerController, InternalCardFingerprintController],
    providers: [...repositories, ...useCases, CardFingerprintEncoder, ProxyTokenizerClient],
    imports: [TypeOrmModule.forFeature(entities)],
})
export class TokenizerModule {}
