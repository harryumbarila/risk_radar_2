import { Controller, Get, Res, HttpException, HttpStatus, All, Req, Post } from '@nestjs/common';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { Request, Response } from 'express';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { CreateFingerprintUseCase } from '@/tokenizer/usecase/create-fingerprint.usecase';
import { ApiExcludeController, ApiTags } from '@nestjs/swagger';
import { ProxyTokenizerClient } from '@/tokenizer/webservice/proxy-tokenizer.client';
import util from 'util';
import { exec } from 'child_process';

export interface TokenizerConfig {
    TOKENIZER_PROXY_URL: string;
}

interface PaymentMethod {
    card: {
        entry_type: string;
        number: string;
        expiration_date: string;
        cvc: string;
    };
}

interface TokenizerRequest {
    tsid: string;
    payment_method: PaymentMethod;
}

@ApiExcludeController()
@ApiTags('internal-proxy')
@Controller(['api', ''])
export class ProxyTokenizerController {
    constructor(
        private configService: ConfigService<TokenizerConfig>,
        private createFingerprintUseCase: CreateFingerprintUseCase,
        private proxyTokenizerClient: ProxyTokenizerClient,
        @InjectPinoLogger(ProxyTokenizerController.name) private readonly logger: PinoLogger,
    ) {}

    // eslint-disable-next-line @darraghor/nestjs-typed/api-method-should-specify-api-response
    @Public()
    @All('lookup/*')
    async proxyLookup(@Req() req: Request, @Res() res: Response) {
        try {
            // Construct the URL for the external API
            const lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/api/lookup/${req.params[0]}`;

            let response;

            if (req.method === 'GET') {
                // Handle GET request, forward query parameters
                response = await axios.get(lookupUrl, { params: req.query, headers: { Authorization: req.headers.authorization } });
            } else if (req.method === 'POST') {
                // Handle POST request, forward body
                response = await this.proxyTokenizerClient.forwardPostLookup(req.params[0], req.headers.authorization, req.body);
            } else {
                throw new HttpException('Method Not Allowed', HttpStatus.METHOD_NOT_ALLOWED);
            }

            // Forward the response back to the client
            res.status(response.status).json(response.data);
        } catch (error) {
            console.log(error);
            this.logger.error(error.message);
            // Handle error and send appropriate response
            if (error.response) {
                res.status(error.response.status).json(error.response.data);
            } else {
                throw new HttpException('Failed request', HttpStatus.BAD_GATEWAY);
            }
        }
    }

    // eslint-disable-next-line @darraghor/nestjs-typed/api-method-should-specify-api-response
    @Public()
    @Post('tokenizer')
    async proxyTokenizer(@Req() req: Request, @Res() res: Response) {
        try {
            // Construct the URL for the external API
            const lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/api/tokenizer`;

            const raw = JSON.stringify(req.body);

            const curlCommand = `
curl -v -4 --tls-max 1.3 --tlsv1.3 --no-sessionid -s '${this.configService.get('TOKENIZER_PROXY_URL')}/api/tokenizer' \
  -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'content-type: application/json' \
  -H 'referer: ${this.configService.get('TOKENIZER_PROXY_URL')}/api/tokenizer/${req.headers.authorization}' \
  -H 'authorization: ${req.headers.authorization}' \
  --data-raw '${raw}'
`;
            //const execPromise = util.promisify(child_process.exec);

            function execPromise(command) {
                return new Promise((resolve, reject) => {
                    exec(command, (error, stdout, stderr) => {
                        if (error) {
                            reject(error); // Reject the Promise on error
                            return;
                        }
                        resolve({ stdout, stderr }); // Resolve with the output
                    });
                });
            }

            let token: string = '';
            let data: string = '';

            try {
                // @ts-ignore
                const { stdout, stderr } = await execPromise(curlCommand);

                if (stderr) {
                    console.error(`Curl stderr: ${stderr}`);
                }

                console.log(`Curl output: ${stdout}`);
                const parsed = JSON.parse(stdout);
                token = parsed.data.token;
                data = parsed;
            } catch (error) {
                console.error(`Error executing curl command: ${error.message}`);
            }

            //
            // exec(curlCommand, (error, stdout, stderr) => {
            //     if (error) {
            //         console.error(`Error executing curl command: ${error.message}`);
            //         return;
            //     }
            //     if (stderr) {
            //         console.error(`Curl stderr: ${stderr}`);
            //         return;
            //     }
            //     console.log(`Curl output: ${stdout}`);
            // });
            //
            // axios.interceptors.request.use((request) => {
            //     console.log('Starting Request', JSON.stringify(request, null, 2));
            //     return request;
            // });
            //
            // let response = await axios.post(lookupUrl, JSON.stringify(req.body), {
            //     headers: {
            //         Authorization: req.headers.authorization,
            //         'Content-Type': 'application/json',
            //         Accept: 'application/json, text/plain, */*',
            //         'User-Agent':
            //             'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            //         referer: 'https://app.fluidpay.com/api/tokenizer/' + req.headers.authorization,
            //     },
            //     transformRequest: [(data) => data], // Disabling Axios's transformation
            //     timeout: 0,
            // });

            // Format and validate req.body
            const requestBody: TokenizerRequest = req.body;

            // Get funding
            const postLookupResponse = await this.proxyTokenizerClient.forwardPostLookup(
                'bin/' + req.headers.authorization,
                req.headers.authorization,
                {
                    type: 'tokenizer',
                    type_id: requestBody.tsid,
                    bin: requestBody.payment_method.card.number,
                },
            );

            // Create fingerprint
            await this.createFingerprintUseCase.handle(
                requestBody.payment_method.card.number,
                token,
                postLookupResponse.data.data.card_type,
            );

            // Forward the response back to the client
            res.status(200).json(data);
        } catch (error) {
            this.logger.error(error);
            // Handle error and send appropriate response
            if (error.response) {
                res.status(error.response.status).json(error.response.data);
            } else {
                throw new HttpException('Failed request', HttpStatus.BAD_GATEWAY);
            }
        }
    }

    // Handle GET requests to /v1/tokenizer/pub_xxx
    // eslint-disable-next-line @darraghor/nestjs-typed/api-method-should-specify-api-response
    @Public()
    @Get('tokenizer/*')
    async proxyGetTokenizer(@Req() req: Request, @Res() res: Response) {
        try {
            const resource = req.params[0];
            let lookupUrl;

            if (resource.startsWith('pub_') || resource.startsWith('services')) {
                lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/api/tokenizer/${req.params[0]}`;
            } else {
                // static resource
                res.setHeader('Content-Type', 'text/javascript; charset=utf-8');

                if (resource == 'tokenizer-form.css') {
                    res.setHeader('Content-Type', 'text/css; charset=utf-8');
                }

                lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/tokenizer/${req.params[0]}`;
            }

            // Copy headers and remove host
            const headers = { ...req.headers };
            delete headers.host;

            let response = await axios.get(lookupUrl, { params: req.query, headers: headers });

            let htmlContent = response.data;

            res.setHeader(
                'Content-Security-Policy',
                "default-src * data: blob: filesystem:; script-src * 'unsafe-inline' 'unsafe-eval' data: blob: filesystem:; style-src * 'unsafe-inline' data: blob: filesystem:;",
            );
            res.removeHeader('X-Frame-Options');
            // Forward the modified HTML response back to the client
            res.status(response.status).send(htmlContent);
        } catch (error) {
            console.log(error);
            this.logger.error(error.message);
            // Handle error and send appropriate response
            if (error.response) {
                res.status(error.response.status).send(error.response.data);
            } else {
                throw new HttpException('Failed request', HttpStatus.BAD_GATEWAY);
            }
        }
    }

    // Handle GET requests to /v1/tokenizer/pub_xxx
    // eslint-disable-next-line @darraghor/nestjs-typed/api-method-should-specify-api-response
    @Public()
    @All('cdn-cgi/*')
    async cdnCgi(@Req() req: Request, @Res() res: Response) {
        try {
            const resource = req.params[0];
            const lookupUrl = `${this.configService.get('TOKENIZER_PROXY_URL')}/cdn-cgi/${req.params[0]}`;
            let response;

            if (req.method === 'GET') {
                response = await axios.get(lookupUrl, { params: req.query });
            } else {
                response = await axios.post(lookupUrl, { params: req.query });
            }

            let htmlContent = response.data;
            res.setHeader('Content-Type', 'text/javascript; charset=utf-8');
            res.setHeader('Content-Security-Policy', "default-src * data: blob: 'unsafe-inline' 'unsafe-eval'; frame-ancestors *");
            // Forward the modified HTML response back to the client
            res.status(response.status).send(htmlContent);
        } catch (error) {
            this.logger.error(error.message);
            // Handle error and send appropriate response
            if (error.response) {
                res.status(error.response.status).send(error.response.data);
            } else {
                throw new HttpException('Failed request', HttpStatus.BAD_GATEWAY);
            }
        }
    }
}
