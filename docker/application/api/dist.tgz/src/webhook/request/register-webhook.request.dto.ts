import { IsEnum, IsNotEmpty, IsOptional, IsUrl, MaxLength, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export enum WebhookScopeEnum {
    merchant = 'merchant',
    charge = 'charge',
    payouts = 'payouts',
}

export class RegisterWebhookRequestDto {
    @ApiProperty()
    @IsNotEmpty()
    @MaxLength(2000)
    @IsUrl()
    readonly url: string;

    @ApiProperty()
    @IsNotEmpty()
    @MaxLength(16)
    readonly label: string;

    @ApiProperty({ type: 'enum', enum: WebhookScopeEnum, isArray: true })
    @IsOptional()
    @IsEnum(WebhookScopeEnum, { each: true })
    readonly scope: WebhookScopeEnum[];
}
