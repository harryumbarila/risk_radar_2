import { Account } from '@/shared/model/account.entity';
import { WebhookEventTypeEnum } from '@/webhook/webhook.entity';
import { WebhookLogObjectType } from '@/webhook/webhook-log.entity';

export interface WebhookEventObject {
    /**
     * @todo rename to data
     */
    payload?: any;
    object: WebhookLogObjectType;
    id: string;
}

export interface WebhookData {
    created_at: string;
    account_sid: string;
    event_type: WebhookEventTypeEnum;
    object: WebhookEventObject;
    api_version: string;
    /**
     * Information on the API request that triggers the event.
     */
    request: {
        /**
         * ID of the API request that caused the event. If null, the event was automatic.
         */
        id: string | null;
    };
}

export class WebhookEvent {
    public readonly createdAt: Date;

    constructor(
        public readonly account: Account,
        public readonly eventType: WebhookEventTypeEnum,
        public readonly object: WebhookEventObject,
        public readonly requestId: string | null = null,
        public readonly apiVersion: string = '2024-07-06',
    ) {
        this.createdAt = new Date();
    }

    toData(): WebhookData {
        return {
            created_at: new Date().toISOString(),
            account_sid: this.account.sid.toString(),
            event_type: this.eventType,
            object: this.object,
            api_version: this.apiVersion,
            request: {
                id: this.requestId,
            },
        };
    }
}
