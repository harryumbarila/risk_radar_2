import { RegisterWebhookResponseDto } from '@/webhook/response/register-webhook.response.dto';

export class UpdateWebhookResponseDto extends RegisterWebhookResponseDto {}
