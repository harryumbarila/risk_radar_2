import { ApiProperty } from '@nestjs/swagger';
import { Webhook } from '@/webhook/webhook.entity';

export class RegisterWebhookResponseDto {
    @ApiProperty()
    id: string;
    @ApiProperty()
    url: string;
    @ApiProperty()
    label: string;
    @ApiProperty()
    secret: string;
    @ApiProperty()
    created_at: Date;
    @ApiProperty()
    events: any;

    static createFromWebhook(webhook: Webhook): RegisterWebhookResponseDto {
        const dto = new RegisterWebhookResponseDto();
        dto.id = webhook.sid.toString();
        dto.url = webhook.url;
        dto.label = webhook.label;
        dto.events = webhook.events;
        dto.secret = webhook.secret;
        dto.created_at = webhook.createdAt;

        return dto;
    }
}
