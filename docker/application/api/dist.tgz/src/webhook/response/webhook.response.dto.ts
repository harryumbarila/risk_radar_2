import { RegisterWebhookResponseDto } from '@/webhook/response/register-webhook.response.dto';

export class WebhookResponseDto extends RegisterWebhookResponseDto {}
