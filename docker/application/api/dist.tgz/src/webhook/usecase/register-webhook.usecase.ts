import { Injectable } from '@nestjs/common';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { Webhook, WebhookEventTypeEnum } from '../webhook.entity';
import { RegisterWebhookRequestDto, WebhookScopeEnum } from '../request/register-webhook.request.dto';
import { PartialType } from '@nestjs/swagger';
import { InjectRepository } from '@nestjs/typeorm';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import { Account } from '@/shared/model/account.entity';

class RegisterWebhookUseCaseInput extends PartialType(RegisterWebhookRequestDto) {}

@Injectable()
export class RegisterWebhookUseCase implements UseCaseInterface {
    constructor(
        @InjectRepository(Webhook) private readonly webhookRepository: WebhookRepository,
        @InjectPinoLogger(RegisterWebhookUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(account: Account, input: RegisterWebhookUseCaseInput): Promise<Webhook> {
        const events = [];

        if (input.scope.includes(WebhookScopeEnum.merchant)) {
            events.push(
                ...[
                    WebhookEventTypeEnum.MerchantVerificationApproved,
                    WebhookEventTypeEnum.MerchantVerificationFailed,
                    WebhookEventTypeEnum.MerchantUpdated,
                    WebhookEventTypeEnum.MerchantProcessing,
                    WebhookEventTypeEnum.MerchantCreated,
                ],
            );
        }

        const webhook = Webhook.createFromParams(TypeSidFactory.createFromPrefix('webhook'), input.url, events, input.label);
        webhook.account = Promise.resolve(account);

        return await this.webhookRepository.save(webhook);
    }
}
