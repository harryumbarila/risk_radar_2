import { Injectable, NotFoundException } from '@nestjs/common';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { Webhook } from '../webhook.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { WebhookLog } from '@/webhook/webhook-log.entity';
import { WebhookLogRepository } from '@/webhook/webhook-log.repository';

@Injectable()
export class DeleteWebhookUseCase implements UseCaseInterface {
    constructor(
        @InjectRepository(Webhook) private readonly webhookRepository: WebhookRepository,
        @InjectRepository(WebhookLog) private readonly webhookLogRepository: WebhookLogRepository,
    ) {}

    async handle(sid: string): Promise<Webhook> {
        const webhook = await this.webhookRepository.findOneBy({ sid: sid });

        if (!webhook) {
            throw new NotFoundException(`Webhook does not exist for sid ${sid}`);
        }

        await this.webhookLogRepository.delete({ webhook: { id: webhook.id } });

        return this.webhookRepository.remove(webhook);
    }
}
