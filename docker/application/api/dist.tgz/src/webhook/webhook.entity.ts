import {
    BeforeInsert,
    Column,
    Entity,
    Index,
    JoinColumn,
    ManyToOne,
    PrimaryColumn,
} from 'typeorm';
import { SidColumn } from '@/shared/typeorm/decorator/sid-column.decorator';
import { TypeSid } from '@/shared/model/type-sid';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import * as crypto from 'crypto';
import { Account } from '@/shared/model/account.entity';
import { BaseEntity } from '@/shared/model/base.entity';

/**
 * Define a http header to be included in the webhook call back to the endpoint provided in the webhook
 */
export interface WebhookHttpHeader {
    [header: string]: string;
}

export enum WebhookEventTypeEnum {
    MerchantCreated = 'merchant.created',
    MerchantUpdated = 'merchant.updated',
    MerchantVerificationFailed = 'merchant.verification_failed',
    MerchantVerificationApproved = 'merchant.verification_approved',
    MerchantProcessing = 'merchant.processing',
    ChargeSucceeded = 'charge.succeeded',
    ChargeFailed = 'charge.failed',
}

@Entity('webhooks')
@Index(['label'])
export class Webhook extends BaseEntity {
    public static readonly SECRET_LENGTH: number = 36;

    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('webhook')
    sid: TypeSid<'webhook'>;

    @Column()
    label: string;

    /**
     * Allow to turn on/off the webhook in case we need to temporarily disable it
     */
    @Column({ name: 'is_active' })
    isActive: boolean;

    @Column({ type: 'jsonb', default: null })
    events: WebhookEventTypeEnum[];

    /**
     * The url to send the data to
     */
    @Column()
    url: string;

    /**
     * Webhook signing secret
     */
    @Column()
    secret: string;

    @Column({ type: 'jsonb', name: 'http_headers', nullable: true })
    httpHeaders?: WebhookHttpHeader;

    @ManyToOne(() => Account, (account) => account.webhooks, { lazy: true })
    @JoinColumn({ name: 'account_id' })
    account: Promise<Account>;

    static createFromParams(sid: TypeSid<'webhook'>, url: string, events: WebhookEventTypeEnum[], label: string, secret?: string): Webhook {
        const webhook = new Webhook();

        webhook.sid = sid;
        webhook.isActive = true;
        webhook.secret = secret ?? Webhook.generateSecret();
        webhook.label = label;
        webhook.events = events;
        webhook.url = url;
        webhook.id = sid.toUUID();

        return webhook;
    }

    static generateSecret(): string {
        return (
            'whs_' +
            crypto
                .randomBytes(Math.ceil(Webhook.SECRET_LENGTH / 2))
                .toString('hex')
                .slice(0, Webhook.SECRET_LENGTH)
        );
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('webhook');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
