import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import axios from 'axios';
import { WebhookLog } from '@/webhook/webhook-log.entity';

@Injectable()
export class WebhookForwardClient {
    constructor(@InjectPinoLogger(WebhookForwardClient.name) private readonly logger: PinoLogger) {}
    async sendWebhook(webhookLog: WebhookLog) {
        // Add retry
        try {
            const res = await axios.post(
                webhookLog.webhook.url,
                {
                    id: webhookLog.eventSid.toString(),
                    object: webhookLog.object,
                    api_version: webhookLog.apiVersion,
                    created: webhookLog.createdAt.toLocaleString(),
                    type: webhookLog.eventType,
                    data: webhookLog.payload,
                },
                {
                    headers: {
                        ...webhookLog.webhook.httpHeaders,
                    },
                    timeout: 8000,
                },
            );

            return {
                status: res.status,
                data: res.data,
            };
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }
}
