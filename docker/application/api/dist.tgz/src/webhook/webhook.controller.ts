import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBasicAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { RegisterWebhookRequestDto } from '@/webhook/request/register-webhook.request.dto';
import { RegisterWebhookUseCase } from '@/webhook/usecase/register-webhook.usecase';
import { Webhook } from '@/webhook/webhook.entity';
import { RegisterWebhookResponseDto } from '@/webhook/response/register-webhook.response.dto';
import { CurrentAccount } from '@/shared/auth/decorator/current-account.decorator';
import { Account } from '@/shared/model/account.entity';
import { AccountSecretAuthorizationBasicGuard } from '@/shared/auth/guard/account-secret-authorization-basic.guard';
import { DeleteWebhookUseCase } from '@/webhook/usecase/delete-webhook.usecase';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { WebhookResponseDto } from '@/webhook/response/webhook.response.dto';

@ApiTags('Webhooks')
@Controller('/v1/webhooks')
export class WebhookController {
    constructor(
        private readonly webhookRepository: WebhookRepository,
        private readonly registerWebhookUseCase: RegisterWebhookUseCase,
        private readonly deleteWebhookUseCase: DeleteWebhookUseCase,
    ) {}

    @ApiResponse({
        status: 200,
        description: 'Create webhook',
        type: RegisterWebhookResponseDto,
    })
    @ApiOperation({ operationId: 'Create webhook' })
    @ApiBasicAuth('account-secret')
    @Public()
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @HttpCode(HttpStatus.OK)
    @Post()
    async create(@Body() dto: RegisterWebhookRequestDto, @CurrentAccount() account: Account): Promise<RegisterWebhookResponseDto> {
        const webhook: Webhook = await this.registerWebhookUseCase.handle(account, dto);
        return RegisterWebhookResponseDto.createFromWebhook(webhook);
    }

    @ApiResponse({
        status: 204,
        description: 'Delete webhook',
    })
    @ApiOperation({ operationId: 'Delete webhook' })
    @Public()
    @ApiBasicAuth('account-secret')
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @HttpCode(HttpStatus.NO_CONTENT)
    @Delete('/:webhook_id')
    async delete(@Param('webhook_id') id: string, @CurrentAccount() account: Account) {
        return this.deleteWebhookUseCase.handle(id);
    }

    @ApiResponse({
        status: 200,
        description: 'Get webhooks',
        type: WebhookResponseDto,
        isArray: true,
    })
    @ApiOperation({ operationId: 'Get webhook' })
    @Public()
    @ApiBasicAuth('account-secret')
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @HttpCode(HttpStatus.OK)
    @Get()
    async get(@CurrentAccount() account: Account): Promise<WebhookResponseDto[]> {
        const webhooks = await this.webhookRepository.findByAccountId(account.id);
        return webhooks.map((value) => WebhookResponseDto.createFromWebhook(value));
    }
}
