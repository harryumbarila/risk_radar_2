import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { WebhookLog } from '@/webhook/webhook-log.entity';

@Injectable()
export class WebhookLogRepository extends Repository<WebhookLog> {
    constructor(dataSource: DataSource) {
        super(WebhookLog, dataSource.createEntityManager());
    }
}
