import { ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Body, Controller, HttpCode, HttpStatus, Param, Post, UseGuards } from '@nestjs/common';
import { INTERNAL_API_HEADER_NAME, InternalApiKeyGuard } from '@/shared/auth/guard/internal-api-key.guard';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { WebhookService } from '@/webhook/webhook.service';
import { AccountRepository } from '@/shared/model/account/account.repository';

/**
 * Temporary solution of forwarding webhooks from aoraki
 */
@Controller('/v1/internal/webhooks')
@ApiTags('internal-webhooks')
export class InternalWebhookForwardController {
    constructor(
        private readonly webhookService: WebhookService,
        private readonly accountRepository: AccountRepository,
    ) {}
    @ApiResponse({
        status: HttpStatus.OK,
        description: 'Forward webhook to external service',
    })
    @ApiHeader({
        name: INTERNAL_API_HEADER_NAME,
        description: 'Required internal api key',
        required: true,
    })
    @Post(':account_id')
    @HttpCode(HttpStatus.OK)
    @Public()
    @UseGuards(InternalApiKeyGuard)
    async forward(@Param('account_id') accountId: string, @Body() dto: any): Promise<void> {
        const account = await this.accountRepository.findOneBy({ sid: accountId });
        return this.webhookService.forwardCharge(account, dto);
    }
}
