import { Queue } from 'bullmq';
import { WebhookEvent } from '@/webhook/webhook-payload';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { WebhookLog } from '@/webhook/webhook-log.entity';
import { WebhookLogRepository } from '@/webhook/webhook-log.repository';
import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';

export type QueueType = 'onboarding' | 'payments';

@Injectable()
export class WebhookQueueService {
    constructor(
        @InjectQueue('onboarding') private onboardingQueue: Queue,
        @InjectQueue('payments') private paymentsQueue: Queue,
        private readonly webhookRepository: WebhookRepository,
        private readonly webhookLogRepository: WebhookLogRepository,
        @InjectPinoLogger(WebhookQueueService.name) private readonly logger: PinoLogger,
    ) {}

    async addToQueue(event: WebhookEvent, queueName: QueueType = 'onboarding'): Promise<void> {
        const webhooks = await this.webhookRepository.findByAccountIdAndEventType(event.account.id, event.eventType);

        for (const webhook of webhooks) {
            const webhookLog = await this.webhookLogRepository.save(WebhookLog.createFromWebhook(webhook, event));

            try {
                if (queueName === 'payments') {
                    await this.paymentsQueue.add('payments', webhookLog.toData(), { jobId: webhookLog.sid.toString() });
                } else if (queueName === 'onboarding') {
                    await this.onboardingQueue.add('onboarding', webhookLog.toData(), { jobId: webhookLog.sid.toString() });
                }
            } catch (e) {
                this.logger.error(`Could not add to webhook queue message due to ${e.message}`);
            }
        }
    }
}
