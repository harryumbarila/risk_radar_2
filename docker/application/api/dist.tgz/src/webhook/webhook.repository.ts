import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { Webhook, WebhookEventTypeEnum } from '@/webhook/webhook.entity';

@Injectable()
export class WebhookRepository extends Repository<Webhook> {
    constructor(dataSource: DataSource) {
        super(Webhook, dataSource.createEntityManager());
    }

    /**
     * Finds webhook entries by the given account ID and event type.
     *
     * @param {string} accountId - The ID of the account to search for.
     * @param {WebhookEventTypeEnum} event - The type of the event to search for.
     * @return {Promise<Webhook[]>} A promise that resolves to an array of matching webhooks.
     */
    findByAccountIdAndEventType(accountId: string, event: WebhookEventTypeEnum): Promise<Webhook[]> {
        return this.createQueryBuilder('e')
            .innerJoin('e.account', 'a')
            .where('a.id = :accountId', { accountId: accountId })
            .andWhere('e.events @> :eventType', { eventType: JSON.stringify([event]) })
            .getMany();
    }

    /**
     * Finds webhook entries by the given account ID
     *
     * @param {string} accountId - The ID of the account to search for.
     * @return {Promise<Webhook[]>} A promise that resolves to an array of matching webhooks.
     */
    findByAccountId(accountId: string): Promise<Webhook[]> {
        return this.createQueryBuilder('e').innerJoin('e.account', 'a').where('a.id = :accountId', { accountId: accountId }).getMany();
    }
}
