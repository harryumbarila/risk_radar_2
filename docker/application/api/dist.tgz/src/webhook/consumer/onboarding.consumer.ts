import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { WebhookLogRepository } from '@/webhook/webhook-log.repository';
import { Injectable } from '@nestjs/common';
import { WebhookForwardClient } from '@/webhook/webservice/webhook-forward.client';
import { WebhookLogStatusEnum } from '@/webhook/webhook-log.entity';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';

@Injectable()
@Processor('onboarding')
export class OnboardingConsumer extends WorkerHost {
    constructor(
        private readonly webhookLogRepository: WebhookLogRepository,
        private readonly webhookForwardClient: WebhookForwardClient,
        @InjectPinoLogger(OnboardingConsumer.name) private readonly logger: PinoLogger,
    ) {
        super();
    }

    async process(job: Job<any, any, string>): Promise<any> {
        try {
            const webhookLog = await this.webhookLogRepository.findOneBy({ sid: job.id });

            if (!webhookLog) {
                return;
            }

            if (!webhookLog.webhook.isActive) {
                return;
            }

            try {
                const response = await this.webhookForwardClient.sendWebhook(webhookLog);
                webhookLog.deliveredOn = new Date();
                webhookLog.status = WebhookLogStatusEnum.DELIVERED;
                webhookLog.responseBody = response.data;
                webhookLog.statusCode = response.status;
            } catch (e) {
                webhookLog.status = WebhookLogStatusEnum.FAILED;
                webhookLog.responseBody = e.message ?? `${e}`;
            } finally {
                await this.webhookLogRepository.save(webhookLog);
            }
        } catch (e) {
            this.logger.error(`Error sending webhook for job.id`, e);
        }
    }
}
