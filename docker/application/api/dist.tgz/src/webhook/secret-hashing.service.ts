import { Injectable } from '@nestjs/common';
import * as crypto from 'crypto';

@Injectable()
export class WebhookSigningPayloadService {
    public static readonly SIGNING_ALGORITHM: string = 'sha256';

    async sign(payload: any, webhookSigningSecret: string): Promise<string> {
        const hmac = crypto.createHmac(WebhookSigningPayloadService.SIGNING_ALGORITHM, webhookSigningSecret);
        hmac.update(JSON.stringify(payload));
        return hmac.digest('hex');
    }
}
