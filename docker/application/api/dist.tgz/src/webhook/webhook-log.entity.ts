import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Type } from 'class-transformer';
import { Webhook, WebhookEventTypeEnum } from './webhook.entity';
import { TypeSid } from '@/shared/model/type-sid';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import { BaseEntity } from '@/shared/model/base.entity';
import { SidColumn } from '@/shared/typeorm/decorator/sid-column.decorator';
import { WebhookEvent } from '@/webhook/webhook-payload';

export enum WebhookLogStatusEnum {
    /**
     * Pending is when the webhook event is created but not sent yet
     */
    PENDING = 'PENDING',
    /**
     * Processing is when the webhook event is being processed by consumer
     */
    PROCESSING = 'PROCESSING',
    /**
     * after a successful delivery
     */
    DELIVERED = 'DELIVERED',
    /**
     * after a failed delivery
     */
    FAILED = 'FAILED',
}

export type WebhookLogObjectType = 'any' | 'merchant' | 'charge';

/**
 * This entity keeps track of sent webhooks. This is very important for debugging, and to show customers the history of
 * their events etc.
 */
@Entity('webhooks_log')
@Index(['eventSid'])
export class WebhookLog extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('webhooklog')
    sid: TypeSid<'webhooklog'>;

    @Column({
        type: 'varchar',
        length: '46',
        nullable: true,
        name: 'event_sid',
    })
    eventSid: string;

    @Column({ type: 'enum', enum: WebhookLogStatusEnum })
    status: WebhookLogStatusEnum;

    @ManyToOne(() => Webhook, { nullable: false, eager: true, orphanedRowAction: 'delete' })
    @JoinColumn({ name: 'webhook_id' })
    @Type(() => Webhook)
    webhook: Webhook;

    /**
     * The target url that this webhook was sent to
     */
    @Column({ name: 'target_url' })
    url: string;

    @Column({ name: 'event_type', enum: WebhookEventTypeEnum, type: 'enum', nullable: false })
    eventType: WebhookEventTypeEnum;

    @Column({ name: 'object', type: 'varchar' })
    object: WebhookLogObjectType;

    @Column({ name: 'payload', type: 'jsonb' })
    payload: any;

    @Column({ type: 'varchar', name: 'api_version', nullable: false })
    apiVersion: string;

    /**
     * If and when delivered successfully, will have the actual delivery date
     */
    @Column({ type: 'date', name: 'delivered_on', nullable: true })
    deliveredOn?: Date;

    @Column({ name: 'status_code', default: null })
    statusCode?: number;

    @Column({ type: 'text', name: 'response_body', default: null })
    responseBody?: string;

    @Column({ type: 'varchar', name: 'request_id', default: null })
    requestId?: string;

    static createFromWebhook(webhook: Webhook, event: WebhookEvent) {
        const log = new WebhookLog();
        log.status = WebhookLogStatusEnum.PENDING;
        log.webhook = webhook;
        log.payload = event.toData();
        log.object = event.object.object;
        log.url = webhook.url;
        log.apiVersion = event.apiVersion;
        log.eventType = event.eventType;
        log.requestId = event.toData().request.id;
        log.sid = TypeSidFactory.createFromPrefix('webhooklog');
        log.id = log.sid.toUUID();
        log.eventSid = TypeSidFactory.createFromPrefix('evt').toString();

        return log;
    }

    toData() {
        return {
            webhook_log_event_sid: this.eventSid,
            payload: this.payload,
        };
    }
}
