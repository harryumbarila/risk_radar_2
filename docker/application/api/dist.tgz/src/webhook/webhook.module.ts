import { Module } from '@nestjs/common';
import { WebhookController } from './webhook.controller';
import { WebhookQueueService } from '@/webhook/webhook-queue.service';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { WebhookLogRepository } from '@/webhook/webhook-log.repository';
import { BullModule } from '@nestjs/bullmq';
import { OnboardingConsumer } from '@/webhook/consumer/onboarding.consumer';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Webhook } from '@/webhook/webhook.entity';
import { WebhookLog } from '@/webhook/webhook-log.entity';
import { WebhookForwardClient } from '@/webhook/webservice/webhook-forward.client';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { RegisterWebhookUseCase } from '@/webhook/usecase/register-webhook.usecase';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { Merchant } from '@/shared/model/merchant.entity';
import { WebhookService } from '@/webhook/webhook.service';
import { DeleteWebhookUseCase } from '@/webhook/usecase/delete-webhook.usecase';
import { InternalWebhookForwardController } from '@/webhook/internal-webhook-forward.controller';

@Module({
    imports: [
        BullModule.registerQueue({
            name: 'onboarding',
        }),
        BullModule.registerQueue({
            name: 'payments',
        }),
        TypeOrmModule.forFeature([Webhook, WebhookLog, Merchant]),
    ],
    controllers: [WebhookController, InternalWebhookForwardController],
    providers: [
        WebhookRepository,
        WebhookLogRepository,
        WebhookQueueService,
        WebhookService,
        AccountRepository,
        OnboardingConsumer,
        WebhookForwardClient,
        RegisterWebhookUseCase,
        DeleteWebhookUseCase,
        MerchantRepository,
    ],
    exports: [WebhookService],
})
export class WebhookModule {}
