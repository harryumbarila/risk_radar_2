import { WebhookEvent } from '@/webhook/webhook-payload';
import { Account } from '@/shared/model/account.entity';
import { WebhookEventTypeEnum } from '@/webhook/webhook.entity';
import { RequestIdExtractorService } from '@/shared/service/request-id-extractor.service';
import { GetMerchantResponseDto } from '@/onboarding/response/get-merchant-response.dto';
import { WebhookQueueService } from '@/webhook/webhook-queue.service';
import { Injectable } from '@nestjs/common';

@Injectable()
export class WebhookService {
    constructor(
        private readonly webhookQueueService: WebhookQueueService,
        private readonly requestIdExtractorService: RequestIdExtractorService,
    ) {}

    async createForMerchantCreated(account: Account, merchantDto: GetMerchantResponseDto): Promise<void> {
        const event = new WebhookEvent(
            account,
            WebhookEventTypeEnum.MerchantCreated,
            {
                id: merchantDto.id,
                object: 'merchant',
                payload: merchantDto,
            },
            this.requestIdExtractorService.getRequestId(),
        );

        return this.webhookQueueService.addToQueue(event);
    }

    createForMerchantProcessing(account: Account, merchantDto: GetMerchantResponseDto): Promise<void> {
        const event = new WebhookEvent(
            account,
            WebhookEventTypeEnum.MerchantProcessing,
            {
                id: merchantDto.id,
                object: 'merchant',
                payload: merchantDto,
            },
            this.requestIdExtractorService.getRequestId(),
        );

        return this.webhookQueueService.addToQueue(event);
    }

    createForMerchantVerificationApproved(account: Account, merchantDto: GetMerchantResponseDto): Promise<void> {
        const event = new WebhookEvent(
            account,
            WebhookEventTypeEnum.MerchantVerificationApproved,
            {
                id: merchantDto.id,
                object: 'merchant',
                payload: merchantDto,
            },
            this.requestIdExtractorService.getRequestId(),
        );

        return this.webhookQueueService.addToQueue(event);
    }

    forwardCharge(account: Account, eventData: any): Promise<void> {
        const eventType: WebhookEventTypeEnum = WebhookEventTypeEnum[eventData.type as keyof typeof WebhookEventTypeEnum];

        const event = new WebhookEvent(
            account,
            eventType,
            {
                id: eventData.id,
                object: 'charge',
                payload: eventData,
            },
            this.requestIdExtractorService.getRequestId(),
        );

        return this.webhookQueueService.addToQueue(event);
    }
}
