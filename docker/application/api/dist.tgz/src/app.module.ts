import { AccountModule } from '@/account/account.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoggerModule } from 'nestjs-pino';
import { AppDataSource } from '../data-source';
import { AppController } from './app.controller';
import { OnboardingModule } from './onboarding/onboarding.module';
import { JwtAuthGuard } from './shared/auth/guard/jwt-auth.guard';
import { AWSModule } from './shared/aws/aws.module';
import { jwtConfig } from './shared/config/jwt.config';
import { loggerConfig } from './shared/config/logger.config';
import { rootConfig } from './shared/config/root.config';
import { WebhookModule } from './webhook/webhook.module';
import { BullModule } from '@nestjs/bullmq';
import { bullConfigAsync } from '@/shared/config/bull.config';
import { GlobalModule } from './global/global.module';
import { SentryModule } from '@sentry/nestjs/setup';
import { TokenizerModule } from '@/tokenizer/tokenizer.module';
import { EmailModule } from './email/email.module';

@Module({
    imports: [
        SentryModule.forRoot(),
        ConfigModule.forRoot(rootConfig),
        LoggerModule.forRoot(loggerConfig),
        TypeOrmModule.forRoot(AppDataSource.options),
        JwtModule.register(jwtConfig),
        BullModule.forRootAsync(bullConfigAsync),
        GlobalModule,
        AccountModule,
        OnboardingModule,
        AccountModule,
        WebhookModule,
        TokenizerModule,
        AWSModule,
        EmailModule,
    ],
    controllers: [AppController],
    providers: [
        {
            provide: APP_GUARD,
            useClass: JwtAuthGuard,
        },
    ],
})
export class AppModule {}
