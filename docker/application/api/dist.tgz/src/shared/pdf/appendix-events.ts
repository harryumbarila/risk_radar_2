import { AuditTrailStepStepNameType } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';

export const EventsToInclude: AuditTrailStepStepNameType[] = [
    'get-contract-template-for-main-owner',
    'get-contract-template-for-extra-owner',
    'clicked-on-link-to-sign-contract',
    'sign-contract-by-main-owner',
    'sign-contract-by-extra-owner',
];

export const EventLabels: Partial<Record<AuditTrailStepStepNameType, string>> = {
    'get-contract-template-for-main-owner': 'Populated Application requested by',
    'get-contract-template-for-extra-owner': 'Populated Application requested by',
    'clicked-on-link-to-sign-contract': 'Link to sign the contract clicked by',
    'sign-contract-by-main-owner': 'Document e-signed by',
    'sign-contract-by-extra-owner': 'Document e-signed by',
};
