import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { S3Service } from '@/shared/aws/s3.service';
import { ConfigService } from '@nestjs/config';

export interface PDFTemplatesServiceConfig {
    AWS_TEMPLATES_BUCKET: string;
}

@Injectable()
export class PDFTemplatesService {
    constructor(
        @InjectPinoLogger(PDFTemplatesService.name) private readonly logger: PinoLogger,
        private configService: ConfigService<PDFTemplatesServiceConfig>,
        private readonly s3Service: S3Service,
    ) {}

    async getTemplate() {
        return this.s3Service.getFile(this.configService.get<string>('AWS_TEMPLATES_BUCKET'), 'contract-template-v1.pdf');
    }

    async getFile(key: string) {
        return this.s3Service.getFile(this.configService.get<string>('AWS_TEMPLATES_BUCKET'), key);
    }

    async getFileWithSignedUrl(key: string) {
        return this.s3Service.getFileSignedUrl(this.configService.get<string>('AWS_TEMPLATES_BUCKET'), key);
    }

    async upload(file: Buffer | string, fileName: string) {
        return this.s3Service.uploadFile(this.configService.get<string>('AWS_TEMPLATES_BUCKET'), file, fileName, 'application/pdf');
    }
}
