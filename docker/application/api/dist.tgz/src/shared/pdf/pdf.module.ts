import { Module } from '@nestjs/common';
import { AWSModule } from '../aws/aws.module';
import { PDFService } from './pdf.service';
import { PDFTemplatesService } from './templates.service';

@Module({
    imports: [AWSModule],
    exports: [PDFService, PDFTemplatesService],
    providers: [PDFService, PDFTemplatesService],
})
export class PDFModule {}
