import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
// We use this library to read the PDF file as pdf-lib has an open issue for not found widgets https://github.com/Hopding/pdf-lib/issues/1281
import { PDFCheckBox, PDFDocument, PDFTextField, rgb, StandardFonts } from '@visaright/pdf-lib';

import { AuditTrailStepStepNameType } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';

import * as fs from 'fs';
import * as path from 'path';
import { EventLabels } from './appendix-events';

// This need to be imported this way to work with nest, see https://github.com/Hopding/pdf-lib/issues/372
const fontkit = require('@pdf-lib/fontkit');
const DeviceDetector = require('device-detector-js');

type AppendixDataRow = {
    name: string;
    email: string;
    ip: string;
    date: Date;
    device: string;
    event: AuditTrailStepStepNameType;
};

@Injectable()
export class PDFService {
    constructor(@InjectPinoLogger(PDFService.name) private readonly logger: PinoLogger) {}

    async fillFromTemplate(template: Buffer, data: Record<string, string>): Promise<Buffer> {
        // Load the template with form fields
        this.logger.info('Loading template');
        const file = await PDFDocument.load(template);
        const form = file.getForm();
        const fields = form.getFields();

        // Fill the form with the data and make fields no longer editable
        this.logger.info('Filling template with data');

        fields.forEach((field) => {
            try {
                const value = data[field.getName()];
                if (!value) return;

                // Fill depending the type of the field
                if (field instanceof PDFTextField) {
                    field.setText(value);
                }

                if (field instanceof PDFCheckBox) {
                    if (value === 'Yes' || value === 'true' || value === '1') {
                        field.check();
                    }
                }
            } catch (error) {
                this.logger.error('Failed to fill field: ', field.getName(), error.message);
            }
        });

        // Save the filled PDF
        this.logger.info('Saving changes to PDF');
        form.flatten();

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addDefaultSignature(template: Buffer) {
        this.logger.info('Loading template');
        const file = await PDFDocument.load(template);
        await this.addSignature(file, 5, 50, 225, 'John Doe');

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addSignatureCommon(file: PDFDocument, name: string) {
        await this.addInitials(file, name);
        await this.addIAgree(file);
    }

    // TODO: Move this to a separate service or a corresponding one
    async addFirstOwnerSignatures(template: Buffer, name: string) {
        const file = await PDFDocument.load(template);

        const now = new Date();

        await this.addSignature(file, 3, 45, 318, name);
        await this.addDate(file, 3, 175, 318, now);

        await this.addSignature(file, 4, 125, 215, name);
        await this.addDate(file, 4, 475, 215, now);

        await this.addSignature(file, 5, 50, 225, name);
        await this.addDate(file, 5, 320, 225, now);

        await this.addSignature(file, 7, 30, 153, name);
        await this.addDate(file, 7, 190, 153, now);

        await this.addSignature(file, 8, 40, 175, name);
        await this.addDate(file, 8, 190, 175, now);

        await this.addSignatureCommon(file, name);

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addSecondOwnerSignatures(template: Buffer, name: string) {
        const file = await PDFDocument.load(template);

        const now = new Date();

        await this.addSignature(file, 3, 45, 280, name);
        await this.addDate(file, 3, 175, 280, now);

        await this.addSignature(file, 7, 290, 153, name);
        await this.addDate(file, 7, 480, 153, now);

        await this.addSignature(file, 8, 290, 175, name);
        await this.addDate(file, 8, 460, 175, now);

        await this.addSignatureCommon(file, name);

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addThirdOwnerSignatures(template: Buffer, name: string) {
        const file = await PDFDocument.load(template);

        const now = new Date();

        await this.addSignature(file, 3, 360, 320, name);
        await this.addDate(file, 3, 500, 320, now);

        await this.addSignature(file, 8, 35, 123, name);
        await this.addDate(file, 8, 190, 123, now);

        await this.addSignatureCommon(file, name);

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addFourthOwnerSignatures(template: Buffer, name: string) {
        const file = await PDFDocument.load(template);

        const now = new Date();

        await this.addSignature(file, 3, 360, 280, name);
        await this.addDate(file, 3, 500, 290, now);

        await this.addSignature(file, 8, 290, 123, name);
        await this.addDate(file, 8, 460, 123, now);

        await this.addSignatureCommon(file, name);

        const filledPdf = await file.save();

        return Buffer.from(filledPdf);
    }

    async addAppendixPage(template: Buffer, page: number): Promise<Buffer> {
        const pdf = await PDFDocument.load(template);
        const pages = pdf.getPages();
        const pageToAdd = pages[page - 1];

        const font = await pdf.embedFont(StandardFonts.HelveticaBold);
        const fontSize = 24;

        const x = 55;
        const y = 730;

        pageToAdd.drawText('Audit Trail Logs', {
            x,
            y,
            size: fontSize,
            font,
            color: rgb(0, 0, 0),
        });

        const filledPdf = await pdf.save();
        return Buffer.from(filledPdf);
    }

    async addAppendixEvents(template: Buffer, data: AppendixDataRow[]): Promise<Buffer> {
        const page = 10;
        const pdf = await PDFDocument.load(template);

        const pages = pdf.getPages();
        const pageToSign = pages[page - 1];

        const font = await pdf.embedFont(StandardFonts.TimesRoman);
        const fontSize = 12;

        let x = 55;
        let y = 690;

        const deviceDetector = new DeviceDetector();

        data.forEach(({ name, email, ip, device, date, event }) => {
            const label = EventLabels[event];

            const message = `${label} ${name} (${email})`;
            const ipReport = `${date.toISOString()} - IP Address: ${ip}`;

            // Device
            const deviceData = deviceDetector.parse(device);
            const parsedDeviceType = deviceData.device.type.charAt(0).toUpperCase() + deviceData.device.type.slice(1);

            const deviceString =
                `${parsedDeviceType}${deviceData.device.brand ? ' - ' + deviceData.device.brand : ''}${deviceData.device.model ? ' - ' + deviceData.device.model : ''}`.trim();
            const osString = `${deviceData.os.name}${deviceData.os.version ? ' - ' + deviceData.os.version : ''}`.trim();
            const clientString = `${deviceData.client.name}${deviceData.client.version ? ' - ' + deviceData.client.version : ''}`.trim();

            const deviceInfoString =
                `Device: ${deviceString ? deviceString + ' / ' : ''}${osString ? osString + ' / ' : ''}${clientString ? clientString : ''}`.trim();

            pageToSign.drawText(message, {
                x,
                y,
                size: fontSize,
                font,
                color: rgb(0, 0, 0),
            });

            pageToSign.drawText(ipReport, {
                x,
                y: y - 20,
                size: fontSize,
                font,
                color: rgb(0, 0, 0),
            });

            pageToSign.drawText(deviceInfoString, {
                x,
                y: y - 40,
                size: fontSize,
                font,
                color: rgb(0, 0, 0),
            });

            y -= 80;
        });

        const filledPdf = await pdf.save();

        return Buffer.from(filledPdf);
    }

    async addSignature(pdf: PDFDocument, page: number, x: number, y: number, text: string): Promise<PDFDocument> {
        // Load the font
        pdf.registerFontkit(fontkit);
        const fontPath = path.join(__dirname, '../..', 'assets', 'fonts', 'AlexandriaWhitehouse.otf');
        const signFont = fs.readFileSync(fontPath);

        this.logger.info('Adding signature to PDF');

        const pages = pdf.getPages();
        const pageToSign = pages[page - 1];

        const font = await pdf.embedFont(signFont);
        const fontSize = 18;

        pageToSign.drawText(text, {
            x,
            y,
            size: fontSize,
            font,
            color: rgb(0, 0, 0),
        });

        return pdf;
    }

    async addDate(pdf: PDFDocument, page: number, x: number, y: number, date: Date): Promise<PDFDocument> {
        const font = await pdf.embedFont(StandardFonts.TimesRoman);
        const fontSize = 10;

        this.logger.info('Adding date to PDF');

        const pages = pdf.getPages();
        const pageToSign = pages[page - 1];

        const formattedDate = date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
        });

        pageToSign.drawText(formattedDate, {
            x,
            y,
            size: fontSize,
            font,
            color: rgb(0, 0, 0),
        });

        return pdf;
    }

    async addInitials(pdf: PDFDocument, name: string): Promise<PDFDocument> {
        const initialsPage = 3;

        const font = await pdf.embedFont(StandardFonts.Helvetica);
        const fontSize = 7;

        const [firstName, secondName] = name.split(' ');
        const initials = `${firstName.charAt(0)}${secondName.charAt(0)}`;

        this.logger.info('Adding owner initials to PDF');

        const pages = pdf.getPages();
        const pageToSign = pages[initialsPage - 1];

        pageToSign.drawText(initials, {
            x: 345,
            y: 417,
            size: fontSize,
            font,
            color: rgb(0, 0, 0),
        });

        return pdf;
    }

    async addIAgree(pdf: PDFDocument): Promise<PDFDocument> {
        const agreePage = 9;

        const font = await pdf.embedFont(StandardFonts.Helvetica);
        const fontSize = 64;

        this.logger.info('Checking I Agree checkbox in PDF');

        const pages = pdf.getPages();
        const pageToSign = pages[agreePage - 1];

        pageToSign.drawText('.', {
            x: 416,
            y: 545,
            size: fontSize,
            font,
            color: rgb(0, 0, 0),
        });

        return pdf;
    }
}
