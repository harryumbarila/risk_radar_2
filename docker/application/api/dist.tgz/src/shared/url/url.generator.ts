import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';

/**
 * Contracts
 */
export const CONTRACTS_PREFIX = '/v1/contracts';
export const CONTRACTS_URL_CLICK_TO_SIGN_TRACK = '/click_to_sign/:leadSignatureId';

export interface UrlGeneratorConfig {
    EMAILS_MERCHANT_WEB_APP_URL: string;
    CONTRACTS_DOWNLOAD_URL: string;
    API_URL: string;
}

@Injectable()
export class UrlGenerator {
    constructor(private configService: ConfigService<UrlGeneratorConfig>) {}

    generateClickToSignTrackUrl(params: Record<string, string>): string {
        let url = CONTRACTS_URL_CLICK_TO_SIGN_TRACK;

        Object.keys(params).forEach((key) => {
            // Replace placeholders in the URL with values from `params`
            const placeholder = `:${key}`;
            url = url.replace(placeholder, params[key]);
        });

        return this.configService.get('API_URL') + CONTRACTS_PREFIX + url;
    }

    generateDownloadContractUrl(leadSignatureId: string): string {
        return this.configService.get('CONTRACTS_DOWNLOAD_URL') + CONTRACTS_PREFIX + '/download/' + leadSignatureId;
    }

    generateClickToSignFormUrl(leadSignatureId: string): string {
        return this.configService.get('EMAILS_MERCHANT_WEB_APP_URL') + '/' + leadSignatureId;
    }
}
