import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';

import { FormKeyDef, ProductionFieldKeys, StagingFieldKeys } from './mappings';
import { StateFields, JobTitleFields, BusinessTypeFields, MainProductFields, BooleanFields, TinTypeField } from './special-fields';
import { stateMapping } from './state-mappings';
import { jobTitleMapping } from './job-title-fields';
import { businessTypeMapping } from './business-type-fields';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import {
    mainProductCategoryMappingProduction,
    mainProductCategoryMappingStaging,
} from '@/shared/irisMappings/main-product-category.mapping';
import { tinTypeMapping } from '@/shared/irisMappings/tin-type-mapping';
import { CreateSignatureForLeadRequest, RecipientDto } from '@/shared/webservice/iris/request/create-signature-for-lead.request';
import { SignatureOwnersMappings } from '@/shared/irisMappings/signature-owners-mappings';
import { signedSignatureMappingProduction, signedSignatureMappingStaging } from '@/shared/irisMappings/signed-signature.mapping';
import { OwnerSignedRequest } from '@/shared/webservice/iris/request/owner-signed.request';
import { OwnerSignedMapperRequest } from '@/shared/webservice/iris/mapper/owner-signed.request';

// TODO: Move this to a separate file
type FieldRow = {
    id: number;
    value: string;
};

type DetailsRow = {
    id: number;
    fields: FieldRow[];
};

type IncomingIrisData = {
    details: DetailsRow[];
};

const iterate = (obj, callback, path = '') => {
    Object.keys(obj).forEach((key) => {
        let currentPath = path + '.' + key;
        if (currentPath.startsWith('.')) currentPath = currentPath.substring(1);
        callback(currentPath, obj[key]);
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            iterate(obj[key], callback, currentPath);
        }
    });
};

const iterateNonRecursive = (obj, callback) => {
    const stack = [obj];
    while (stack?.length > 0) {
        const currentObj = stack.pop();
        Object.keys(currentObj).forEach((key) => {
            callback(key, currentObj[key]);
            if (typeof currentObj[key] === 'object' && currentObj[key] !== null) {
                stack.push(currentObj[key]);
            }
        });
    }
};

const getFieldNameById = (obj, id) => {
    let name = null;
    const keys = Object.keys(obj);
    for (let i = 0; i < keys.length && !name; i++) {
        const mId = obj[keys[i]];
        if (mId == id) {
            name = keys[i];
        }
    }
    return name;
};

export interface IrisMapperConfig {
    IRIS_MAPPING_KEYS_ENV: 'staging' | 'production';
}

@Injectable()
export class IrisMapper {
    private readonly fieldKeys: FormKeyDef;
    private readonly mainProductCategory: FormKeyDef;
    private readonly businessTypeMapping: FormKeyDef;
    private readonly signatureOwnersMapping: FormKeyDef;

    constructor(configService: ConfigService<IrisMapperConfig>) {
        const keysEnv = configService.get('IRIS_MAPPING_KEYS_ENV');
        this.fieldKeys = keysEnv === 'staging' ? StagingFieldKeys : ProductionFieldKeys;
        this.mainProductCategory = keysEnv === 'staging' ? mainProductCategoryMappingStaging : mainProductCategoryMappingProduction;
        this.signatureOwnersMapping = keysEnv === 'staging' ? signedSignatureMappingStaging : signedSignatureMappingProduction;
        this.businessTypeMapping = businessTypeMapping;
    }

    fromNormalizedDtoToIris(input: PublicLeadDto): string {
        const fields = [];
        iterate(input, (identifier, value) => {
            const id = this.fieldKeys[identifier];
            if (!id) return;
            let mValue = value.toString();

            /**
             * Iris expects to send 1 or 0
             */
            if (typeof value === 'boolean') {
                mValue = <boolean>value ? '1' : '0';
            }

            if (StateFields[identifier]) mValue = stateMapping[mValue];
            else if (BusinessTypeFields[identifier]) mValue = this.businessTypeMapping[mValue];
            else if (JobTitleFields[identifier]) mValue = jobTitleMapping[mValue];
            else if (TinTypeField[identifier]) {
                mValue = tinTypeMapping[mValue];
            } else if (identifier == 'main_product.category') mValue = this.mainProductCategory[mValue];
            fields.push({ id, value: mValue });
        });
        const res = { fields };
        return JSON.stringify(res);
    }

    fromIrisToNormalizedDto(input: string): PublicLeadDto {
        const data = JSON.parse(input);
        const dto = {};
        iterateNonRecursive(data, (key, value) => {
            if (!value) return;
            if (typeof value !== 'object' || Array.isArray(value)) return;
            const { id } = value;
            if (!id) return;
            const fieldName = getFieldNameById(this.fieldKeys, id);
            if (!fieldName) return;
            if (!value.value) {
                return;
            }
            const pathParts = fieldName.split('.');
            let currentPosition = dto;
            const length = pathParts.length;
            let mValue = value.value;
            if (StateFields[fieldName]) {
                if (mValue == null && stateMapping[value.value]) {
                    mValue = value.value;
                }
            } else if (BusinessTypeFields[fieldName]) {
                mValue = getFieldNameById(this.businessTypeMapping, mValue);

                if (mValue == null && this.businessTypeMapping[value.value]) {
                    mValue = value.value;
                }
            } else if (JobTitleFields[fieldName]) mValue = getFieldNameById(jobTitleMapping, mValue);
            else if (MainProductFields[fieldName]) {
                mValue = getFieldNameById(this.mainProductCategory, mValue);
                if (mValue == null && this.mainProductCategory[value.value]) {
                    mValue = value.value;
                }
            } else if (BooleanFields[fieldName]) {
                /**
                 * Iris for get merchant returns Yes No
                 */
                if (mValue == 'Yes') {
                    mValue = true;
                }

                if (mValue == 'No') {
                    mValue = false;
                }

                /**
                 * Otherwise Iris returns 0 or 1
                 */
                if (mValue == '1') {
                    mValue = true;
                }

                if (mValue == '0') {
                    mValue = false;
                }
            } else if (TinTypeField[fieldName]) {
                mValue = getFieldNameById(tinTypeMapping, mValue);

                if (mValue == null && tinTypeMapping[value.value]) {
                    mValue = value.value;
                }
            }
            for (let i = 0; i < length; i++) {
                const part = pathParts[i];
                if (i === length - 1) currentPosition[part] = mValue;
                else {
                    if (!currentPosition[part]) currentPosition[part] = {};
                    currentPosition = currentPosition[part];
                }
            }
        });
        return dto as PublicLeadDto;
    }

    /**
     * @deprecated
     */
    fromOwnersToCreateSignatureForLeadRequest(owners: string[]): CreateSignatureForLeadRequest {
        const dto = new CreateSignatureForLeadRequest();
        dto.expire = true;

        dto.recipients = [];

        for (let index = 0; index < owners.length; index++) {
            const ownerKey = `${index + 1}`;
            const fieldId = SignatureOwnersMappings[ownerKey];

            if (fieldId) {
                const recipient = new RecipientDto();
                recipient.fieldId = fieldId;
                recipient.name = owners[index];
                dto.recipients.push(recipient);
            }
        }

        return dto;
    }

    signOwner(dto: OwnerSignedMapperRequest): OwnerSignedRequest {
        const request = new OwnerSignedRequest();
        request.fields = [];

        if (dto.ownerNumber) {
            const ownerKey = `owner${dto.ownerNumber}`; // Derive the owner key e.g., owner1, owner2, etc.
            const ownerUrlKey = `${ownerKey}Url`; // Derive the URL key

            // Fetch the corresponding mapping IDs
            const ownerId = this.signatureOwnersMapping[ownerKey];
            const ownerUrlId = this.signatureOwnersMapping[ownerUrlKey];

            // If IDs exist, create FieldDto objects for them
            if (ownerId && ownerUrlId) {
                request.fields.push({ id: ownerId, value: '1' }); // 1 for Yes, 0 for No
                request.fields.push({ id: ownerUrlId, value: dto.url });
            }
        }

        if (dto.allOwnersSigned) {
            // Add a global "owners signed" field if existent in the mapping
            const allOwnersSignedId = this.signatureOwnersMapping['allOwnersSigned'];

            if (allOwnersSignedId) {
                request.fields.push({ id: allOwnersSignedId, value: '1' });
            }
        }

        return request;
    }

    /**
     * Flattens the Iris data to a key-value pair object where the key is the field ID and the value is the field value
     * @param data The Iris data to flatten
     * @returns The flattened data
     */
    flatIrisData(data: IncomingIrisData): Record<string, string> {
        const result: Record<string, string> = {};

        // Map
        data.details.forEach((detail) => {
            detail.fields.forEach((field) => {
                result[field.id.toString()] = field.value;
            });
        });

        return result;
    }
}
