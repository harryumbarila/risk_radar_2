export const SignatureOwnersMappings: Record<string, string> = {
    1: '5945', // owner 1
    2: '4815', // owner 2
    3: '5944', // owner 3
    4: '5943', // owner 4
};
