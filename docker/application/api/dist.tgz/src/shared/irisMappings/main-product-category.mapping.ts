import { FormKeyDef } from '@/shared/irisMappings/mappings';

/**
 * @see industryCodeMappings
 */
export const mainProductCategoryMappingStaging: FormKeyDef = {
    Apperel: '12',
    Auto: '13',
    Healthcare: '14',
    Lodging: '8',
    MOTO: '4',
    Other: '15',
    'Personal Services': '16',
    'Professional Services': '17',
    Restaurant: '18',
    Retail: '2',
    Transportation: '18',
    Wholesale: '19',
    Petroleum: '20',
    Internet: '21',
    'Monitored Merchant': '22',
};

/**
 * @see industryCodeMappings
 */
export const mainProductCategoryMappingProduction: FormKeyDef = {
    Apperel: '13',
    Auto: '12',
    Healthcare: '14',
    Lodging: '8',
    MOTO: '4',
    Other: '16',
    'Personal Services': '17',
    'Professional Services': '18',
    Restaurant: '5',
    Retail: '2',
    Transportation: '19',
    Wholesale: '20',
    Petroleum: '11',
    Internet: '7',
    'Monitored Merchant': '22',
};
