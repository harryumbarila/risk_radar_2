export const businessTypeMapping: Record<string, string> = {
    'Sole Proprietor': '2',
    'Limited Liability (LLC)': '1',
    Partnership: '15',
    'Association/State & Trust': '19',
    'Tax Exempt Org': '21',
    Corporation: '3',
};
