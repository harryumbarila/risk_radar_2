import { FormKeyDef } from '@/shared/irisMappings/mappings';

export const signedSignatureMappingStaging: FormKeyDef = {
    owner1: '8348',
    owner1Url: '8349',
    owner2: '8351',
    owner2Url: '8354',
    owner3: '8352',
    owner3Url: '8355',
    owner4: '8353',
    owner4Url: '8356',
    allOwnersSigned: '8350',
};

export const signedSignatureMappingProduction: FormKeyDef = {
    owner1: '8032',
    owner1Url: '8037',
    owner2: '8033',
    owner2Url: '8038',
    owner3: '8034',
    owner3Url: '8039',
    owner4: '8035',
    owner4Url: '8040',
    allOwnersSigned: '8036',
};
