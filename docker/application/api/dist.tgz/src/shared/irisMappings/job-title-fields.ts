export const jobTitleMapping: Record<string, string> = {
  President: '1',
  'Vice President': '2',
  Treasurer: '3',
  Owner: '4',
  Partner: '5',
  CEO: '6',
  Secretary: '7',
  Director: '8',
  Controller: '9',
  Accountant: '11',
  Chairmen: '12',
  'Contact Only': '13'
};
