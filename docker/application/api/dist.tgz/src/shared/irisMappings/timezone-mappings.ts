export const timezoneMappingToIris: Record<string, string> = {
  'US/Eastern': '705',
  'US/Central': '706',
  'US/Mountain': '707',
  'US/Pacific': '708',
  'US/Alaska': '709',
  'US/Hawaii': '110',
};

const inverted: Record<string, string> = {};
Object.keys(timezoneMappingToIris).forEach((key) => {
  inverted[timezoneMappingToIris[key]] = key;
});

export const timezoneMappingToString: Record<string, string> = inverted;
