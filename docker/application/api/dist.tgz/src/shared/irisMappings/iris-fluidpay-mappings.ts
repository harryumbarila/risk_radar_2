export const businessTypeMappings: Record<string, string> = {
    Apparel: 'retail',
    Auto: 'retail',
    Healthcare: 'healthcare',
    MOTO: 'moto',
    Retail: 'retail',
    Internet: 'ecomm',
};

export const industryCodeMappings: Record<string, string> = {
    Apparel: 'R',
    Auto: 'R',
    Healthcare: 'R',
    Lodging: 'H',
    MOTO: 'R',
    Other: '0',
    'Personal Services': 'R',
    'Professional Services': 'R',
    Restaurant: 'F',
    Retail: 'R',
    Transportation: 'P',
    Wholesale: 'R',
    Petroleum: 'O',
    Internet: '0',
    'Monitored Merchant': '0',
};

const mappingBusinessLogic = (lead: any): string => {
    const storefront = lead.current_sales.sales_percentage.card_swipe_percentage;
    const internet = lead.current_sales.sales_percentage.online_percentage;
    const keyed = lead.current_sales.sales_percentage.keyed_percentage;
    const moto = lead.current_sales.sales_percentage.moto_percentage;
    if (storefront >= 70) return 'retail';
    else if (keyed >= 50) return 'moto';
    else if (internet >= 30) return 'ecomm';
    else if (moto >= 30) return 'moto';
    return 'retail';
};

export const getFluidPayBusinessTypeMapping = (irisBusinessType: string, lead: any): string => {
    const mapping = businessTypeMappings[irisBusinessType];
    if (mapping) return mapping;
    else return mappingBusinessLogic(lead);
};

export const getFluidPayIndustryCodeMapping = (irisBusinessType: string): string => {
    return industryCodeMappings[irisBusinessType] ?? 'R';
};
