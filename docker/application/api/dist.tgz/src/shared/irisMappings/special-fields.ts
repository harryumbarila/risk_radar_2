export const StateFields = {
    'legal_business_address.state': true,
    'dba_address.state': true,
    'owner_one.home_address.state': true,
    'owner_two.home_address.state': true,
    'owner_three.home_address.state': true,
    'owner_four.home_address.state': true,
} as const;

export const JobTitleFields = {
    'owner_one.job_title': true,
    'owner_two.job_title': true,
    'owner_three.job_title': true,
    'owner_four.job_title': true,
} as const;

export const BusinessTypeFields = {
    business_type: true,
} as const;

export const TinTypeField = {
    tin_type: true,
} as const;

export const MainProductFields = {
    'main_product.category': true,
};

export const BooleanFields = {
    'owner_one.authority.authorized_signer': true,
    'owner_one.authority.manager_controller': true,
    'owner_one.authority.personal_guarantee': true,
    'owner_one.authority.authorized_contact': true,

    'owner_two.authority.authorized_signer': true,
    'owner_two.authority.manager_controller': true,
    'owner_two.authority.personal_guarantee': true,
    'owner_two.authority.authorized_contact': true,

    'owner_three.authority.authorized_signer': true,
    'owner_three.authority.manager_controller': true,
    'owner_three.authority.personal_guarantee': true,
    'owner_three.authority.authorized_contact': true,

    'owner_four.authority.authorized_signer': true,
    'owner_four.authority.manager_controller': true,
    'owner_four.authority.personal_guarantee': true,
    'owner_four.authority.authorized_contact': true,
};
