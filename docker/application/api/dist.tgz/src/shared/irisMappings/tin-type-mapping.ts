export const tinTypeMapping: Record<string, string> = {
    EIN: '2',
    SSN: '3',
    ITIN: '4',
};
