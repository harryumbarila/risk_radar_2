import { PipeTransform } from '@nestjs/common';
import { CustomFileTypeValidator } from './custom-file-type-validator.decorator';
import { DomainError } from '../model/domain.error';
import { DocumentUploadErrorCode } from '@/shared/model/error.constants';

export class CustomFileError extends DomainError<DocumentUploadErrorCode> {}

export class CustomFileValidationPipe implements PipeTransform {
    constructor(
        private readonly allowedFileTypes: string[],
        private readonly maxSize: number,
    ) {}

    transform(file: any) {
        const fileTypeValidator = new CustomFileTypeValidator(this.allowedFileTypes);
        const isFileTypeValid = fileTypeValidator.validate(file.mimetype);

        if (!isFileTypeValid) {
            throw new CustomFileError({
                name: 'INVALID_DOCUMENT_TYPE',
                message: fileTypeValidator.defaultMessage(),
            });
        }

        if (file.size > this.maxSize) {
            throw new CustomFileError({
                name: 'FILE_SIZE_EXCEEDED',
                message: 'File size exceeds the allowed limit of ' + this.maxSize + ' bytes.',
            });
        }

        return file;
    }
}
