import { ValidatorConstraint, ValidatorConstraintInterface } from 'class-validator';

@ValidatorConstraint({ name: 'customFileTypeValidator', async: false })
export class CustomFileTypeValidator implements ValidatorConstraintInterface {
    constructor(private readonly allowedFileTypes: string[]) {}

    validate(mimetype: string) {
        // Check if the mimetype exists in the allowed file types
        const valid = this.allowedFileTypes.includes(mimetype);
        return valid;
    }

    defaultMessage() {
        // Return a default error message
        return `File type is invalid. Allowed types: ${this.allowedFileTypes.join(', ')}`;
    }
}
