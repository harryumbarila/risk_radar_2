import {
    ValidationArguments,
    ValidationOptions,
    ValidatorConstraint,
    ValidatorConstraintInterface,
    registerDecorator,
} from 'class-validator';
import { SalesPercentage } from '@/onboarding/request/public-lead.request.dto';

@ValidatorConstraint({ name: 'SumOfPercentagesEquals100' })
export class SumOfPercentagesConstraint implements ValidatorConstraintInterface {
    validate(value: Object, args?: ValidationArguments): boolean {
        if (typeof value !== 'object' || value === null) {
            return false;
        }

        const salesPercentage = value as SalesPercentage;
        const sum =
            Number(salesPercentage.card_swipe_percentage) +
            Number(salesPercentage.moto_percentage) +
            Number(salesPercentage.online_percentage) +
            Number(salesPercentage.keyed_percentage);
        return sum === 100;
    }

    defaultMessage(args?: ValidationArguments): string {
        return ' The sum of all percentages must be 100';
    }
}

export function SumOfPercentagesEquals100(validationOptions?: ValidationOptions) {
    return function (object: Object, propertyName: string) {
        registerDecorator({
            target: object.constructor,
            propertyName: propertyName,
            options: validationOptions,
            constraints: [propertyName],
            validator: SumOfPercentagesConstraint,
        });
    };
}
