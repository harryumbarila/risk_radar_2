import { ArgumentMetadata, PipeTransform } from '@nestjs/common';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { CreateMerchantRequestDto } from '@/onboarding/request/create-merchant-request.dto';

export class ConfigureOwnersPipeTransformer implements PipeTransform {
    transform(value: any, metadata: ArgumentMetadata) {
        if (metadata.type === 'body') {
            if (value instanceof PublicLeadDto) {
                value.configureOwners();
            } else if (value instanceof CreateMerchantRequestDto && value.merchant instanceof PublicLeadDto) {
                value.merchant.configureOwners();
            }
        }
        return value;
    }
}
