export interface UseCaseInterface {
    handle(...args: any[]): any;
}
