import { TypeID } from 'typeid-js';

export class TypeSid<T extends string> extends TypeID<T> {
    toJSON() {
        return this.toString();
    }
}
