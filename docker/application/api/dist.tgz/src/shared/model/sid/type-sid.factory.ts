import { typeid, TypeID } from 'typeid-js';
import { TypeSid } from '../type-sid';

/**
 * A factory class for creating TypeSid instances.
 */
export class TypeSidFactory {
    private constructor() {}

    /**
     * Create a TypeSid instance from a string.
     *
     * @param {string} str - The input string to create the TypeSid instance from.
     * @returns {TypeSid<U>} - The created TypeSid instance.
     */
    static createFromString<U extends string>(str: string): TypeSid<U> {
        const id = TypeID.fromString<U>(str);
        return Object.setPrototypeOf(id, TypeSid.prototype);
    }

    /**
     * Creates a new TypeSid instance using the provided prefix.
     *
     * @param prefix - The prefix value for the TypeSid instance.
     * @returns A new TypeSid instance.
     */
    static createFromPrefix<U extends string>(prefix: U): TypeSid<U> {
        const id = typeid(prefix);
        return Object.setPrototypeOf(id, TypeSid.prototype);
    }
}
