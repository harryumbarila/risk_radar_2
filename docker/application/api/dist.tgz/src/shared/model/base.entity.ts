import { CreateDateColumn, UpdateDateColumn } from 'typeorm';

interface TimestampedEntityInterface {
    createdAt: Date;
    updatedAt: Date;

    getCreatedAt(): Date;
    getUpdatedAt(): Date;
}

export abstract class BaseEntity implements TimestampedEntityInterface {
    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;

    getCreatedAt(): Date {
        return this.createdAt;
    }

    getUpdatedAt(): Date {
        return this.updatedAt;
    }
}
