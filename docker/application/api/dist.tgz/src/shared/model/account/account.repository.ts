import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { Account } from '@/shared/model/account.entity';

@Injectable()
export class AccountRepository extends Repository<Account> {
    constructor(dataSource: DataSource) {
        super(Account, dataSource.createEntityManager());
    }
}
