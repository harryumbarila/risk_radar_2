import { Injectable } from '@nestjs/common';
import * as crypto from 'crypto';
import { ConfigService } from '@nestjs/config';
import { ApiKeys } from '@/shared/model/account/api-keys';

export interface ApiKeysServiceConfig {
    ACCOUNT_PUBLIC_API_KEY_PREFIX: string;
    ACCOUNT_SECRET_API_KEY_PREFIX: string;
}

export interface ApiKeysRaw {
    rawSecretKey: string;
    apiKeys: ApiKeys;
}

@Injectable()
export class ApiKeysFactory {
    constructor(
        private configService: ConfigService<ApiKeysServiceConfig>,
    ) {}

    async create(): Promise<ApiKeysRaw> {
        try {
            const publicApiKeyPrefix = this.configService.get<string>('ACCOUNT_PUBLIC_API_KEY_PREFIX');
            const secretApiKeyPrefix = this.configService.get<string>('ACCOUNT_SECRET_API_KEY_PREFIX');
            const publishableKey = publicApiKeyPrefix + '_' + crypto.randomBytes(64).toString('hex');
            const secretKey = secretApiKeyPrefix + '_' + crypto.randomBytes(64).toString('hex');

            const apiKeys = new ApiKeys();

            apiKeys.publishableKey = publishableKey;
            apiKeys.secretKey = secretKey;

            return {
                rawSecretKey: secretKey,
                apiKeys: apiKeys,
            };
        } catch (err) {
            throw new Error('Could not create api keys.');
        }
    }
}
