import { Column, CreateDateColumn } from 'typeorm';
import { ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH, ACCOUNT_API_KEYS_MAX_SECRET_KEY_LENGTH } from '@/shared/model/account/account.const';

export class ApiKeys {
    @Column({ type: 'varchar', name: 'publishable_key', length: ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH, unique: true })
    publishableKey: string;

    @Column({ type: 'varchar', name: 'secret_key', length: ACCOUNT_API_KEYS_MAX_SECRET_KEY_LENGTH, unique: true })
    secretKey: string;

    @CreateDateColumn({ name: 'secret_key_created_at' })
    secretKeyCreatedAt: Date;

    @CreateDateColumn({ name: 'publishable_key_created_at' })
    publishableKeyCreatedAt: Date;

    @Column({ type: 'date', name: 'secret_key_last_used_at', nullable: true })
    secretKeyLastUsedAt?: Date;

    @Column({ type: 'date', name: 'publishable_key_last_used_at', nullable: true })
    publishableKeyLastUsedAt?: Date;

    isTheSamePublishableKey(publishableKey: string): boolean {
        return this.publishableKey === publishableKey;
    }
}
