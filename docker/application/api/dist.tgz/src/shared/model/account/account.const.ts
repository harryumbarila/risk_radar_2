export const ACCOUNT_MAX_EMAIL_LENGTH: number = 320;
export const ACCOUNT_MAX_NAME_LENGTH: number = 255;
export const ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH: number = 255;
export const ACCOUNT_API_KEYS_MAX_SECRET_KEY_LENGTH: number = 255;
