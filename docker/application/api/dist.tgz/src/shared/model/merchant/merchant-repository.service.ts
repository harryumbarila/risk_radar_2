import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { Merchant } from '../merchant.entity';

@Injectable()
export class MerchantRepository extends Repository<Merchant> {
    constructor(dataSource: DataSource) {
        super(Merchant, dataSource.createEntityManager());
    }

    async findOneBySid(sid: string): Promise<Merchant | null> {
        return this.findOneBy({ sid: sid });
    }

    async findUserFromAccount(accountSid: string, userSid: string): Promise<Merchant | null> {
        return this.findOneBy({ account: { sid: accountSid }, sid: userSid });
    }
}
