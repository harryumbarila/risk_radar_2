import { BeforeInsert, Column, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import { BaseEntity } from './base.entity';
import { SidColumn } from '../typeorm/decorator/sid-column.decorator';
import { TypeSid } from './type-sid';
import { TypeSidFactory } from './sid/type-sid.factory';
import { CustomPhoneNumber } from './custom-phone-number';
import { Lead } from './lead.entity';
import { Account } from '@/shared/model/account.entity';

@Entity({ name: 'merchants' })
export class Merchant extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('merchant')
    sid: TypeSid<'merchant'>;

    @Column({ type: 'varchar', length: 11, name: 'phone_number' })
    phoneNumber: string;

    @OneToOne(() => Lead, (lead) => lead.merchant, { eager: true })
    lead: Lead;

    @Column({ type: 'boolean', default: false })
    deactivated: boolean;

    @Column({ name: 'automatic_payouts', type: 'boolean', default: true })
    automaticPayouts: boolean;

    @ManyToOne(() => Account, (account) => account.merchants, { lazy: true })
    @JoinColumn({ name: 'account_id' })
    account: Promise<Account>;

    @Column({ type: 'integer', name: 'agent', default: null })
    agent: number | null;

    /**
     * @todo Add IP address
     */
    static create(phoneNumber: CustomPhoneNumber, account: Account, agent?: number): Merchant {
        const merchant = new Merchant();
        merchant.account = Promise.resolve(account);
        merchant.phoneNumber = phoneNumber.getNumber();
        merchant.agent = agent;
        return merchant;
    }

    getId(): string {
        return this.id;
    }

    getSid(): TypeSid<'merchant'> {
        return this.sid;
    }

    getPhoneNumber(): string {
        return this.phoneNumber;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('merchant');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
