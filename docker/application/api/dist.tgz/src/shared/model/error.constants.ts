/**
 * This type represents possible errors related to account operations.
 */
export type AccountErrorCode = 'COULD_NOT_REGISTER_ACCOUNT_ALREADY_EXISTS';

/**
 * OnboardingErrorConstants defines a set of possible error codes that can be encountered during
 * the user onboarding process.
 */
export type OnboardingErrorCode =
    | 'INVALID_OTP_CODE'
    | 'COULD_NOT_SEND_OTP_CODE'
    | 'COULD_NOT_VERIFY_OTP_CODE'
    | 'USER_EXISTS_AND_CANNOT_BE_ONBOARDED'
    | 'IRIS_WEBHOOK_DID_NOT_RETURN_LEAD_ID'
    | 'IRIS_WEBHOOK_DID_NOT_RETURN_EVENT'
    | 'IRIS_DID_NOT_CREATE_A_SIGNATURE'
    | 'INVALID_ACCOUNT'
    | 'INTERNAL_SERVER_ERROR'
    | 'IRIS_WEBHOOK_NO_MERCHANT_FOUND_FOR_LEAD'
    | 'COULD_NOT_CREATE_LEAD_ALREADY_EXISTS'
    | 'COULD_NOT_FIND_USER_FROM_ACCOUNT'
    | 'COULD_NOT_UPLOAD_DOCUMENT_FOR_LEAD'
    | 'LEAD_DOES_NOT_EXIST'
    | 'COULD_NOT_CREATE_USER_EXISTS'
    | 'COULD_NOT_CREATE_LEAD'
    | 'COULD_NOT_PATCH_LEAD'
    | 'AUDIT_TRAIL_ERROR';

export type SignErrorCode = 'ONBOARDING_SIGN_ERROR_ONBOARDING_STATUS_IS_NOT_COMPLETED' | 'ALREADY_SIGNED';

/**
 * This type represents error codes that can occur during document upload.
 */
export type DocumentUploadErrorCode = 'INVALID_DOCUMENT_TYPE' | 'FILE_SIZE_EXCEEDED';

export type DomainErrorCode = 'ERROR' | OnboardingErrorCode | AccountErrorCode | DocumentUploadErrorCode | SignErrorCode;
