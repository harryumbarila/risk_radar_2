import { BeforeInsert, Column, Entity, OneToMany, PrimaryColumn } from 'typeorm';
import { BaseEntity } from './base.entity';
import { SidColumn } from '../typeorm/decorator/sid-column.decorator';
import { TypeSid } from './type-sid';
import { TypeSidFactory } from './sid/type-sid.factory';
import { ApiKeys } from '@/shared/model/account/api-keys';
import { ACCOUNT_MAX_EMAIL_LENGTH, ACCOUNT_MAX_NAME_LENGTH } from '@/shared/model/account/account.const';
import { Merchant } from '@/shared/model/merchant.entity';
import { Webhook } from '@/webhook/webhook.entity';

@Entity({ name: 'accounts' })
export class Account extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('account')
    sid: TypeSid<'account'>;

    @Column({ type: 'varchar', length: ACCOUNT_MAX_NAME_LENGTH, nullable: true })
    name: string;

    @Column({ type: 'varchar', name: 'email', nullable: false, length: ACCOUNT_MAX_EMAIL_LENGTH, unique: true })
    email: string;

    @Column(() => ApiKeys, { prefix: false })
    apiKeys: ApiKeys;

    @OneToMany(() => Merchant, (merchant) => merchant.account, { lazy: true })
    merchants: Promise<Merchant[]>;

    @OneToMany(() => Webhook, (webhook) => webhook.account, { lazy: true })
    webhooks: Promise<Webhook[]>;

    static create(apiKeys: ApiKeys, email: string, name?: string): Account {
        const account = new Account();
        account.email = email.toLowerCase();
        account.name = name;
        account.apiKeys = apiKeys;

        return account;
    }

    getId(): string {
        return this.id;
    }

    getSid(): TypeSid<'account'> {
        return this.sid;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('account');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
