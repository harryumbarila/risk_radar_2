import { parsePhoneNumber, PhoneNumber } from 'libphonenumber-js';

export class CustomPhoneNumber {
    private phoneNumber: PhoneNumber;

    constructor(phoneNumberAsString: string) {
        const parsedPhoneNumber = parsePhoneNumber(phoneNumberAsString, 'US');

        if (!parsedPhoneNumber) {
            throw new Error('Invalid phone number');
        }

        this.phoneNumber = parsedPhoneNumber;
    }

    /**
     * Converts the phone number to a string representation in the format of E.164.
     *
     * @return {string} The string representation of the phone number.
     */
    public toString(): string {
        return this.phoneNumber.format('E.164');
    }

    /**
     * Returns the national number of the phone number. Without +
     *
     * @returns {string} The national number of the phone number.
     */
    public getNumber(): string {
        return this.phoneNumber.countryCallingCode + this.phoneNumber.nationalNumber;
    }

    /**
     * Formats the phone number with dashes for US country ex. 111-111-1111
     *
     * @throws {Error} If the phone number country is not US.
     * @return {string} The formatted phone number with dashes.
     */
    public formatWithDashesForUs(): string {
        if (this.phoneNumber.country !== 'US') {
            throw new Error('Phone number is not US and cannot be formatted');
        }

        let phone = this.phoneNumber.nationalNumber;
        return phone.substring(0, 3) + '-' + phone.substring(3, 6) + '-' + phone.substring(6, 10);
    }
}
