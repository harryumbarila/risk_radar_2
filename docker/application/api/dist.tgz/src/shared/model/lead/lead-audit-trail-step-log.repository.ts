import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';

@Injectable()
export class LeadAuditTrailStepLogRepository extends Repository<LeadAuditTrailStepLog> {
    constructor(dataSource: DataSource) {
        super(LeadAuditTrailStepLog, dataSource.createEntityManager());
    }
}
