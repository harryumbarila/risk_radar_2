import { BaseEntity } from '@/shared/model/base.entity';
import { Entity, Column, PrimaryColumn, BeforeInsert, Index } from 'typeorm';
import { SidColumn } from '@/shared/typeorm/decorator/sid-column.decorator';
import { TypeSid } from '@/shared/model/type-sid';
import { Order, Orderable } from 'typeorm-orderable';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';

@Orderable()
@Entity('lead_audit_trail_step_logs')
@Index(['createdAt'])
@Index(['leadSignatureId'])
export class LeadAuditTrailStepLog extends BaseEntity {
    @Order({ priority: -1 })
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @Order({ priority: -1 })
    @SidColumn('lat')
    sid: TypeSid<'lat'>;

    @Column({ name: 'endpoint', type: 'varchar', length: 255 })
    endpoint: string;

    @Column({ name: 'step_name', type: 'varchar', length: 255 })
    stepName: string;

    /**
     * Full owner name including email
     */
    @Column({ name: 'owner_name', type: 'text', nullable: true })
    ownerName?: string;

    @Column({ type: 'timestamp' })
    timestamp: Date;

    @Column({ name: 'ip_address', type: 'varchar', length: 45 })
    ipAddress: string;

    @Column({ name: 'merchant_id', type: 'varchar', length: 36 })
    merchantId: string;

    @Column({ name: 'lead_sid', type: 'varchar', length: 36 })
    leadSid: string;

    @Column({ name: 'merchant_sid', type: 'varchar', length: 36 })
    merchantSid: string;

    @Column({ name: 'lead_signature_id', type: 'varchar', length: 36, nullable: true })
    leadSignatureId: string;

    @Column({ name: 'device_browser', type: 'varchar', length: 255 })
    deviceBrowser: string;

    @Column({ name: 'request_id', type: 'varchar', length: 255 })
    requestId: string;

    @Column({ name: 'email_status', type: 'varchar', length: 255, nullable: true })
    emailStatus?: 'sent' | 'failed_to_send';

    @Column({ name: 'email_recipient', type: 'varchar', length: 255, nullable: true })
    emailRecipient?: string;

    public static create(dto: AuditTrailLeadStepLogDto): LeadAuditTrailStepLog {
        const leadAuditTrailStepLogs = new LeadAuditTrailStepLog();

        leadAuditTrailStepLogs.stepName = dto.getStepName();
        leadAuditTrailStepLogs.ipAddress = dto.getIpAddress();
        leadAuditTrailStepLogs.merchantId = dto.getMerchantId();
        leadAuditTrailStepLogs.merchantSid = dto.getMerchantSid();
        leadAuditTrailStepLogs.deviceBrowser = dto.getDeviceBrowser();
        leadAuditTrailStepLogs.endpoint = dto.getEndpoint();
        leadAuditTrailStepLogs.leadSid = dto.getLeadSid();
        leadAuditTrailStepLogs.timestamp = new Date();
        leadAuditTrailStepLogs.requestId = dto.getRequestId();
        leadAuditTrailStepLogs.emailStatus = dto.getEmailStatus();
        leadAuditTrailStepLogs.emailRecipient = dto.getEmailRecipient();
        leadAuditTrailStepLogs.ownerName = dto.getOwnerName()?.toString() ?? undefined;
        leadAuditTrailStepLogs.leadSignatureId = dto.getLeadSignatureId()?.toString() ?? undefined;

        return leadAuditTrailStepLogs;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('lat');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
