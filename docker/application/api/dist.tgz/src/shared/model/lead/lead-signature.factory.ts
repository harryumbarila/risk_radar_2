import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { Lead } from '@/shared/model/lead.entity';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { PDFService } from '@/shared/pdf/pdf.service';
import { Readable } from 'stream';
import { Inject, Injectable } from '@nestjs/common';
import { Merchant } from '@/shared/model/merchant.entity';
import { IrisMapper, IrisMapperConfig } from '@/shared/irisMappings/iris-mapper';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { mpaPdfFieldMappings as stagingMpaPdfFieldMappings } from '@/shared/irisMappings/mpa-pdf-mappings-staging';
import { mpaPdfFieldMappings as productionMpaPdfFieldMappings } from '@/shared/irisMappings/mpa-pdf-mappings-production';
import { ConfigService } from '@nestjs/config';
import { PDFTemplatesService } from '@/shared/pdf/templates.service';

@Injectable()
// eslint-disable-next-line @darraghor/nestjs-typed/injectable-should-be-provided
export class LeadSignatureFactory {
    private readonly mpaPdfFieldMap: Record<string, string>;

    constructor(
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly pDFService: PDFService,
        private readonly pdfTemplatesService: PDFTemplatesService,
        private readonly irisMapper: IrisMapper,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        configService: ConfigService<IrisMapperConfig>,
    ) {
        const keysEnv = configService.get('IRIS_MAPPING_KEYS_ENV');
        this.mpaPdfFieldMap = keysEnv === 'staging' ? stagingMpaPdfFieldMappings : productionMpaPdfFieldMappings;
    }
    async create(merchant: Merchant, lead: Lead, leadData: PublicLeadDto): Promise<LeadSignature> {
        if (!leadData.owner_one) {
            throw new Error('Owner One is required');
        }

        // generate the template the same for all owners
        const file = await this.pdfTemplatesService.getTemplate();

        // Convert the S3 response into a buffer
        const templateBuffer = await new Promise<Buffer>((resolve, reject) => {
            const chunks: Uint8Array[] = [];
            const stream = file.Body as Readable;
            stream.on('data', (chunk) => {
                chunks.push(chunk);
            });
            stream.on('end', () => {
                resolve(Buffer.concat(chunks));
            });
            stream.on('error', (err) => {
                reject(err);
            });
        });

        // Parse iris data to a flat object that pdf service can use
        const rawIrisData = await this.irisClient.getLead(lead.leadId);
        const leadFlatData = this.irisMapper.flatIrisData(rawIrisData);

        const pdfData = Object.entries(this.mpaPdfFieldMap).reduce((acc, [key, value]) => {
            const irisValue = leadFlatData[value];
            if (irisValue) {
                acc[key] = irisValue;
            }

            return acc;
        }, {});

        const filled = await this.pDFService.fillFromTemplate(templateBuffer, pdfData);

        const filename = merchant.sid.toString() + '/' + lead.sid.toString() + '.pdf';

        const uploadResult = await this.pdfTemplatesService.upload(filled, filename);

        const ownerLeadSignature = await this.leadSignatureRepository.save(
            LeadSignature.create(
                lead,
                true,
                leadData.owner_one.first_name + ' ' + leadData.owner_one.last_name,
                leadData.owner_one.email,
                uploadResult.key,
                uploadResult.url,
                1,
            ),
        );

        if (leadData.owner_two && leadData.owner_two.email) {
            await this.leadSignatureRepository.save(
                LeadSignature.create(
                    lead,
                    false,
                    leadData.owner_two.first_name + ' ' + leadData.owner_two.last_name,
                    leadData.owner_two.email,
                    uploadResult.key,
                    uploadResult.url,
                    2,
                ),
            );
        }

        if (leadData.owner_three && leadData.owner_three.email) {
            await this.leadSignatureRepository.save(
                LeadSignature.create(
                    lead,
                    false,
                    leadData.owner_three.first_name + ' ' + leadData.owner_three.last_name,
                    leadData.owner_three.email,
                    uploadResult.key,
                    uploadResult.url,
                    3,
                ),
            );
        }

        if (leadData.owner_four && leadData.owner_four.email) {
            await this.leadSignatureRepository.save(
                LeadSignature.create(
                    lead,
                    false,
                    leadData.owner_four.first_name + ' ' + leadData.owner_four.last_name,
                    leadData.owner_four.email,
                    uploadResult.key,
                    uploadResult.url,
                    4,
                ),
            );
        }

        return ownerLeadSignature;
    }
}
