import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { Lead } from '../lead.entity';

@Injectable()
export class LeadRepository extends Repository<Lead> {
    constructor(dataSource: DataSource) {
        super(Lead, dataSource.createEntityManager());
    }
}
