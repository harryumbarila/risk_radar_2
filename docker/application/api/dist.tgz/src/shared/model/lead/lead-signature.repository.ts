import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';

@Injectable()
export class LeadSignatureRepository extends Repository<LeadSignature> {
    constructor(dataSource: DataSource) {
        super(LeadSignature, dataSource.createEntityManager());
    }
}
