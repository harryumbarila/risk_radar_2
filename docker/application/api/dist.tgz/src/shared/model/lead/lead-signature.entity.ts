import { BaseEntity } from '@/shared/model/base.entity';
import { Entity, Column, PrimaryColumn, BeforeInsert, JoinColumn, ManyToOne } from 'typeorm';
import { SidColumn } from '@/shared/typeorm/decorator/sid-column.decorator';
import { TypeSid } from '@/shared/model/type-sid';
import { Order, Orderable } from 'typeorm-orderable';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import { Lead } from '@/shared/model/lead.entity';

@Orderable()
@Entity('lead_signatures')
export class LeadSignature extends BaseEntity {
    @Order({ priority: -1 })
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @Order({ priority: -1 })
    @SidColumn('lss')
    sid: TypeSid<'lss'>;

    @Column({ name: 'signed_at', type: 'timestamp', nullable: true })
    signedAt?: Date;

    @Column({ name: 'signed_ip_address', type: 'varchar', length: 45, nullable: true })
    signedIpAddress?: string;

    @Column({ name: 'signed_device_browser', type: 'varchar', length: 255, nullable: true })
    signedDeviceBrowser?: string;

    @ManyToOne(() => Lead, (lead) => lead.leadSignatures, { eager: true })
    @JoinColumn({ name: 'lead_id' })
    lead: Lead;

    @Column({ name: 'owner', type: 'boolean' })
    owner: boolean;

    @Column({ name: 'owner_number', type: 'int', nullable: true })
    ownerNumber: number;

    @Column({ name: 'signature_name', type: 'varchar', length: 255, nullable: false })
    signatureName: string;

    @Column({ name: 'signature_email', type: 'varchar', length: 320, nullable: false })
    signatureEmail: string;

    @Column({ name: 'contract_template_url', type: 'varchar', length: 255, nullable: false })
    contractTemplateUrl: string;

    @Column({ name: 'contract_template_key', type: 'varchar', length: 255, nullable: false })
    contractTemplateKey: string;

    @Column({ name: 'signed_contract_key', type: 'varchar', length: 255, nullable: true })
    signedContractKey: string;

    @Column({ name: 'signed_contract_url', type: 'varchar', length: 255, nullable: true })
    signedContractUrl: string;

    public static create(
        lead: Lead,
        owner: boolean,
        signatureName: string,
        signatureEmail: string,
        contractTemplateKey: string,
        contractTemplateUrl: string,
        ownerNumber: number,
    ): LeadSignature {
        const leadSignature = new LeadSignature();
        leadSignature.lead = lead;
        leadSignature.owner = owner;
        leadSignature.signatureName = signatureName;
        leadSignature.signatureEmail = signatureEmail;
        leadSignature.contractTemplateKey = contractTemplateKey;
        leadSignature.contractTemplateUrl = contractTemplateUrl;
        leadSignature.ownerNumber = ownerNumber;
        return leadSignature;
    }

    sign(key: string, url: string, signedIpAddress: string, signedDeviceBrowser: string): void {
        this.signedAt = new Date();
        this.signedContractKey = key;
        this.signedContractUrl = url;
        this.signedIpAddress = signedIpAddress;
        this.signedDeviceBrowser = signedDeviceBrowser;
    }

    isSigned(): boolean {
        return !!this.signedAt;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('lss');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
