// IRIS Webhook Body Interface

export interface WebhookBody {
    data?: {
        lead?: {
            id?: number;
            newStatus?: {
                id?: number;
                name?: string;
            };
        };
        signatures?: Array<{
            lead?: {
                id?: number;
            };
        }>;
        accounts?: Array<{
            id: number;
            dba: string;
            lid: number;
            mid: string;
        }>;
    };
    hook?: {
        event?: string;
    };
}
