import { DomainErrorCode } from '@/shared/model/error.constants';

/**
 * Represents a known error in the application.
 */
export class DomainError<T extends DomainErrorCode> extends Error {
    name: T;
    message: string;
    cause: any;

    constructor({ name, message, cause }: { name: T; message: string; cause?: any }) {
        super();
        this.name = name;
        this.message = message;
        this.cause = cause;
    }
}
