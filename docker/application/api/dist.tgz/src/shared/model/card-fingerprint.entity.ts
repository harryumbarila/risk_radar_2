import { BeforeInsert, Column, Entity, Index, PrimaryColumn } from 'typeorm';
import { BaseEntity } from '@/shared/model/base.entity';
import { SidColumn } from '@/shared/typeorm/decorator/sid-column.decorator';
import { TypeSid } from '@/shared/model/type-sid';
import { TypeSidFactory } from '@/shared/model/sid/type-sid.factory';
import { FundingType } from '@/shared/model/card-fingerprint/funding-type.enum';

@Entity({ name: 'card_fingerprints' })
export class CardFingerprint extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('cf')
    sid: TypeSid<'cf'>;

    @Index()
    @Column({ type: 'varchar', name: 'token', length: 200 })
    token: string;

    @Column({ type: 'varchar', name: 'fingerprint', length: 200 })
    fingerprint: string;

    @Column({
        type: 'enum',
        enum: FundingType,
        default: FundingType.UNKNOWN,
        name: 'funding',
    })
    public funding: FundingType;

    static create(token: string, fingerprint: string, funding: FundingType = FundingType.UNKNOWN): CardFingerprint {
        const cardFingerprint = new CardFingerprint();
        cardFingerprint.token = token;
        cardFingerprint.fingerprint = fingerprint;
        cardFingerprint.funding = funding;
        return cardFingerprint;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('cf');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
