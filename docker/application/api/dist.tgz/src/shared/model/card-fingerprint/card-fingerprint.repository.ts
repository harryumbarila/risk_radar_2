import { DataSource, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { CardFingerprint } from '@/shared/model/card-fingerprint.entity';

@Injectable()
export class CardFingerprintRepository extends Repository<CardFingerprint> {
    constructor(dataSource: DataSource) {
        super(CardFingerprint, dataSource.createEntityManager());
    }
}
