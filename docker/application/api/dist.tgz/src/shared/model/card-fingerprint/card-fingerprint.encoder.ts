import { createHmac } from 'crypto';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';

export interface CardFingerprintEncoderConfig {
    ACCOUNT_SECRET_API_KEY_PREFIX: string;
}

@Injectable()
export class CardFingerprintEncoder {
    constructor(private readonly configService: ConfigService<CardFingerprintEncoderConfig>) {}

    private static readonly HASH_ALGORITHM = 'sha256';

    // Method to create a fingerprint for a given card number (PAN)
    encode(pan: string): string {
        if (!pan) {
            throw new Error('PAN (card number) must be provided');
        }

        const secretApiKeyPrefix = this.configService.get<string>('ACCOUNT_SECRET_API_KEY_PREFIX');

        // Create a hash of the PAN and random identifier
        return this.hashToString(pan, secretApiKeyPrefix);
    }

    private hashToString(data: string, secretKey: string): string {
        return createHmac(CardFingerprintEncoder.HASH_ALGORITHM, secretKey).update(data).digest('hex');
    }
}
