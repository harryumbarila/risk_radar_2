export enum FundingType {
    CREDIT = 'credit',
    DEBIT = 'debit',
    PREPAID = 'prepaid',
    UNKNOWN = 'unknown',
}

export namespace FundingType {
    export function parse(funding: string): FundingType {
        const fundingType = funding as FundingType;

        if (fundingType === undefined) {
            return FundingType.UNKNOWN;
        }

        return fundingType;
    }
}
