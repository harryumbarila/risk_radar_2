import { BeforeInsert, Column, Entity, JoinColumn, OneToMany, OneToOne, PrimaryColumn } from 'typeorm';
import { BaseEntity } from './base.entity';
import { Merchant } from './merchant.entity';
import { SidColumn } from '../typeorm/decorator/sid-column.decorator';
import { TypeSid } from './type-sid';
import { TypeSidFactory } from './sid/type-sid.factory';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';

/**
 * Enumeration representing the various statuses of an onboarding process.
 *
 * - NOT_STARTED: The onboarding process has not yet started.
 * - IN_PROGRESS: The onboarding process is currently in progress. Onboarding application was created
 * - COMPLETED: The onboarding process has been completed but not yet signed by all owners - just the first one.
 * - APPROVED: The onboarding process has been approved.
 * - FAILED: The onboarding process has failed.
 */
export enum OnboardingStatus {
    NOT_STARTED = 'NOT_STARTED',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    APPROVED = 'APPROVED',
    FAILED = 'FAILED',
}

@Entity({ name: 'leads' })
export class Lead extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', length: 36 })
    id: string;

    @SidColumn('lead')
    sid: TypeSid<'lead'>;

    @Column({ type: 'integer', name: 'lead_id' })
    leadId: number;

    @Column({ type: 'enum', enum: OnboardingStatus, name: 'onboarding_status' })
    onboardingStatus: OnboardingStatus;

    @Column({ type: 'jsonb', name: 'data' })
    data: string;

    @OneToOne(() => Merchant)
    @JoinColumn({ name: 'merchant_id' })
    merchant: Merchant;

    @OneToMany(() => LeadSignature, (leadSignature) => leadSignature.lead, { lazy: true })
    leadSignatures: Promise<LeadSignature[]>;

    static create(merchant: Merchant, leadId: number, status: OnboardingStatus, data: string): Lead {
        const lead: Lead = new Lead();
        lead.leadId = leadId;
        lead.merchant = merchant;
        lead.onboardingStatus = status;
        lead.data = data;
        return lead;
    }

    getId(): number {
        return this.leadId;
    }

    getStatus(): OnboardingStatus {
        return this.onboardingStatus;
    }

    getData(): string {
        return this.data;
    }

    @BeforeInsert()
    generateIdAndSid() {
        if (!this.sid) {
            this.sid = TypeSidFactory.createFromPrefix('lead');
        }

        if (!this.id) {
            this.id = this.sid.toUUID();
        }
    }
}
