import { ConfigModule, ConfigService } from '@nestjs/config';
import { SlackAsyncConfig } from 'nestjs-slack/dist/types';

export const slackConfigAsync = {
    imports: [ConfigModule],
    inject: [ConfigService],
    useFactory: (configService: ConfigService) => ({
        type: 'webhook',
        channels: [
            {
                name: <string>configService.get<string>('SLACK_WEBHOOK_ONBOARDING_CHANNEL_NAME'),
                url: <string>configService.get<string>('SLACK_WEBHOOK_ONBOARDING_CHANNEL_URL'),
            },
        ],
    }),
} as SlackAsyncConfig;
