import { JwtModuleOptions } from '@nestjs/jwt/dist/interfaces/jwt-module-options.interface';

export const jwtConfig = {
    global: true,
    signOptions: { expiresIn: '30d' },
} as JwtModuleOptions;
