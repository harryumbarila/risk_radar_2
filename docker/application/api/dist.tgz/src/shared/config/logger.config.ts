import { randomUUID } from 'crypto';
import { RequestMethod } from '@nestjs/common';
import { Params } from 'nestjs-pino/params';

export const loggerConfig = {
    pinoHttp: {
        formatters: {
            level: (label) => {
                return { level: label.toUpperCase() };
            },
        },
        // Define a custom request id function
        genReqId: function (req, res) {
            const existingID = req.id ?? req.headers['x-request-id'];
            if (existingID) return existingID;
            const id = randomUUID();
            res.setHeader('X-Request-Id', id);
            return id;
        },
        transport:
            process.env.NODE_ENV !== 'production'
                ? {
                      target: 'pino-pretty',
                      options: {
                          singleLine: true,
                      },
                  }
                : undefined,
        customLogLevel: (res, err) => {
            if (process.env.NODE_ENV === 'production' && (res.statusCode === 404 || err.statusCode === 404)) {
                return 'silent'; // Skip logging for 404
            }

            if (err && err.statusCode >= 400 && err.statusCode < 500) {
                return 'warn';
            }

            if (err && err.statusCode >= 500) {
                return 'error';
            }

            if (res.statusCode >= 500) {
                return 'error';
            }

            if (res.statusCode >= 400) {
                return 'warn';
            }

            return 'info';
        },
    },
    exclude: [{ path: '/', method: RequestMethod.GET }],
} as Params;
