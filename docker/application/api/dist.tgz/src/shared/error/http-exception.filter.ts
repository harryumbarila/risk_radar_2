import { ExceptionFilter, Catch, ArgumentsHost, HttpException } from '@nestjs/common';
import { Response } from 'express';
import * as Sentry from '@sentry/nestjs';

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
    catch(exception: HttpException, host: ArgumentsHost) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse<Response>();
        const request = ctx.getRequest();
        const status = exception.getStatus();
        const requestId = response.getHeader('x-request-id');

        let responseMessage: string | string[] = exception.message;

        if (status === 400) {
            const exceptionResponse = exception.getResponse();
            if (typeof exceptionResponse === 'object' && exceptionResponse !== null && 'message' in exceptionResponse) {
                responseMessage = exceptionResponse.message as string | string[];
            }
        }

        if (status >= 500) {
            Sentry.withScope((scope) => {
                scope.setTag('request_id', requestId as string);
                scope.setTag('status_code', status.toString());
                scope.setTag('url', request?.url);
                scope.setContext('request', {
                    method: request?.method,
                    url: request?.url,
                    headers: request?.headers,
                });

                Sentry.setUser({
                    id: request?.userEntity?.sid ?? null,
                    phone_number: request?.userEntity?.phoneNumber ?? null,
                    ip_address: request?.ip ?? null,
                });

                Sentry.captureException(exception);
            });
        }

        response.status(status).json({
            statusCode: status,
            message: responseMessage,
            error: exception.name,
            timestamp: new Date().toISOString(),
            request_id: requestId,
        });
    }
}
