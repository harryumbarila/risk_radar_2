import { ArgumentsHost, Catch, ExceptionFilter } from '@nestjs/common';
import { DomainError } from '../model/domain.error';
import { Response } from 'express';

@Catch(DomainError<any>)
export class DomainErrorFilter implements ExceptionFilter {
    catch(exception: DomainError<any>, host: ArgumentsHost) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse<Response>();
        const status = 400;
        const requestId = response.getHeader('x-request-id');

        response.status(status).json({
            statusCode: status,
            message: exception.message,
            error: exception.name,
            timestamp: new Date().toISOString(),
            request_id: requestId,
        });
    }
}
