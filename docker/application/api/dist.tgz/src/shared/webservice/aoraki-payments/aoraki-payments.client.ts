import { ConfigService } from '@nestjs/config';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import axios, { AxiosError, AxiosInstance, AxiosResponse } from 'axios';
import { RequestIdExtractorService } from '@/shared/service/request-id-extractor.service';

export interface AorakiPaymentsClientInterface {
    createAccount(accountSid: string, accountSecret: string): Promise<void>;
    merchantOnboarding(
        accountSid: string,
        accountSecret: string,
        merchantSid: string,
        irisMerchantId: string,
        merchantData: any,
        processorData: any,
    ): Promise<void>;
    merchantCreateTerminal(accountSid: string, accountSecret: string, merchantSid: string): Promise<void>;
    getMerchant(accountSid: string, accountSecret: string, merchantSid: string): Promise<AorakiGetMerchantDTO>;
}

export interface AorakiGetMerchantDTO {
    merchant_sid: string;
    merchant_id: string;
    publishable_key: string;
    terminal_id: string;
}

const encodeBase64 = (username: string, password: string): string => {
    const authString = `${username}:${password}`;
    return Buffer.from(authString).toString('base64');
};

export const AorakiPaymentsSymbolToken = Symbol('AorakiPaymentsSymbolToken');

export interface AorakiPaymentsClientConfig {
    AORAKI_PAYMENTS_URL: string;
    AORAKI_PAYMENTS_API_KEY: string;
}

export class AorakiPaymentsClient implements AorakiPaymentsClientInterface {
    private httpClient: AxiosInstance;

    constructor(
        private configService: ConfigService<AorakiPaymentsClientConfig>,
        private requestIdExtractor: RequestIdExtractorService,
        @InjectPinoLogger(AorakiPaymentsClient.name) private readonly logger: PinoLogger,
    ) {
        const instance = axios.create({
            baseURL: this.configService.get('AORAKI_PAYMENTS_URL'),
        });

        instance.interceptors.request.use((request) => {
            this.logger.info('AXIOS Request: ' + JSON.stringify(request, null, 2));
            return request;
        });

        instance.interceptors.response.use((response) => {
            this.logger.info('AXIOS Response: ' + JSON.stringify(response?.data, null, 2));
            return response;
        });

        this.httpClient = instance;
    }

    async createAccount(accountSid: string, accountSecret: string): Promise<void> {
        try {
            this.logger.info(`Sending request to aoraki payments to create account for ${accountSid}`);
            await this.send('/v1/accounts', {
                account_id: accountSid,
                account_secret: accountSecret,
            });
            this.logger.info(`Account created in aoraki ${accountSid}`);
        } catch (e) {
            this.handleException(e);
        }
    }

    async merchantOnboarding(
        accountSid: string,
        accountSecret: string,
        merchantSid: string,
        irisMerchantId: string,
        merchantData: any,
        processorData: any,
    ): Promise<void> {
        try {
            this.logger.info(`Sending request to aoraki payments for payment onboarding ${merchantSid} for account ${accountSid}`);

            const response = await this.send(
                `/v1/merchants`,
                {
                    merchant_id: merchantSid,
                    iris_merchant_id: irisMerchantId,
                    merchant_data: {
                        merchant_id: merchantSid,
                        ...merchantData,
                    },
                    processor_data: processorData,
                },
                'POST',
                { Authorization: `Basic ${encodeBase64(accountSid, accountSecret)}` },
            );
            this.logger.info(`Payment onboarding response ${JSON.stringify(response.data, null, 2)}`);
            this.logger.info(`Merchant onboarded in aoraki ${merchantSid}`);
        } catch (e) {
            this.handleException(e);
        }
    }

    async merchantCreateTerminal(accountSid: string, accountSecret: string, merchantSid: string): Promise<void> {
        try {
            this.logger.info(`Sending request to aoraki payments for merchant ${merchantSid} to create terminal - account ${accountSid}`);

            const response = await this.send(`/v1/merchants/${merchantSid}/terminals`, {}, 'POST', {
                Authorization: `Basic ${encodeBase64(accountSid, accountSecret)}`,
            });
            this.logger.info(`Payment onboarding response ${JSON.stringify(response.data, null, 2)}`);
            this.logger.info(`Merchant new terminal created in aoraki ${merchantSid}`);
        } catch (e) {
            this.handleException(e);
        }
    }

    async getMerchant(accountSid: string, accountSecret: string, merchantSid: string): Promise<AorakiGetMerchantDTO> {
        try {
            this.logger.info(`Sending request to aoraki payments to get merchant ${merchantSid} - account ${accountSid}`);

            const response = await this.send(`/v1/merchants/${merchantSid}`, {}, 'GET', {
                Authorization: `Basic ${encodeBase64(accountSid, accountSecret)}`,
            });

            return response.data as AorakiGetMerchantDTO;
        } catch (e) {
            this.handleException(e);
        }
    }

    private async send(
        endpoint: string,
        data: {},
        method: 'GET' | 'POST' = 'GET',
        additionalHeaders: Record<string, string> = {},
    ): Promise<AxiosResponse<any>> {
        const requestId = this.requestIdExtractor.getRequestId();
        const options = {
            headers: {
                'content-type': 'application/json',
                'aoraki-api-key': this.configService.get('AORAKI_PAYMENTS_API_KEY'),
                'request-id': requestId,
                'x-request-id': requestId,
                ...additionalHeaders,
            },
        };

        return method === 'POST' ? this.httpClient.post(endpoint, data, options) : this.httpClient.get(endpoint, options);
    }

    private handleException(e: any) {
        this.logger.error('Response failed due to ' + e.message);

        if (e instanceof AxiosError) {
            this.logger.error('Response error message ' + e.response?.data ? JSON.stringify(e.response.data) : e.response?.statusText);
        }

        throw e;
    }
}
