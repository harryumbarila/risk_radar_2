import { Injectable } from '@nestjs/common';
import { SlackService } from 'nestjs-slack';
import { ConfigService } from '@nestjs/config';
import { SlackInterface } from '@/shared/webservice/slack/slack.interface';

interface SlackClientConfig {
    SLACK_WEBHOOK_ONBOARDING_CHANNEL_NAME: string;
}

@Injectable()
export class SlackClient implements SlackInterface {
    private readonly companyOnboardingChannel: string;

    constructor(
        private slackService: SlackService,
        configService: ConfigService<SlackClientConfig>,
    ) {
        this.companyOnboardingChannel = <string>configService.get<string>('SLACK_WEBHOOK_ONBOARDING_CHANNEL_NAME');
    }

    postOnOnboarding(text: string): Promise<void> {
        return this.slackService.sendText(text, {
            channel: this.companyOnboardingChannel,
        });
    }
}
