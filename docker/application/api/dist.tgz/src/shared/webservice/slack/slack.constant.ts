export const SlackSymbolToken = Symbol('SlackSymbolToken');
