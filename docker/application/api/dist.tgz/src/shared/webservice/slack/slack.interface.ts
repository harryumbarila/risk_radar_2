export interface SlackInterface {
    postOnOnboarding(text: string): Promise<void>;
}
