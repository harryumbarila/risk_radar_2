import { ConfigService } from '@nestjs/config';
import { SendEmailCommand, SendEmailCommandOutput, SESClient } from '@aws-sdk/client-ses';
import { EmailClientInterface } from '@/shared/webservice/email/email.client.interface';
import { EmailMessage } from '@/shared/webservice/email/email-message';
import { EmailResponse } from '@/shared/webservice/email/email-response';
import { Injectable } from '@nestjs/common';

export interface AWSSesClientConfig {
    AWS_REGION: string;
    AWS_SES_SENDER_EMAIL_ADDRESS: string;
}

@Injectable()
// eslint-disable-next-line @darraghor/nestjs-typed/injectable-should-be-provided
export class AwsSesClient implements EmailClientInterface {
    constructor(private readonly configService: ConfigService<AWSSesClientConfig>) {}

    async send(email: EmailMessage): Promise<EmailResponse> {
        const createSendEmailCommand = (toAddress: string, fromAddress: string) => {
            return new SendEmailCommand({
                Destination: {
                    ToAddresses: [toAddress],
                },
                Message: {
                    /* required */
                    Body: {
                        /* required */
                        Html: {
                            Charset: 'UTF-8',
                            Data: email.body,
                        },
                    },
                    Subject: {
                        Charset: 'UTF-8',
                        Data: email.subject,
                    },
                },
                Source: fromAddress,
                ReplyToAddresses: [this.configService.get('AWS_SES_SENDER_EMAIL_ADDRESS')],
            });
        };

        const run = async () => {
            const sendEmailCommand = createSendEmailCommand(email.to, <string>this.configService.get('AWS_SES_SENDER_EMAIL_ADDRESS'));

            try {
                const sesClient = new SESClient({ region: this.configService.get('AWS_REGION') });
                return sesClient.send(sendEmailCommand);
            } catch (caught) {
                if (caught instanceof Error && caught.name === 'MessageRejected') {
                    return caught;
                }

                throw caught;
            }
        };

        const response: SendEmailCommandOutput | Error = await run();

        return 'MessageId' in response ? { status: 'sent' } : { status: 'failed_to_send', error: (response as Error).message };
    }
}
