import { EmailMessage } from '@/shared/webservice/email/email-message';
import { EmailResponse } from '@/shared/webservice/email/email-response';

export interface EmailClientInterface {
    send(email: EmailMessage): Promise<EmailResponse>;
}
