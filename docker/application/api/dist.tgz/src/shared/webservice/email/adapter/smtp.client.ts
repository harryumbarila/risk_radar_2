import * as nodemailer from 'nodemailer';
import { ConfigService } from '@nestjs/config';
import { EmailClientInterface } from '@/shared/webservice/email/email.client.interface';
import { EmailMessage } from '../email-message';
import { EmailResponse } from '../email-response';
import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';

export interface SmtpClientConfig {
    SMTP_HOST: string;
    SMTP_PORT: number;
    SMTP_SECURE: boolean;
    SMTP_USER: string;
    SMTP_PASSWORD: string;
    SMTP_FROM_EMAIL: string;
}

@Injectable()
export class SmtpClient implements EmailClientInterface {
    private transporter: nodemailer.Transporter;

    constructor(
        @InjectPinoLogger(SmtpClient.name) private readonly logger: PinoLogger,
        private readonly configService: ConfigService<SmtpClientConfig>,
    ) {}

    async send(email: EmailMessage): Promise<EmailResponse> {
        // Configure SMTP with Nodemailer
        if (!this.transporter) {
            this.transporter = nodemailer.createTransport({
                host: this.configService.get<string>('SMTP_HOST'), // e.g., 'smtp.gmail.com'
                port: this.configService.get<number>('SMTP_PORT'), // e.g., 465 for secure connections
                secure: false, // true for 465, false for other ports
                auth: {
                    user: this.configService.get<string>('SMTP_USER'), // SMTP username
                    pass: this.configService.get<string>('SMTP_PASSWORD'), // SMTP password
                },
            });
        }

        try {
            const { to, subject, body } = email;

            const senderEmail = this.configService.get<string>('SMTP_FROM_EMAIL'); // Sender email address
            await this.transporter.sendMail({
                from: senderEmail, // 'Sender Name <sender@example.com>'
                to,
                subject,
                html: body, // You can alternatively use `text` for plain text emails
            });
            return { status: 'sent' };
        } catch (error) {
            this.logger.error(`Failed to send email ${error.message}`);
            return { status: 'failed_to_send', error: error.message };
        }
    }
}
