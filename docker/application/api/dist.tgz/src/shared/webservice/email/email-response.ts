export class EmailResponse {
    status: 'sent' | 'failed_to_send';
    error?: string;
}
