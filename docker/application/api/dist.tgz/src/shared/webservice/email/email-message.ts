export class EmailMessage {
    to: string;
    subject: string;
    body: string;
    context: { [key: string]: string };
    attachments?: any;
}
