import { OtpCodeResponse } from './response/otp-code.response';
import { CustomPhoneNumber } from '../../model/custom-phone-number';

export interface TwilioClientInterface {
    sendOtpCode(phoneNumber: CustomPhoneNumber): Promise<OtpCodeResponse>;
    verifyOtpCode(phoneNumber: CustomPhoneNumber, otpCode: string): Promise<OtpCodeResponse>;
}
