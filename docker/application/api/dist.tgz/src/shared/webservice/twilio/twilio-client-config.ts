export interface TwilioClientConfig {
    TWILIO_ACCOUNT_SID: string;
    TWILIO_AUTH_TOKEN: string;
    TWILIO_VERIFY_SERVICE_TOKEN: string;
}
