import { DomainError } from '../../../model/domain.error';
import { OnboardingErrorCode } from '@/shared/model/error.constants';

export class TwilioError extends DomainError<OnboardingErrorCode> {}

export class CouldNotSendOtpCodeError extends TwilioError {
    public static create(): TwilioError {
        return new this({
            name: 'COULD_NOT_SEND_OTP_CODE',
            message: `Could not send otp code due internal error`,
        });
    }
}

export class CouldNotVerifyOtpCodeError extends TwilioError {
    public static create(): TwilioError {
        return new this({
            name: 'COULD_NOT_VERIFY_OTP_CODE',
            message: `Could verify otp code due internal error`,
        });
    }
}
