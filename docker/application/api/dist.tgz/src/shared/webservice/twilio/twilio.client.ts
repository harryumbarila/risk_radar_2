import { Injectable } from '@nestjs/common';
import { TwilioClientInterface } from './twilio-client.interface';
import { Twilio } from 'twilio';
import { ConfigService } from '@nestjs/config';
import { TwilioClientConfig } from './twilio-client-config';
import { OtpCodeResponse } from './response/otp-code.response';
import { CouldNotSendOtpCodeError, CouldNotVerifyOtpCodeError } from './error/twilio.error';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import parsePhoneNumber, { PhoneNumber } from 'libphonenumber-js';
import { NumberFormat } from 'libphonenumber-js/types';
import { CustomPhoneNumber } from '../../model/custom-phone-number';

@Injectable()
export class TwilioClient implements TwilioClientInterface {
    private readonly twilioClient: Twilio;
    private readonly twilioVerifyServicesToken: string;

    constructor(
        private configService: ConfigService<TwilioClientConfig>,
        @InjectPinoLogger(TwilioClient.name) private readonly logger: PinoLogger,
    ) {
        const accountSid = this.configService.get('TWILIO_ACCOUNT_SID');
        const authToken = this.configService.get('TWILIO_AUTH_TOKEN');
        this.twilioVerifyServicesToken = this.configService.get('TWILIO_VERIFY_SERVICE_TOKEN');
        this.twilioClient = new Twilio(accountSid, authToken);
    }

    async sendOtpCode(phoneNumber: CustomPhoneNumber): Promise<OtpCodeResponse> {
        try {
            this.logger.info(`Twilio sending verify otp to ${phoneNumber}`);
            const result: OtpCodeResponse = (await this.twilioClient.verify.v2
                .services(this.twilioVerifyServicesToken)
                .verifications.create({
                    to: phoneNumber.toString(),
                    channel: 'sms',
                })) as unknown as OtpCodeResponse;
            this.logger.info(`Twilio otp code sent status: ${result.status}`);
            return result;
        } catch (e) {
            this.logger.error(e.message);
            throw CouldNotSendOtpCodeError.create();
        }
    }

    async verifyOtpCode(phoneNumber: CustomPhoneNumber, otpCode: string): Promise<OtpCodeResponse> {
        try {
            this.logger.info(`Twilio verifying otp ${otpCode} to ${phoneNumber}`);
            return (await this.twilioClient.verify.v2.services(this.twilioVerifyServicesToken).verificationChecks.create({
                to: phoneNumber.toString(),
                code: otpCode,
            })) as unknown as OtpCodeResponse;
        } catch (e) {
            this.logger.error(e.message);
            throw CouldNotVerifyOtpCodeError.create();
        }
    }
}
