/**
 * Represents the response of an OTP code verification request. Used in sending and verifying otp code
 */
export interface OtpCodeResponse {
    /**
     * The phone number or [email](https://www.twilio.com/docs/verify/email) being verified. Phone numbers must be in [E.164 format](https://www.twilio.com/docs/glossary/what-e164).
     */
    to: string;

    /**
     * The status of the verification. One of: `pending`, `approved`, or `canceled`
     */
    status: string;

    /**
     * If true code is valid
     */
    valid: boolean;
}
