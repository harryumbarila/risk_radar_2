import { CheckDuplicateLeadDto } from '@/onboarding/request/check-duplicate-lead.dto';
import { IrisCheckDuplicatedLeadRequestDto } from '@/shared/webservice/iris/request/iris-check-duplicated-lead.request.dto';

export class IrisCheckDuplicatedLeadRequestMapper {
    static to(dto: CheckDuplicateLeadDto): IrisCheckDuplicatedLeadRequestDto {
        const [line_1, line_2] = dto.dba_address.address.split(',');

        return {
            legal_name: dto.legal_business_name,
            dba_name: dto.doing_business_as,
            dba_address: {
                line_1: line_1,
                line_2: line_2,
                city: dto.dba_address.city,
                state: dto.dba_address.state,
                zip: dto.dba_address.zip,
            },
            owner: {
                email: dto.owner.email,
                first_name: dto.owner.first_name,
                last_name: dto.owner.last_name,
            },
            phone_number: dto.legal_phone,
        };
    }
}
