import { DomainError } from '../../model/domain.error';
import { OnboardingErrorCode } from '@/shared/model/error.constants';

export class IrisError extends DomainError<OnboardingErrorCode> {}

export class CouldNotCreateLead extends IrisError {
    public static create(): IrisError {
        return new this({
            name: 'COULD_NOT_CREATE_LEAD',
            message: `Could not create lead`,
        });
    }
}
