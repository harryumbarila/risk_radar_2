export class FieldDto {
    id: string;
    value: string;
}

export class OwnerSignedRequest {
    fields: FieldDto[];
}
