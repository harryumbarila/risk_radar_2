interface Data {
    id: string;
    status: string;
    templateId: string;
    templateName: string;
    url: string;
    created: string | null;
    opened: string | null;
}

export interface CheckSignaturesResponseDto {
    data: Data[];
}
