export class OwnerSignedMapperRequest {
    ownerNumber?: number;
    url?: string;
    allOwnersSigned?: boolean;

    constructor(partial: Partial<OwnerSignedMapperRequest> = {}) {
        Object.assign(this, partial);
    }
}
