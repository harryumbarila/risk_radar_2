import { Injectable } from '@nestjs/common';
import { IrisClientInterface } from './iris-client.interface';
import { ConfigService } from '@nestjs/config';
import { IrisClientConfig } from './iris-client-config';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { CustomPhoneNumber } from '../../model/custom-phone-number';
import { CouldNotCreateLead, IrisError } from './iris.error';
const FormData = require('form-data');
import axios from 'axios';
import * as fs from 'node:fs';
import { CreateSignatureResponseDto } from '@/onboarding/response/create-signature.response.dto';
import { ErrorGeneratingSignature, IntervalServerError } from '@/onboarding/onboarding.error';
import { LeadListDto } from '@/onboarding/response/lead-list.response.dto';
import { CheckDuplicateLeadDto } from '@/onboarding/request/check-duplicate-lead.dto';
import { IrisCheckDuplicatedLeadRequestMapper } from '@/shared/webservice/iris/mapper/iris-check-duplicated-lead.request.mapper';
import { CreateSignatureForLeadRequest } from '@/shared/webservice/iris/request/create-signature-for-lead.request';
import { CheckSignaturesResponseDto } from '@/shared/webservice/iris/response/check-signatures.response.dto';

export interface CreateLeadResponse {
    leadId: number;
    message: string;
}

export interface Option {
    key: string;
    value: string;
}

export interface Options {
    dropdown: Option[];
    tooltip: string;
}

export interface GetLeadFieldsResponse {
    id: number;
    tab: number;
    tabName: string;
    label: string;
    type: string;
    length: number;
    default: string;
    alignment: string;
    searchable: number;
    special: string;
    options: Options;
    order: number;
    readOnly: boolean;
    required: boolean;
}

@Injectable()
export class IrisClient implements IrisClientInterface {
    private readonly apiUrl: string;
    private readonly apiMidUrl: string;
    private readonly apiKey: string;
    private readonly leadId: string;
    private readonly duplicatedLeadsUrl: string;
    private readonly duplicatedLeadUsername: string;
    private readonly duplicatedPassword: string;

    private readonly specialRelationshipId: string;
    private readonly primarySalesPersonId: string;

    // This status number means not processed for IRIS - Prospecting (IRIS)
    private readonly initialApplicationStatus: number;

    private readonly signatureURL: string = '/{lead_id}/signatures/{app_number}/generate';
    private readonly sendSignatureURL: string = '/{lead_id}/signatures/{app_number}/send';
    private readonly applicationTemplateNumber: string;

    private readonly equipmentURL: string = '/{mid}/equipment';

    private readonly documentLabelId: string;
    private readonly documentTabId: string;

    private static readonly signDocumentName: string = 'Talus TSYS-FSP North Application (Signed)';

    constructor(
        private configService: ConfigService<IrisClientConfig>,
        @InjectPinoLogger(IrisClient.name) private readonly logger: PinoLogger,
    ) {
        this.initialApplicationStatus = parseInt(this.configService.get('IRIS_INITIAL_APPLICATION_STATUS'));
        this.apiUrl = this.configService.get('IRIS_LEADS_URL');
        this.apiMidUrl = this.configService.get('IRIS_MERCHANTS_URL');
        this.apiKey = this.configService.get('IRIS_API_KEY');
        this.leadId = this.configService.get('IRIS_ID');
        this.applicationTemplateNumber = this.configService.get('IRIS_APPLICATION_TEMPLATE_NUMBER');
        this.duplicatedLeadsUrl = this.configService.get('DUPLICATED_LEADS_URL');
        this.duplicatedLeadUsername = this.configService.get('DUPLICATED_LEADS_USER');
        this.duplicatedPassword = this.configService.get('DUPLICATED_LEADS_PASSWORD');
        this.specialRelationshipId = this.configService.get('IRIS_CREATE_LEAD_SPECIAL_RELATIONSHIP_ID');
        this.primarySalesPersonId = this.configService.get('IRIS_CREATE_LEAD_PRIMARY_SALESPERSON_ID');
    }

    async createLead(phoneNumber: CustomPhoneNumber): Promise<CreateLeadResponse> {
        try {
            this.logger.info(`Iris Client creating lead ${phoneNumber}`);

            const req = await fetch(this.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
                body: JSON.stringify({
                    status: this.initialApplicationStatus,
                    fields: [
                        {
                            id: `${this.leadId}`,
                            value: phoneNumber.formatWithDashesForUs(),
                            record: 1,
                        },
                        {
                            id: this.specialRelationshipId,
                            value: '8',
                            record: 1,
                        },
                        {
                            id: this.primarySalesPersonId,
                            value: '',
                            record: 1,
                        },
                    ],
                }),
            });

            const status = req.status;
            const data = await req.text();

            if (status !== 200) {
                throw new Error(`Iris did not create the lead, error: ${data}`);
            }

            const JSONData = JSON.parse(data);
            const leadId = JSONData.leadId as number;
            const message = JSONData.message as string;
            this.logger.info(`Iris created lead ${leadId} for ${phoneNumber}`);

            return {
                leadId: leadId,
                message: message,
            } as CreateLeadResponse;
        } catch (e) {
            this.logger.error(e.message);
            throw CouldNotCreateLead.create();
        }
    }

    async getLead(leadId: number): Promise<any> {
        this.logger.info(`Calling IRIS API to get lead ${leadId}`);
        try {
            const req = await fetch(this.apiUrl + '/' + leadId, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
            });

            const dataTxt = await req.text();

            const status = req.status;
            if (status !== 200) {
                throw new Error(`Iris did return lead ${leadId}, error: ${dataTxt}`);
            }

            this.logger.info(`Iris returned lead ${leadId}`, dataTxt);
            return JSON.parse(dataTxt);
        } catch (e) {
            this.logger.error(e.message);
        }
    }

    async patchLead(leadId: number, input: string): Promise<void> {
        this.logger.info(`Iris patching lead ${leadId}`);
        try {
            const req = await fetch(this.apiUrl + '/' + leadId, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
                body: input,
            });

            const status = req.status;
            const data = await req.text();

            if (status !== 200) {
                const msg = `Iris did not patch the lead ${leadId}, error: ${data}`;
                this.logger.error(msg);
                throw new IrisError({ name: 'COULD_NOT_PATCH_LEAD', message: msg, cause: data });
            }

            this.logger.info(`Iris patched lead ${leadId} `);
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async getLeadsFields(fieldId: number): Promise<GetLeadFieldsResponse> {
        this.logger.info(`Get Leads fields for ${fieldId}`);
        try {
            const res = await fetch(this.apiUrl + `/fields/${fieldId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = await res.text();

            if (status !== 200) {
                throw new Error(`Iris we couldn't get fields for ${fieldId}, error: ${data}`);
            }

            this.logger.info(`Iris fields request succeeded for ${fieldId} `);
            console.log(data);
            return JSON.parse(data) as GetLeadFieldsResponse;
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async assignAgentToLead(leadId: number, agent: number): Promise<void> {
        this.logger.info(`Assigning agent to lead ${leadId}`);
        try {
            const url = this.apiUrl + `/${leadId}/users`;
            const body = {
                user: agent,
                assign_manager: false,
            };
            this.logger.info(`URL: ${url}`);
            this.logger.info(`Body agent: ${body.user}`);

            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
                body: JSON.stringify(body),
            });

            const status = res.status;
            const data = await res.text();

            if (status !== 200) {
                throw new Error(`Iris we couldn't assign agent for ${leadId}, error: ${data}`);
            }

            this.logger.info(`Iris assigning agent succeeded for ${leadId} `);
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    getEndpointForIrisSignature(leadId: string): string {
        const base = this.apiUrl;
        const signatureURLWithLead = this.signatureURL.replace('{lead_id}', leadId.toString());
        const signatureURLWithLeadAndAppNumber = signatureURLWithLead.replace('{app_number}', this.applicationTemplateNumber);
        const url = base + signatureURLWithLeadAndAppNumber;
        return url;
    }

    getEndpointForIrisForSendSignature(leadId: string): string {
        const base = this.apiUrl;
        const signatureURLWithLead = this.sendSignatureURL.replace('{lead_id}', leadId.toString());
        const signatureURLWithLeadAndAppNumber = signatureURLWithLead.replace('{app_number}', this.applicationTemplateNumber);
        const url = base + signatureURLWithLeadAndAppNumber;
        return url;
    }

    async processIrisSignatureGenerationResponse(response: Response): Promise<string> {
        const status = response.status;
        if (status !== 200 && status !== 201) {
            this.logger.error(`The API returned an ${status} status code and body: ${await response.text()}`);
            throw ErrorGeneratingSignature.create();
        }
        const data = await response.json();
        return data.url;
    }

    async generateSignature(leadId: string, expire: boolean): Promise<CreateSignatureResponseDto> {
        const url = this.getEndpointForIrisSignature(leadId);
        const body = JSON.stringify({ expire });
        try {
            const req = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
                body,
            });
            const responseURL = await this.processIrisSignatureGenerationResponse(req);
            const res = new CreateSignatureResponseDto();
            res.url = responseURL;
            return res;
        } catch (err) {
            this.logger.error(`Error: Exception catched: ${err.message}`);
            throw IntervalServerError.create();
        }
    }

    async createSignatureForLead(leadId: number, dto: CreateSignatureForLeadRequest): Promise<CreateSignatureResponseDto> {
        const url = this.getEndpointForIrisForSendSignature(leadId as unknown as string);
        const body = JSON.stringify(dto);
        try {
            const req = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-KEY': this.apiKey,
                },
                body,
            });
            const responseURL = await this.processIrisSignatureGenerationResponse(req);
            const res = new CreateSignatureResponseDto();
            res.url = responseURL;
            return res;
        } catch (err) {
            this.logger.error(`Error: Exception catched: ${err.message}`);
            throw IntervalServerError.create();
        }
    }

    async uploadLeadDocument(id: number, file: Express.Multer.File): Promise<any> {
        this.logger.info(`Uploading document to iris ${id}`);

        try {
            const url =
                this.apiUrl +
                `/${id}/documents?tab=${this.documentTabId}&label=${this.documentLabelId}&filename=${file.originalname}&notify_users=all_assigned`;
            this.logger.info(`URL: ${url}`);

            const formData = new FormData();
            formData.append('file', fs.createReadStream(file.path), file.originalname);

            const res = await axios.post(url, formData, {
                headers: {
                    ...formData.getHeaders(),
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Uploading document to iris failed ${id} - ${data}`);
                throw new Error(`Iris we couldn't assign agent for ${id}, error: ${data}`);
            }

            this.logger.info(`Iris document upload succeeded for ${id} `);
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async uploadSignDocument(leadId: number, file: Buffer): Promise<void> {
        this.logger.info(`Uploading sign documents to iris lead ${leadId}`);

        try {
            const url = this.apiUrl + `/${leadId}/documents?tab=19&label=1&filename=${IrisClient.signDocumentName}`;
            this.logger.info(`URL: ${url}`);

            const formData = new FormData();
            formData.append('file', file, IrisClient.signDocumentName + '.pdf');

            const res = await axios.post(url, formData, {
                headers: {
                    ...formData.getHeaders(),
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Uploading sign document to iris failed ${leadId} - ${data}`);
                throw new Error(`Iris we couldn't assign agent for ${leadId}, error: ${data}`);
            }

            this.logger.info(`Iris document upload succeeded for ${leadId} `);
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async checkDuplicatedLead(dto: CheckDuplicateLeadDto): Promise<LeadListDto> {
        this.logger.info(`Checking if lead is duplicated`);
        try {
            const body = JSON.parse(JSON.stringify(IrisCheckDuplicatedLeadRequestMapper.to(dto)));
            body.Username = this.duplicatedLeadUsername;
            body.Password = this.duplicatedPassword;

            const res = await axios.post(this.duplicatedLeadsUrl, body);

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Error checking duplicated lead - ${data}`);
                throw new Error(`Error checking duplicated lead - ${status} - ${data}`);
            }

            this.logger.info(`Got leads ${data} `);
            return { leads: data.leads.sort((a, b) => a.created_at - b.created_at) };
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    // TODO: add response
    async getEquipmentInformation(mid: string): Promise<any> {
        this.logger.info(`Getting equipment information from IRIS for mid ${mid}`);
        try {
            const url = (this.apiMidUrl + this.equipmentURL).replace('{mid}', mid);
            const res = await axios.get(url, {
                headers: {
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Error getting equipment information from IRIS for mid ${mid}`);
                throw new Error(`Error getting equipment information from IRIS for mid ${mid}`);
            }

            this.logger.info(`Got equipment information ${JSON.stringify(data)} `);
            return data;
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async getMerchant(mid: string): Promise<any> {
        this.logger.info(`Getting merchant information from IRIS for mid ${mid}`);
        try {
            const res = await axios.get(this.apiMidUrl + '/' + mid, {
                headers: {
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Error getting merchant information from IRIS for mid ${mid}`);
                throw new Error(`Error getting merchant information from IRIS for mid ${mid}`);
            }

            this.logger.info(`Got merchant information ${data} `);
            return data;
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }

    async checkSignatures(leadId: number): Promise<CheckSignaturesResponseDto> {
        this.logger.info(`Checking merchant signatures from IRIS for lead ${leadId}`);
        try {
            const res = await axios.get(this.apiUrl + '/' + leadId + '/signatures', {
                headers: {
                    'X-API-KEY': this.apiKey,
                },
            });

            const status = res.status;
            const data = res.data;

            if (status !== 200) {
                this.logger.error(`Error getting signatures information from IRIS for mid ${leadId}`);
                throw new Error(`Error getting signatures information from IRIS for mid ${leadId}`);
            }

            this.logger.info(`Got lead signatures information ${data} `);
            return data as CheckSignaturesResponseDto;
        } catch (e) {
            this.logger.error(e.message);
            throw e;
        }
    }
}
