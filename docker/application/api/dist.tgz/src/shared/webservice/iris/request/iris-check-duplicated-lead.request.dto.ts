class DbaAddress {
    readonly line_1: string;
    readonly line_2: string;
    readonly city: string;
    readonly state: string;
    readonly zip: string;
}

class Owner {
    readonly email: string;
    readonly first_name: string;
    readonly last_name: string;
}

export class IrisCheckDuplicatedLeadRequestDto {
    readonly legal_name?: string;
    readonly dba_name: string;
    readonly dba_address: DbaAddress;
    readonly owner: Owner;
    readonly phone_number: string;
}
