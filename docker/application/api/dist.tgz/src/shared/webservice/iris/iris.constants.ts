export const IrisSymbolToken = Symbol('IrisSymbolToken');
