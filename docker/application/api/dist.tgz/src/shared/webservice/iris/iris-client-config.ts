export interface IrisClientConfig {
    IRIS_LEADS_URL: string;
    /**
     * Url used to retrieve data for equipment - IRIS (to TSYS) for equipment data
     */
    IRIS_MERCHANTS_URL: string;
    IRIS_API_KEY: string;
    IRIS_ID: string;
    IRIS_SIGNATURE_APP_NUMBER: string;
    IRIS_INITIAL_APPLICATION_STATUS: string;
    IRIS_SUBMITTED_APPLICATION_STATUS: string;
    /**
     * Iris create lead special relationship
     */
    IRIS_CREATE_LEAD_SPECIAL_RELATIONSHIP_ID: string;
    /**
     * Iris create lead with default primary sales person
     */
    IRIS_CREATE_LEAD_PRIMARY_SALESPERSON_ID: string;

    /**
     * Template which is used to generate the application form
     */
    IRIS_APPLICATION_TEMPLATE_NUMBER: string;
    /**
     * Iris documents upload
     */
    IRIS_DOCUMENT_LABEL_ID: string;
    IRIS_DOCUMENT_TAB_ID: string;
    /**
     * Checking duplicated leads
     */
    DUPLICATED_LEADS_URL: string;
    DUPLICATED_LEADS_USER: string;
    DUPLICATED_LEADS_PASSWORD: string;
    /**
     * Deployment mode
     */
    NODE_ENV: string;
    /**
     * The fee schedule id
     */
    FEE_SCHEDULE_ID: string;
}
