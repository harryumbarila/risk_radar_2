import { CreateSignatureResponseDto } from 'src/onboarding/response/create-signature.response.dto';
import { CustomPhoneNumber } from '../../model/custom-phone-number';
import { CreateLeadResponse, GetLeadFieldsResponse } from './iris.client';
import { LeadListDto } from '@/onboarding/response/lead-list.response.dto';
import { CheckDuplicateLeadDto } from '@/onboarding/request/check-duplicate-lead.dto';
import { CreateSignatureForLeadRequest } from '@/shared/webservice/iris/request/create-signature-for-lead.request';
import { CheckSignaturesResponseDto } from '@/shared/webservice/iris/response/check-signatures.response.dto';

export interface IrisClientInterface {
    createLead(phoneNumber: CustomPhoneNumber): Promise<CreateLeadResponse>;
    patchLead(leadId: number, input: string): Promise<void>;
    assignAgentToLead(leadId: number, agent: number): Promise<void>;
    getLeadsFields(fieldId: number): Promise<GetLeadFieldsResponse>;
    /**
     * @deprecated
     * @see createSignatureForLead
     */
    generateSignature(leadId: string, expire: boolean): Promise<CreateSignatureResponseDto>;
    createSignatureForLead(leadId: number, dto: CreateSignatureForLeadRequest): Promise<CreateSignatureResponseDto>;
    checkSignatures(leadId: number): Promise<CheckSignaturesResponseDto>;
    getLead(id: number): Promise<any>;

    /**
     * @deprecated
     * @see uploadSignDocument
     */
    uploadLeadDocument(id: number, file: Express.Multer.File): Promise<any>;
    uploadSignDocument(leadId: number, file: Buffer): Promise<void>;
    checkDuplicatedLead(dto: CheckDuplicateLeadDto): Promise<LeadListDto>;
    getEquipmentInformation(mid: string): Promise<any>;
    getMerchant(mid: string): Promise<any>;
}
