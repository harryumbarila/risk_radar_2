export class RecipientDto {
    fieldId: string;
    name: string;
}

export class CreateSignatureForLeadRequest {
    recipients: RecipientDto[];
    expire: boolean;
}
