import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Request } from 'express';
import { AuthService } from '../auth.service';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorator/public.decorator';

@Injectable()
export class JwtAuthGuard implements CanActivate {
    public static readonly REQUEST_USER_TOKEN_PAYLOAD_KEY: string = 'userEntity';
    public static readonly REQUEST_USER_ENTITY_KEY: string = 'userEntity';
    public static readonly JWT_BEARER_HEADER_VALUE: string = 'Bearer';

    constructor(
        private authService: AuthService,
        private reflector: Reflector,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [context.getHandler(), context.getClass()]);

        if (isPublic) {
            return true;
        }

        const request = context.switchToHttp().getRequest();
        const token = this.extractTokenFromHeader(request);

        if (!token) {
            throw new UnauthorizedException();
        }

        try {
            if (await this.authService.verifyJwtTokenRaw(token)) {
                const payload = this.authService.decodeTokenToJwtPayloadType(token);
                const user = await this.authService.getUserEntityFromJwtPayloadType(payload);

                request[JwtAuthGuard.REQUEST_USER_TOKEN_PAYLOAD_KEY] = payload;
                request[JwtAuthGuard.REQUEST_USER_ENTITY_KEY] = user;
            } else {
                throw new UnauthorizedException();
            }
        } catch {
            throw new UnauthorizedException();
        }
        return true;
    }

    private extractTokenFromHeader(request: Request): string | undefined {
        const [type, token] = request.headers.authorization?.split(' ') ?? [];
        return type?.toLowerCase() === JwtAuthGuard.JWT_BEARER_HEADER_VALUE.toLowerCase() ? token : undefined;
    }
}
