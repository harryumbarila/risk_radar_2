import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthService } from '@/shared/auth/auth.service';
import { ConfigService } from '@nestjs/config';
import { ApiKeysServiceConfig } from '@/shared/model/account/api-keys.factory';
import { Account } from '@/shared/model/account.entity';
import { REQUEST_ACCOUNT_ENTITY_KEY } from '@/shared/auth/guard/request-entity-account-key.constant';

@Injectable()
export class AccountSecretAuthorizationBasicGuard implements CanActivate {
    constructor(
        private readonly authService: AuthService,
        private configService: ConfigService<ApiKeysServiceConfig>,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request = context.switchToHttp().getRequest();
        const authorization = request.headers.authorization;

        if (!authorization) {
            throw new UnauthorizedException();
        }

        const [strategy, token] = authorization.split(' ');

        if (strategy.toLowerCase() !== 'basic') {
            throw new UnauthorizedException();
        }

        const account = await this.validateBasicAuthorization(token);

        if (!account) {
            throw new UnauthorizedException();
        }

        request[REQUEST_ACCOUNT_ENTITY_KEY] = account;

        return true;
    }

    async validateBasicAuthorization(token: string): Promise<boolean | Account> {
        const buff = Buffer.from(token, 'base64');
        const text = buff.toString('ascii');
        const [accountSid, accountSecretKey] = text.split(':');

        const apiKeyPrefix = this.configService.get<string>('ACCOUNT_SECRET_API_KEY_PREFIX');

        if (!accountSecretKey) {
            return false;
        }

        if (!accountSecretKey.startsWith(apiKeyPrefix)) {
            throw new UnauthorizedException('Secret key cannot be used in this env.');
        }

        return await this.authService.verifyAndGetAccount(accountSid, accountSecretKey);
    }
}
