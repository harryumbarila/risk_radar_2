export const REQUEST_ACCOUNT_ENTITY_KEY: string = 'accountEntity';
