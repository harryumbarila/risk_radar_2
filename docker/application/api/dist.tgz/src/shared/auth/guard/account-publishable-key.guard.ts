import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { Account } from '@/shared/model/account.entity';
import { ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH } from '@/shared/model/account/account.const';
import { ConfigService } from '@nestjs/config';
import { ApiKeysServiceConfig } from '@/shared/model/account/api-keys.factory';
import { REQUEST_ACCOUNT_ENTITY_KEY } from '@/shared/auth/guard/request-entity-account-key.constant';

/**
 * @deprecated
 */
@Injectable()
export class AccountPublishableKeyGuard implements CanActivate {
    constructor(
        private accountRepository: AccountRepository,
        private configService: ConfigService<ApiKeysServiceConfig>,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request = context.switchToHttp().getRequest();

        const publishableKey = request.headers['custom-publishable-key'];

        if (publishableKey.length > ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH) {
            throw new UnauthorizedException('Publishable key is invalid.');
        }

        const apiKeyPrefix = this.configService.get<string>('ACCOUNT_PUBLIC_API_KEY_PREFIX');

        if (!publishableKey.startsWith(apiKeyPrefix)) {
            throw new UnauthorizedException('Publishable key cannot be used in this env.');
        }

        const account: Account = await this.accountRepository.findOneBy({ apiKeys: { publishableKey: publishableKey } });

        if (!account) {
            throw new UnauthorizedException('Invalid publishable key.');
        }

        request[REQUEST_ACCOUNT_ENTITY_KEY] = account;

        return true;
    }
}
