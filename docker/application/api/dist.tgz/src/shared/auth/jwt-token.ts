import { ApiProperty } from '@nestjs/swagger';

export class JwtToken {
    @ApiProperty()
    public readonly id: string;
    @ApiProperty()
    public readonly token: string;
    @ApiProperty()
    public readonly phone: string;
    @ApiProperty()
    public readonly created_at: string;
    @ApiProperty()
    public readonly publishable_key: string;
}
