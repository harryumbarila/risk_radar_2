import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { REQUEST_ACCOUNT_ENTITY_KEY } from '@/shared/auth/guard/request-entity-account-key.constant';

export const CurrentAccount = createParamDecorator((data: unknown, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest();

    if (request[REQUEST_ACCOUNT_ENTITY_KEY]) {
        return request[REQUEST_ACCOUNT_ENTITY_KEY];
    }

    return null;
});
