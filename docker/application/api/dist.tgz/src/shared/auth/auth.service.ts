import { Injectable, UnauthorizedException } from '@nestjs/common';
import { Merchant } from '../model/merchant.entity';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { JwtToken } from './jwt-token';
import { InjectRepository } from '@nestjs/typeorm';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { Account } from '@/shared/model/account.entity';
import { ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH } from '@/shared/model/account/account.const';

export interface AuthServiceConfig {
    JWT_SECRET_KEY: string;
    ACCOUNT_PUBLIC_API_KEY_PREFIX: string;
}

interface JwtPayload {
    user_id?: string;
    sid?: string;
}

/**
 * @description Represents the expiration time for a JWT token.
 * The value is provided in string format using the following format: 'Xy', where:
 *  - X: number of time units
 *  - y: time unit identifier
 *
 * The available time unit identifiers are:
 *  - s: seconds
 *  - m: minutes
 *  - h: hours
 *  - d: days
 *
 * Example Usage:
 *  - '30s' represents 30 seconds
 *  - '1h' represents 1 hour
 *  - '2d' represents 2 days
 */
const JWT_TOKEN_EXPIRES_IN: string = '3d';

@Injectable()
export class AuthService {
    constructor(
        private jwtService: JwtService,
        private readonly accountRepository: AccountRepository,
        @InjectRepository(Merchant) private readonly userRepository: MerchantRepository,
        private configService: ConfigService<AuthServiceConfig>,
    ) {}

    /**
     * Generates a JWT token for the given merchant.
     *
     * @param {Merchant} user - The merchant object for which the token needs to be generated.
     * @throws Error  if the environment variable is missing.
     * @return {Promise<JwtToken>} - A promise that resolves to the generated JwtToken object.
     */
    async generateJwtToken(user: Merchant): Promise<JwtToken> {
        const payload = { user_id: user.getId(), sid: user.getSid().toString() } as JwtPayload;
        const account = await user.account;

        return {
            id: user.getSid().toString(),
            token: await this.jwtService.signAsync(payload, {
                secret: <string>this.configService.getOrThrow<string>('JWT_SECRET_KEY'),
                expiresIn: JWT_TOKEN_EXPIRES_IN,
            }),
            phone: user.getPhoneNumber(),
            created_at: user.getCreatedAt().toISOString(),
            publishable_key: account.apiKeys.publishableKey,
        } as JwtToken;
    }

    /**
     * Verify a JSON Web Token (JWT) against the JWT_SECRET_KEY. Returns true if the token is verified, false for any other reason.
     *
     * @param {string} token - The JWT to be verified.
     * @throws Error  if the environment variable is missing.
     * @returns {Promise<boolean>} - A promise that is resolved with true if the JWT is valid, false otherwise.
     */
    async verifyJwtTokenRaw(token: string): Promise<boolean> {
        const secret = this.configService.getOrThrow('JWT_SECRET_KEY');
        try {
            await this.jwtService.verifyAsync(token, { secret });
            return true;
        } catch (error) {
            return false;
        }
    }

    /**
     * This method decodes the given JWT token and checks that the decoded payload has either a sid or user_id
     * property - if not, an error will be thrown.
     * @param token
     */
    decodeTokenToJwtPayloadType(token: string): JwtPayload {
        const payload = this.jwtService.decode(token) as JwtPayload;
        if (payload.user_id === undefined || payload.sid === undefined) {
            throw new UnauthorizedException();
        }

        return payload;
    }

    /**
     * Resolves the merchant entity from the JWT payload type.
     *
     * @param {JwtPayload} payload - The JWT payload type.
     * @returns {Promise<Merchant>} - The resolved merchant entity.
     * @throws {UnauthorizedException} - If the merchant is not found or is not active or pending.
     */
    async getUserEntityFromJwtPayloadType(payload: JwtPayload): Promise<Merchant> {
        let user: Merchant | null = null;

        /**
         * @todo add check with account
         */
        if (payload.user_id) {
            user = await this.userRepository.findOneBy({ id: payload.user_id });
        }

        if (!user) {
            throw new UnauthorizedException();
        }

        return user;
    }

    /**
     * Verifies the provided account credentials and returns the account if they are valid.
     *
     * @param {string} accountSid - The Account SID.
     * @param {string} accountSecret - The Account secret key.
     * @return {Promise<Account|boolean>} - Either the account object if the credentials are valid or false otherwise.
     */
    async verifyAndGetAccount(accountSid: string, accountSecret: string): Promise<Account | boolean> {
        const account = await this.accountRepository.findOneBy({ sid: accountSid });

        if (account && account.apiKeys && account.apiKeys.secretKey === accountSecret) {
            return account;
        }

        return false;
    }

    /**
     * Retrieves an account based on the provided publishable key.
     *
     * @param {string} publishableKey - The publishable key associated with the account.
     * @returns {Promise<Account | null>} - The account object if found, otherwise null.
     * @throws {UnauthorizedException} - If the publishable key is invalid, cannot be used in the current environment, or does not exist.
     */
    async getAccountFromPublishableKey(publishableKey: string): Promise<Account | null> {
        if (publishableKey.length > ACCOUNT_API_KEYS_MAX_PUBLISHABLE_KEY_LENGTH) {
            throw new UnauthorizedException('Publishable key is invalid.');
        }

        const apiKeyPrefix = this.configService.get<string>('ACCOUNT_PUBLIC_API_KEY_PREFIX');

        if (!publishableKey.startsWith(apiKeyPrefix)) {
            throw new UnauthorizedException('Publishable key cannot be used in this env.');
        }

        const account: Account | null = await this.accountRepository.findOneBy({ apiKeys: { publishableKey: publishableKey } });

        if (!account) {
            throw new UnauthorizedException('Invalid publishable key.');
        }

        return account;
    }
}
