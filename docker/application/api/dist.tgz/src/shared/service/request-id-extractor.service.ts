import { Injectable, Scope, Inject } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';

export const REQUEST_ID_HEADER_NAME: string = 'X-Request-Id';

@Injectable({ scope: Scope.REQUEST })
export class RequestIdExtractorService {
    constructor(@Inject(REQUEST) private readonly request: Request) {}

    getRequestId(): string | null {
        const header = this.request.headers[REQUEST_ID_HEADER_NAME] as string;

        if (!header) {
            return null;
        }

        return header;
    }
}
