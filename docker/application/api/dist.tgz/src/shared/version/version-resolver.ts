import { join } from 'path';

const fs = require('fs');

// TODO move to env if absolute path is set use that one instead of this default
const VERSION_PATH = join(__dirname, '../../../../');

export type VersionData = {
    version: string;
    branch: string;
    commit: string;
    created_at: string;
};

export class VersionResolver {
    static resolveVersion(): VersionData {
        const path = join(VERSION_PATH, 'version.json');

        if (fs.existsSync(path)) {
            return JSON.parse(fs.readFileSync(path, 'utf8').replace(new RegExp('\n', 'g'), ' '));
        }

        return {
            version: '1.0.0',
            branch: 'master',
            commit: 'latest',
            created_at: '',
        };
    }
}
