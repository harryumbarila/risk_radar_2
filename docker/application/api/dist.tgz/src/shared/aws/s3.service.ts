import { Injectable, Inject } from '@nestjs/common';
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

@Injectable()
export class S3Service {
    constructor(
        @Inject('S3_CLIENT') private readonly s3Client: S3Client,
        @InjectPinoLogger(S3Service.name) private readonly logger: PinoLogger,
    ) {}

    async uploadFile(bucketName: string, file: Buffer | string, fileName: string, contentType?: string) {
        const fileKey = fileName;
        const command = new PutObjectCommand({
            Bucket: bucketName,
            Key: fileName,
            Body: file,
            ContentType: contentType,
        });

        await this.s3Client.send(command);

        this.logger.info(`File uploaded to S3: ${fileKey}`);

        return {
            key: fileKey,
            url: `https://${bucketName}.s3.amazonaws.com/${fileKey}`,
        };
    }

    async getFile(bucketName: string, key: string) {
        const command = new GetObjectCommand({ Bucket: bucketName, Key: key });
        return this.s3Client.send(command);
    }

    async getFileSignedUrl(bucketName: string, key: string, expiresInSeconds = 3600): Promise<string> {
        try {
            const command = new GetObjectCommand({ Bucket: bucketName, Key: key });
            // Generate the signed URL with an expiration time
            const signedUrl = await getSignedUrl(this.s3Client, command, { expiresIn: expiresInSeconds });
            return signedUrl;
        } catch (error) {
            console.error('Error generating signed URL', error);
            throw error;
        }
    }

    async deleteFile(bucketName: string, key: string) {
        const command = new DeleteObjectCommand({ Bucket: bucketName, Key: key });
        return this.s3Client.send(command);
    }
}
