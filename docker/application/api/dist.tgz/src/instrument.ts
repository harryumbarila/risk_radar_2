import { VersionResolver } from '@/shared/version/version-resolver';
import * as Sentry from '@sentry/nestjs';
import { ConfigService } from '@nestjs/config';
import '@sentry/tracing';

export class Instrument {
    static init(configService: ConfigService): void {
        const version = VersionResolver.resolveVersion();

        Sentry.init({
            dsn: configService.get('SENTRY_DSN'),
            environment: configService.get('APP_ENV'),
            release: version.version,
            debug: process.env.NODE_ENV !== 'production',
            // Tracing
            tracesSampleRate: 0.1, //  Capture 10% of the transactions

            // Set sampling rate for profiling - this is relative to tracesSampleRate
            profilesSampleRate: 0.1,
        });
    }
}
