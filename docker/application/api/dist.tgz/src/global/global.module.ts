import { Global, Module } from '@nestjs/common';
import { AuthService } from '@/shared/auth/auth.service';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Merchant } from '@/shared/model/merchant.entity';
import { Account } from '@/shared/model/account.entity';
import { RequestIdExtractorService } from '@/shared/service/request-id-extractor.service';

@Global()
@Module({
    imports: [TypeOrmModule.forFeature([Merchant, Account])],
    providers: [AuthService, RequestIdExtractorService, MerchantRepository, AccountRepository],
    exports: [AuthService, RequestIdExtractorService],
})
export class GlobalModule {}
