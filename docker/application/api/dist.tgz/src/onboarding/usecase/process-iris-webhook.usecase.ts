import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { InjectRepository } from '@nestjs/typeorm';
import { Lead, OnboardingStatus } from '@/shared/model/lead.entity';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { NoMerchantFoundForLead, NotEventOnIrisWebhook } from '../onboarding.error';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { Merchant } from '@/shared/model/merchant.entity';
import { WebhookBody } from 'src/shared/model/iris-webhook-body';
import { ConfigService } from '@nestjs/config';
import { IrisClientConfig } from '@/shared/webservice/iris/iris-client-config';
import { AorakiPaymentsClientInterface, AorakiPaymentsSymbolToken } from '@/shared/webservice/aoraki-payments/aoraki-payments.client';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { IrisMapper } from '@/shared/irisMappings/iris-mapper';
import { timezoneMappingToString } from '@/shared/irisMappings/timezone-mappings';
import { getFluidPayBusinessTypeMapping, getFluidPayIndustryCodeMapping } from '@/shared/irisMappings/iris-fluidpay-mappings';
import { NewStatusExtractorProcessor } from '@/onboarding/usecase/process-iris-webhook/new-status-extractor.processor';
import { CustomPhoneNumber } from '@/shared/model/custom-phone-number';
import { Account } from '@/shared/model/account.entity';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { WebhookService } from '@/webhook/webhook.service';
import { GetMerchantResponseDto } from '@/onboarding/response/get-merchant-response.dto';
import { UsernameGenerator } from '@/onboarding/usecase/process-iris-webhook/username-generator';
import { SlackSymbolToken } from '@/shared/webservice/slack/slack.constant';
import { SlackInterface } from '@/shared/webservice/slack/slack.interface';
import { MerchantNameCleaner } from '@/onboarding/usecase/process-iris-webhook/merchant-name-cleaner';
import { LeadService } from '@/onboarding/service/lead.service';

type FailedOnboardingSubject = 'Failed Onboarding' | 'Failed to create terminal in AORAKI';

@Injectable()
export class ProcessIrisWebhookUseCase implements UseCaseInterface {
    readonly SIGNATURE_EVENT: string = 'lead.signature.signed';
    readonly TURBOAPP_APPROVED_EVENT: string = 'turboapp.approved';
    readonly LEAD_UPDATED_EVENT: string = 'lead.status.updated';
    readonly LEAD_UPDATED_EVENT_NEW_STATUS_NOT_PROCESSING: string = 'Not Processing';
    readonly LEAD_UPDATED_EVENT_NEW_STATUS_FAILED_ONBOARDING: string = 'Failed Auto-Boarding';

    // This status number means Unclaimed by UW (IRIS)
    private readonly irisSubmittedApplicationStatus: number;
    // The fee schedule id to call fluidpay
    private readonly feeScheduleId: string;

    constructor(
        @InjectPinoLogger(ProcessIrisWebhookUseCase.name) private readonly logger: PinoLogger,
        @InjectRepository(Lead) private readonly leadRepository: LeadRepository,
        @InjectRepository(Merchant) private readonly userRepository: MerchantRepository,
        @InjectRepository(Account) private readonly accountRepository: AccountRepository,
        @Inject(AorakiPaymentsSymbolToken) private readonly aorakiPaymentsClient: AorakiPaymentsClientInterface,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        @Inject(SlackSymbolToken) private readonly slackClient: SlackInterface,
        private configService: ConfigService<IrisClientConfig>,
        private readonly leadService: LeadService,
        private readonly irisMapper: IrisMapper,
        private readonly newStatusExtractor: NewStatusExtractorProcessor,
        private readonly webhookService: WebhookService,
        private readonly usernameGenerator: UsernameGenerator,
    ) {
        this.irisSubmittedApplicationStatus = parseInt(this.configService.get('IRIS_SUBMITTED_APPLICATION_STATUS'));
        this.feeScheduleId = this.configService.get('FEE_SCHEDULE_ID');
    }

    getFluidpayEquipment(data: any): any {
        let correctEquipment;
        const equipmentsArray = data.data;
        for (const equipment of equipmentsArray) {
            if (equipment.status == 'Open' && equipment.model == '45') {
                correctEquipment = equipment;
                break;
            }
        }
        return correctEquipment;
    }

    extractFluidPayInformation(lead: any, merchant: any, equipmentRes: any, mid: string): any {
        const equipment = this.getFluidpayEquipment(equipmentRes);

        let phone = merchant.account_information.Phone;
        const name = MerchantNameCleaner.clean(merchant.general.name);

        let timezone: string;
        if (equipment.timezone && timezoneMappingToString[equipment.timezone]) {
            timezone = timezoneMappingToString[equipment.timezone];
        } else {
            timezone = 'US/Central';
        }

        if (phone.length == 10) {
            phone = `1${phone}`;
        }

        const classification = getFluidPayBusinessTypeMapping(lead.main_product.category, lead);
        const industry_code = getFluidPayIndustryCodeMapping(lead.main_product.category);

        const processorRequiredFields = {
            settle_at: '07:00:00',
            timezone: timezone,
            supported_payment_methods: ['card'],
            name: merchant.general.name,
            description: equipment.pos_mid,
            status: 'active',
            supported_currencies: ['usd'],
            features: {
                hide_in_vt: false,
                disable_auto_settle: false,
            },
            settings: {
                tsys_sierra: {
                    classification,
                    industry_code,
                    city_code: equipment.zip_code,
                    merchant_name: name,
                    merchant_location: phone,
                    bin: equipment.bin,
                    agent_bank_number: equipment.agent,
                    agent_chain_number: equipment.chain,
                    store_number: equipment.store,
                    terminal_number: equipment.terminal,
                    terminal_identification_number: equipment.vnumber.replace('V', '7'),
                    country_code: equipment.country === 'US' ? '840' : '',
                    timezone: timezone,
                    mcc: equipment.mcc,
                    merchant_state: equipment.state,
                    merchant_location_number: equipment.location_num.slice(-5),
                    language_indicator: '00',
                    currency_code: '840',
                    mid: equipment.pos_mid,
                },
            },
        };

        const fluidPayMerchant = {
            status: 'active',
            fee_schedule_id: this.feeScheduleId,
            name: merchant.general.name,
            phone: merchant.account_information.Phone,
            timezone: timezone,
            receipt_email: merchant.account_information.Email,
            primary_contact: {
                country: 'US',
                first_name: lead.owner_one.first_name,
                last_name: lead.owner_one.last_name,
                company: lead.legal_business_name,
                address_line_1: lead.owner_one.home_address.address,
                city: lead.owner_one.home_address.city,
                state: lead.owner_one.home_address.state,
                postal_code: lead.owner_one.home_address.zip,
                email: lead.owner_one.email,
                phone: lead.legal_phone,
            },
            user: {
                status: 'active',
                role: 'admin',
                create_api_key: true,
                create_pub_api_key: true,
                username: this.usernameGenerator.generate(lead.owner_one.first_name, lead.owner_one.last_name, phone),
                name: lead.owner_one.first_name.trim() + ' ' + lead.owner_one.last_name.trim(),
                phone: lead.legal_phone,
                email: lead.owner_one.email,
            },
            permissions: {
                support_blind_credits: false,
                allow_rule_engine_access: true,
                allow_invoice_access: true,
                allow_customer_vault_access: true,
                allow_recurring_billing_access: true,
                allow_cart_access: true,
                allow_developer_hub_link: true,
                allow_advanced_fields: true,
                enable_terminal_debit_transactions: true,
                allow_defaults_population: true,
                allow_billing_access: true,
                allow_dashboard_stats: true,
                allow_file_batch: true,
                allow_automatic_account_updater: true,
                allow_ibx_bin_lookup: false,
                allow_surcharge: false,
                allow_midigator: false,
                allow_advanced_rule_engine_features: false,
                allow_dual_pricing: false,
                allow_customer_delete_with_subscription: false,
                guardian_check: false,
                allow_terminal_credits: false,
                enforce_2fa_requirement: true,
                allow_transaction_reporting_totals: false,
                allow_dual_pricing_v2: false,
                allow_simple_payments_access: false,
                allow_virtual_terminal_session: false,
                require_2fa_for_user_access: false,
                allow_cash_discount_v2: false,
                process_credit: true,
            },
            enable_account_updater: false,
            enable_community_rules: true,
        };

        return {
            merchants: fluidPayMerchant,
            processor: processorRequiredFields,
        };
    }

    /**
     * @todo refactor - extract method to dedicated service for all event handlers
     */
    async handleApproval(body: WebhookBody, accountSid?: string): Promise<void> {
        const data = body?.data?.accounts?.[0];
        if (!data) {
            this.logger.error('No data found in webhook body');
            throw NotEventOnIrisWebhook.create();
        }

        const { lid, mid } = data;
        const merchantData = await this.irisClient.getMerchant(mid);
        const equipmentDataResponse = await this.irisClient.getEquipmentInformation(mid);
        const irisLeadInfo = JSON.stringify(await this.irisClient.getLead(lid));
        const leadData = this.irisMapper.fromIrisToNormalizedDto(irisLeadInfo);
        const fluidpayData = this.extractFluidPayInformation(leadData, merchantData, equipmentDataResponse, mid);
        const leadId = lid;
        let account: Account | null = null;

        let lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

        if (lead) {
            account = await lead.merchant.account;
        }

        if (!lead) {
            /**
             * If there is no lead
             */
            this.logger.info(`No user found for lead ${leadId}`);

            if (accountSid) {
                account = await this.accountRepository.findOne({ where: { sid: accountSid } });

                if (!account) {
                    throw new Error('No account found for lead ' + leadId);
                }

                const merchant = await this.userRepository.save(Merchant.create(new CustomPhoneNumber(leadData.legal_phone), account));
                lead = await this.leadRepository.save(Lead.create(merchant, leadId, OnboardingStatus.COMPLETED, JSON.stringify(data)));
            }
        }

        if (!account) {
            throw new Error(`No account ${accountSid} and for lead ` + leadId);
        }

        if (lead.onboardingStatus == OnboardingStatus.APPROVED) {
            this.logger.info(`Lead already approved ${lead.leadId}`);
            return;
        }

        lead.onboardingStatus = OnboardingStatus.APPROVED;
        await this.leadRepository.save(lead);

        await this.aorakiPaymentsClient.merchantOnboarding(
            account.sid.toString(),
            account.apiKeys.secretKey,
            lead.merchant.sid.toString(),
            mid,
            fluidpayData.merchants,
            fluidpayData.processor,
        );

        await this.webhookService.createForMerchantVerificationApproved(account, GetMerchantResponseDto.createFromMerchant(lead.merchant));
    }

    async handle(body: WebhookBody): Promise<void> {
        this.logger.info('Receiving webhook event body from IRIS', { body: JSON.stringify(body) });

        const event = body.hook?.event;

        if (!event) {
            this.logger.error('No event found in webhook body');
            throw NotEventOnIrisWebhook.create();
        }

        this.logger.info(`Processing ${event} webhook event from IRIS`);

        const leadId = ProcessIrisWebhookUseCase.extractLeadId(body);

        try {
            if (event === this.SIGNATURE_EVENT) {
                if (!leadId) {
                    this.logger.info('No lead id found in webhook body');
                    return;
                }

                // @todo unify checks
                const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

                if (!lead) {
                    this.logger.info('No lead found');
                    return;
                }

                // update application status on IRIS to Unclaimed by UW
                await this.leadService.updateLeadRaw(leadId, JSON.stringify({ status: this.irisSubmittedApplicationStatus }));

                // finished onboarding process - wait for approval by ops afterwards
                await this.completeOnboarding(leadId);
                return;
            } else if (event === this.TURBOAPP_APPROVED_EVENT) {
                await this.handleApproval(body);
                return;
            } else if (event === this.LEAD_UPDATED_EVENT) {
                if (!leadId) {
                    this.logger.info('No lead id found in webhook body');
                    return;
                }

                // @todo unify checks
                const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

                if (!lead) {
                    this.logger.info('No lead found');
                    return;
                }

                const newStatusValue = this.newStatusExtractor.process(body);

                // if "Not Processing" terminal can be created to process terminal payments
                if (newStatusValue === this.LEAD_UPDATED_EVENT_NEW_STATUS_NOT_PROCESSING) {
                    try {
                        await this.createTerminal(leadId);
                    } catch (e) {
                        this.logger.error(`Failed to create terminal for lead ${leadId} due to ${e.message}`);
                        await this.informAboutFailedOnboarding(leadId, e.message, 'Failed to create terminal in AORAKI');
                        return;
                    }
                }

                if (newStatusValue === this.LEAD_UPDATED_EVENT_NEW_STATUS_FAILED_ONBOARDING) {
                    await this.informAboutFailedOnboarding(leadId, body);
                }
            }
        } catch (e) {
            this.logger.error(`Failed onboarding ${leadId} due to ${e.message}`);
            await this.informAboutFailedOnboarding(leadId, body, 'Failed Onboarding', e.message);
        }

        if (!leadId) {
            this.logger.info('No lead id found in webhook body');
            return;
        }

        // @todo unify checks
        const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

        if (!lead) {
            this.logger.info('No lead found');
            return;
        }

        await this.updateLeadData(leadId, body);
    }

    // todo move this logic to external class like IrisLeadIdExtractor
    public static extractLeadId(body: WebhookBody): number | null {
        const signatures = body?.data?.signatures;
        if (!signatures) return body.data?.lead?.id ?? null;
        const signatureWithLeadData = signatures.find((signatureData: any) => signatureData.lead && signatureData.lead.id);
        if (!signatureWithLeadData) return null;
        return signatureWithLeadData.lead.id;
    }

    private async updateLeadData(leadId: number, body: WebhookBody): Promise<void> {
        const jsonData = JSON.stringify(body);
        await this.leadRepository.update({ leadId }, { data: jsonData });
        this.logger.info(`Lead ${leadId} updated on db`);
    }

    private async completeOnboarding(leadId: number): Promise<void> {
        const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });
        if (!lead || !lead.merchant) {
            this.logger.error(`No user found for lead ${leadId}`);
        }

        const userId = lead.merchant.id;
        await this.leadRepository.update({ leadId }, { onboardingStatus: OnboardingStatus.COMPLETED });
        this.logger.info(`User ${userId} lead status updated on db`);
    }

    private async createTerminal(leadId: number): Promise<void> {
        const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

        if (!lead || !lead.merchant) {
            this.logger.error(`No merchant found for lead ${leadId}`);
            throw NoMerchantFoundForLead.create();
        }

        const account = await lead.merchant.account;

        await this.aorakiPaymentsClient.merchantCreateTerminal(
            account.sid.toString(),
            account.apiKeys.secretKey,
            lead.merchant.sid.toString(),
        );
    }

    private async informAboutFailedOnboarding(
        leadId: number,
        body: WebhookBody | string,
        subject: FailedOnboardingSubject = 'Failed Onboarding',
        exception: string = null,
    ): Promise<void> {
        const message = typeof body === 'string' ? body : JSON.stringify(body);
        const formattedMessage = exception ? `${subject} - ${message} - EXCEPTION: ${exception}` : `${subject} - ${message}`;

        await this.slackClient.postOnOnboarding(`${formattedMessage}`);
        const lead = await this.leadRepository.findOne({ where: { leadId }, relations: { merchant: true } });

        // Skip changing onboarding status
        if (subject === 'Failed to create terminal in AORAKI') {
            return;
        }

        if (!lead || !lead.merchant) {
            await this.slackClient.postOnOnboarding(`Lead ${leadId} not found on db`);
            this.logger.error(`No merchant found for lead ${leadId}`);
            throw NoMerchantFoundForLead.create();
        }

        lead.onboardingStatus = OnboardingStatus.FAILED;
        await this.leadRepository.save(lead);
        this.logger.info(`Lead ${leadId} status updated to FAILED`);
    }
}
