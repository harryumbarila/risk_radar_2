import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { LeadService } from '@/onboarding/service/lead.service';
import { SignResponseDto } from '@/onboarding/request/sign.response.dto';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { SignRequestDto } from '@/onboarding/request/sign.request.dto';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { RuntimeException } from '@nestjs/core/errors/exceptions';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { SlackSymbolToken } from '@/shared/webservice/slack/slack.constant';
import { SlackInterface } from '@/shared/webservice/slack/slack.interface';

@Injectable()
export class SignByExtraOwnersUseCase implements UseCaseInterface {
    constructor(
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly merchantRepository: MerchantRepository,
        private readonly leadService: LeadService,
        @Inject(SlackSymbolToken) private readonly slackClient: SlackInterface,
        @InjectPinoLogger(SignByExtraOwnersUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(dto: SignRequestDto, auditTrailDto: AuditTrailLeadStepLogDto): Promise<SignResponseDto> {
        const leadSignature = await this.leadSignatureRepository.findOneBy({ id: dto.lead_signature_id });

        if (!leadSignature) {
            throw new NotFoundException('Lead signature not found');
        }

        if (leadSignature.owner) {
            throw new RuntimeException('You cannot sign this lead, it is already signed by an owner');
        }

        const merchant = await this.merchantRepository.findOne({ where: { lead: { id: leadSignature.lead.id } }, relations: ['lead'] });

        if (!merchant) {
            throw new RuntimeException('Merchant not found');
        }

        // Audit Trail step
        const auditTrailDtoOverride = auditTrailDto.override(merchant);

        try {
            await this.leadService.sign(merchant, dto.lead_signature_id, auditTrailDtoOverride);
            return { ...new SignResponseDto(), message: 'Signed' };
        } catch (e) {
            this.logger.error(e);
            await this.slackClient.postOnOnboarding(
                `Failed onboarding - signing contract ${dto.lead_signature_id} by extra owner ${e.message}`,
            );
            throw e;
        }
    }
}
