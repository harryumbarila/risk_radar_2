import { Injectable, NotFoundException } from '@nestjs/common';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { UrlGenerator } from '@/shared/url/url.generator';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';

@Injectable()
export class CollectClickToSignUseCase implements UseCaseInterface {
    constructor(
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly merchantRepository: MerchantRepository,
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly urlGenerator: UrlGenerator,
    ) {}

    async handle(leadSignatureId: string, dto: AuditTrailLeadStepLogDto): Promise<string> {
        const leadSignature = await this.leadSignatureRepository.findOneBy({ id: leadSignatureId });

        if (!leadSignature) {
            throw new NotFoundException('Lead signature not found');
        }

        const merchant = await this.merchantRepository.findOne({ where: { lead: { id: leadSignature.lead.id } }, relations: ['lead'] });

        if (!merchant) {
            throw new NotFoundException('Merchant not found');
        }

        const audiTrailWithMerchant = dto.override(merchant);

        await this.leadAuditTrailStepLogRepository.save(
            LeadAuditTrailStepLog.create(
                audiTrailWithMerchant.overrideWithOwnerName(
                    new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
                    leadSignature.id,
                ),
            ),
        );

        return this.urlGenerator.generateClickToSignFormUrl(leadSignature.id);
    }
}
