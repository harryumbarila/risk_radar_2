import { UseCaseInterface } from '../../shared/usecase.interface';
import { Inject, Injectable } from '@nestjs/common';
import { TwilioSymbolToken } from '../../shared/webservice/twilio/twilio.constants';
import { TwilioClientInterface } from '../../shared/webservice/twilio/twilio-client.interface';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { CustomPhoneNumber } from '../../shared/model/custom-phone-number';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';

@Injectable()
export class SendOtpCodeUseCase implements UseCaseInterface {
    constructor(
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        @Inject(TwilioSymbolToken) private readonly twilioClient: TwilioClientInterface,
        @InjectPinoLogger(SendOtpCodeUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(phoneNumber: CustomPhoneNumber, dto: AuditTrailLeadStepLogDto) {
        // Audit Trail step
        await this.leadAuditTrailStepLogRepository.save(LeadAuditTrailStepLog.create(dto.overrideWithPhoneNumber(phoneNumber.getNumber())));

        this.logger.info(`Sending otp code to ${phoneNumber}`);
        return await this.twilioClient.sendOtpCode(phoneNumber);
    }
}
