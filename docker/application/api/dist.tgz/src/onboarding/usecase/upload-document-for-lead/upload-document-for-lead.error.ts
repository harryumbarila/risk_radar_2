import { DomainError } from '../../../shared/model/domain.error';

type ErrorName = 'ERROR' | 'COULD_NOT_UPLOAD_DOCUMENT_FOR_LEAD' | 'LEAD_DOES_NOT_EXIST';

export class UploadDocumentForLeadError extends DomainError<ErrorName> {}

export class CouldNotUploadDocumentForLead extends UploadDocumentForLeadError {
    public static create(): UploadDocumentForLeadError {
        return new this({
            name: 'COULD_NOT_UPLOAD_DOCUMENT_FOR_LEAD',
            message: `Could not upload document, please contact CS`,
        });
    }
}

export class LeadDoesNotExist extends UploadDocumentForLeadError {
    public static create(): UploadDocumentForLeadError {
        return new this({
            name: 'LEAD_DOES_NOT_EXIST',
            message: `Could not upload document, please contact CS`,
        });
    }
}
