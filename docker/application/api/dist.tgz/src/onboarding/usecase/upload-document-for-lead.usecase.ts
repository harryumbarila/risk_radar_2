import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { InjectRepository } from '@nestjs/typeorm';
import { Lead } from '@/shared/model/lead.entity';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { CouldNotUploadDocumentForLead, LeadDoesNotExist } from './upload-document-for-lead/upload-document-for-lead.error';

@Injectable()
export class UploadDocumentForLeadUseCase implements UseCaseInterface {
    constructor(
        @InjectPinoLogger(UploadDocumentForLeadUseCase.name) private readonly logger: PinoLogger,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        @InjectRepository(Lead) private readonly leadRepository: LeadRepository,
    ) {}

    async handle(leadId: number, file: Express.Multer.File): Promise<void> {
        this.logger.info('Uploading document to iris', leadId);

        const lead: Lead | null = await this.leadRepository.findOneBy({ leadId: leadId });

        if (!lead) {
            this.logger.error(`Could not find lead id ${leadId}`);
            throw LeadDoesNotExist.create();
        }

        try {
            await this.irisClient.uploadLeadDocument(leadId, file);
        } catch (e) {
            this.logger.error(`Uploading document to iris failed due to ${e.message}`, leadId);
            throw CouldNotUploadDocumentForLead.create();
        }
    }
}
