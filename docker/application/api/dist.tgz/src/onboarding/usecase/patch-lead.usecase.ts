import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadService } from '@/onboarding/service/lead.service';

@Injectable()
export class PatchLeadUseCase implements UseCaseInterface {
    constructor(
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly leadService: LeadService,
        @InjectPinoLogger(PatchLeadUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(leadId: number, dto: AuditTrailLeadStepLogDto, input: string): Promise<void> {
        await this.leadService.updateLeadRaw(leadId, input);

        // Audit Trail step
        await this.leadAuditTrailStepLogRepository.save(LeadAuditTrailStepLog.create(dto));
    }
}
