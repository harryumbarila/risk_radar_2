import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { CreateSignatureResponseDto } from '../response/create-signature.response.dto';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';

// This usecase handles the logic for generating a signature using IRIS API
@Injectable()
export class CreateSignatureUseCase implements UseCaseInterface {
    private readonly signatureExpire: boolean = true;
    constructor(
        @InjectPinoLogger(CreateSignatureUseCase.name) private readonly logger: PinoLogger,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
    ) {}

    async handle(leadId: number): Promise<CreateSignatureResponseDto> {
        this.logger.info('Generate signature for lead ', leadId);
        return await this.irisClient.generateSignature(leadId.toString(), this.signatureExpire);
    }
}
