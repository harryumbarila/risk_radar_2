import { Injectable } from '@nestjs/common';
import { Lead } from '@/shared/model/lead.entity';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { Merchant } from '@/shared/model/merchant.entity';
import { CheckDuplicateLeadDto } from '../request/check-duplicate-lead.dto';
import { CreatedLead } from '../response/lead-list.response.dto';
import { LeadService } from '@/onboarding/service/lead.service';

/**
 * Represents a use case for creating a new lead.
 * After lead is created if merchant was registered with agent number we assign lead to this agent
 */
@Injectable()
export class CreateLeadUseCase implements UseCaseInterface {
    constructor(private leadService: LeadService) {}

    async handle(user: Merchant, dto?: CheckDuplicateLeadDto): Promise<Lead | CreatedLead> {
        if (dto) {
            const existingLead = this.leadService.checkDuplicateLead(dto);

            if (existingLead) {
                return existingLead;
            }
        }

        return await this.leadService.createLead(user);
    }
}
