import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';

export interface UsernameGeneratorConfig {
    USERNAME_GENERATOR_RANDOM_USERNAME: boolean;
}

@Injectable()
export class UsernameGenerator {
    constructor(private configService: ConfigService<UsernameGeneratorConfig>) {}

    generate(firstName: string, lastName: string, phoneNumber: string) {
        const random = this.configService.get('USERNAME_GENERATOR_RANDOM_USERNAME', false);

        let suffix: string = phoneNumber.substring(phoneNumber.length - 4);

        if (random) {
            suffix = <string>(<unknown>Date.now());
        }

        let username = (firstName + '_' + lastName + suffix).replace(/\s+/g, '');

        if (username.length > 50) {
            username = username.substring(0, 50);
        }

        return username;
    }
}
