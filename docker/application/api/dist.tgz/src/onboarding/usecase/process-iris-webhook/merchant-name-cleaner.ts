export class MerchantNameCleaner {
    static clean(merchantName: string, length: number = 25): string {
        // Remove any invalid characters
        let normalized = merchantName.replace(/[^a-zA-Z0-9\s&]/g, '');

        // Remove instances of '&' and '\''
        normalized = normalized.replace(/[&']/g, '');

        // Replace multiple spaces with a single space
        normalized = normalized.replace(/\s+/g, ' ');

        // Convert to lowercase
        normalized = normalized.toLowerCase();

        // Trim the result to be within the length constraint of 25 characters
        return normalized.substring(0, length).trim();
    }
}
