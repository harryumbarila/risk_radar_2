import { WebhookBody } from '@/shared/model/iris-webhook-body';

export interface IrisExtractorProcessorInterface {
    process(payload: WebhookBody): string | number | null;
}
