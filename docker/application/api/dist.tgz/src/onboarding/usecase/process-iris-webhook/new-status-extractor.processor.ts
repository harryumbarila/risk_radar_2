import { WebhookBody } from '@/shared/model/iris-webhook-body';
import { IrisExtractorProcessorInterface } from '@/onboarding/usecase/process-iris-webhook/iris-extractor.processor.interface';

export class NewStatusExtractorProcessor implements IrisExtractorProcessorInterface {
    process(payload: WebhookBody): string | null {
        if (payload && payload.data && payload.data.lead && payload.data.lead.newStatus && payload.data.lead.newStatus.name) {
            return payload.data.lead.newStatus.name;
        }

        return null;
    }
}
