import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadService } from '@/onboarding/service/lead.service';
import { Merchant } from '@/shared/model/merchant.entity';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { ContractResponseDto } from '@/onboarding/request/contract.response.dto';
import { LeadSignatureFactory } from '@/shared/model/lead/lead-signature.factory';
import { PDFTemplatesService } from '@/shared/pdf/templates.service';

/**
 * Get contract template for main owner
 */
@Injectable()
export class GetContractTemplateUseCase implements UseCaseInterface {
    constructor(
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly leadSignatureFactory: LeadSignatureFactory,
        private readonly pdfTemplatesService: PDFTemplatesService,
        private readonly leadService: LeadService,
        @InjectPinoLogger(GetContractTemplateUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(merchant: Merchant, auditTrailDto: AuditTrailLeadStepLogDto): Promise<ContractResponseDto> {
        // Check if Contract was signed by main owner
        const leadSignature = await this.leadService.checkIfMainOwnerSigned(merchant.lead);

        // Signed
        if (leadSignature && leadSignature.isSigned()) {
            return new ContractResponseDto();
        }

        const auditTrailDtoWithMerchant = auditTrailDto.override(merchant);

        // Not signed but generated
        if (leadSignature) {
            // Audit Trail step
            await this.leadAuditTrailStepLogRepository.save(
                LeadAuditTrailStepLog.create(
                    auditTrailDtoWithMerchant.overrideWithOwnerName(
                        new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
                        leadSignature.id,
                    ),
                ),
            );

            const urlFor = await this.pdfTemplatesService.getFileWithSignedUrl(leadSignature.contractTemplateKey);
            return new ContractResponseDto(urlFor, 'not_signed', leadSignature.id);
        }

        // Get lead
        const leadData = await this.leadService.getLead(merchant.lead.leadId);
        // const leadData = new PublicLeadDto();
        // leadData.owner_one = new Owner();
        // leadData.owner_one.first_name = 'John';
        // leadData.owner_one.last_name = 'Novak';
        // leadData.owner_one.email = 'tomasz.pobieralnia@gmail.com';

        // Generate template and signatures for all owners
        const ownerLeadSignature = await this.leadSignatureFactory.create(merchant, merchant.lead, leadData);

        // Audit Trail step
        await this.leadAuditTrailStepLogRepository.save(
            LeadAuditTrailStepLog.create(
                auditTrailDtoWithMerchant.overrideWithOwnerName(
                    new AuditTrailOwnerName(ownerLeadSignature.signatureName, ownerLeadSignature.signatureEmail),
                    ownerLeadSignature.id,
                ),
            ),
        );

        const url = await this.pdfTemplatesService.getFileWithSignedUrl(ownerLeadSignature.contractTemplateKey);

        return new ContractResponseDto(url, 'not_signed', ownerLeadSignature.id);
    }
}
