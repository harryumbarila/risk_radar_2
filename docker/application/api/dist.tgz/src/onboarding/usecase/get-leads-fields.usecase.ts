import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { IrisSymbolToken } from '../../shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '../../shared/webservice/iris/iris-client.interface';
import { GetFieldsResponseDto, Option } from '../response/get-fields.response.dto';

@Injectable()
export class GetLeadsFieldsUseCase implements UseCaseInterface {
    constructor(
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        @InjectPinoLogger(GetLeadsFieldsUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(fieldId: number): Promise<GetFieldsResponseDto> {
        const result = await this.irisClient.getLeadsFields(fieldId);
        return new GetFieldsResponseDto(result.options.dropdown as Option[]);
    }
}
