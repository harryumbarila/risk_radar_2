import { DomainError } from '@/shared/model/domain.error';

type ErrorName = 'ERROR' | 'COULD_NOT_CREATE_USER_EXISTS';

export class CreateLeadError extends DomainError<ErrorName> {}

export class CouldNotCreateUserExistsError extends CreateLeadError {
    public static create(accountSid: string, phoneNumber: string): CreateLeadError {
        return new this({
            name: 'COULD_NOT_CREATE_USER_EXISTS',
            message: `Could not create user for ${accountSid} using ${phoneNumber} - it exists, please contact CS`,
        });
    }
}
