import { Inject, Injectable } from '@nestjs/common';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { CreateSignatureResponseDto } from '@/onboarding/response/create-signature.response.dto';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { LeadService } from '@/onboarding/service/lead.service';

@Injectable()
export class CreateOnboardingSignatureUseCase implements UseCaseInterface {
    constructor(
        private readonly leadService: LeadService,
        @InjectPinoLogger(CreateOnboardingSignatureUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(applicationId: number): Promise<CreateSignatureResponseDto> {
        return this.leadService.createAndSendSignature(applicationId);
    }
}
