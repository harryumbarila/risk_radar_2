import { UseCaseInterface } from '@/shared/usecase.interface';
import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { InjectRepository } from '@nestjs/typeorm';
import { Merchant } from '@/shared/model/merchant.entity';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { Account } from '@/shared/model/account.entity';
import { CreateMerchantRequestDto } from '@/onboarding/request/create-merchant-request.dto';
import { GetMerchantResponseDto } from '@/onboarding/response/get-merchant-response.dto';
import { Lead } from '@/shared/model/lead.entity';
import { WebhookService } from '@/webhook/webhook.service';
import { LeadService } from '@/onboarding/service/lead.service';
import { TestingMidService } from '@/onboarding/service/testing-mid.service';

@Injectable()
export class CreateMerchantUseCase implements UseCaseInterface {
    constructor(
        private readonly leadService: LeadService,
        private readonly webhookService: WebhookService,
        private readonly testingMidService: TestingMidService,
        @InjectRepository(Merchant) private readonly merchantRepository: MerchantRepository,
        @InjectPinoLogger(CreateMerchantUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(account: Account, dto: CreateMerchantRequestDto): Promise<GetMerchantResponseDto> {
        this.logger.info(`Creating merchant for ${account.sid}`);

        const existingMerchant: Merchant | null = await this.merchantRepository.findOneBy({
            phoneNumber: dto.getCustomPhoneNumber().getNumber(),
            account: { id: account.id },
        });

        /**
         * If merchant exists return current merchant data
         */
        if (existingMerchant) {
            if (existingMerchant.lead?.leadId) {
                const data = await this.leadService.getLead(existingMerchant.lead.leadId);
                return GetMerchantResponseDto.createFromMerchantWithData(existingMerchant, data);
            }

            return GetMerchantResponseDto.createFromMerchant(existingMerchant);
        }

        const user = await this.merchantRepository.save(Merchant.create(dto.getCustomPhoneNumber(), account, dto.agent));
        await this.webhookService.createForMerchantCreated(account, GetMerchantResponseDto.createFromMerchant(user));

        let getMerchantResponseDto: GetMerchantResponseDto = null;

        /**
         * If there is merchant data we start full onboarding
         */
        if (dto.merchant) {
            // Create lead
            const lead: Lead = await this.leadService.createLead(user);
            // Fill the onboarding application
            const data = await this.leadService.updateLead(lead.leadId, dto.merchant);

            getMerchantResponseDto = GetMerchantResponseDto.createFromMerchantWithData(user, data);

            // For Testing in staging/sandbox auto approve merchant
            await this.testingMidService.triggerAutoApprove();
        }

        if (!getMerchantResponseDto) {
            getMerchantResponseDto = GetMerchantResponseDto.createFromMerchant(user);
        }

        await this.webhookService.createForMerchantProcessing(account, getMerchantResponseDto);

        return getMerchantResponseDto;
    }
}
