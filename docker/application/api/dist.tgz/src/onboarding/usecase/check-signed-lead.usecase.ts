import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { LeadService } from '@/onboarding/service/lead.service';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { OnboardingStatus } from '@/shared/model/lead.entity';

export interface CheckSignedLeadResponse {
    lead_id: string;
    signed: boolean;
}

@Injectable()
export class CheckSignedLeadUseCase implements UseCaseInterface {
    constructor(
        private readonly leadService: LeadService,
        private readonly leadRepository: LeadRepository,
        @InjectPinoLogger(CheckSignedLeadUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(applicationId: number): Promise<CheckSignedLeadResponse> {
        const signed = await this.leadService.checkSignedLead(applicationId);
        const lead = await this.leadRepository.findOneBy({ leadId: applicationId });

        if (!lead) {
            throw new NotFoundException(`Lead ${applicationId} not found`);
        }

        // Mark as completed if lead is in progress
        if (signed && lead.onboardingStatus === OnboardingStatus.IN_PROGRESS) {
            lead.onboardingStatus = OnboardingStatus.COMPLETED;
            await this.leadRepository.save(lead);
        }

        return {
            lead_id: applicationId as unknown as string,
            signed: signed,
        };
    }
}
