import { DomainError } from '../../../shared/model/domain.error';

type ErrorName = 'ERROR' | 'COULD_NOT_CREATE_LEAD_ALREADY_EXISTS';

export class CreateLeadError extends DomainError<ErrorName> {}

export class CouldNotCreateLeadAlreadyExists extends CreateLeadError {
    public static create(): CreateLeadError {
        return new this({
            name: 'COULD_NOT_CREATE_LEAD_ALREADY_EXISTS',
            message: `Could not create lead, please contact CS`,
        });
    }
}
