import { Request } from 'express';
import { Merchant } from '@/shared/model/merchant.entity';
import { IsString, IsIP, Length, IsNumber, validate, IsDefined, IsOptional, IsNotEmpty, ValidateNested } from 'class-validator';
import { DomainError } from '@/shared/model/domain.error';
import { OnboardingErrorCode } from '@/shared/model/error.constants';
import { Type } from 'class-transformer';

export class AuditTrailOwnerName {
    @IsNotEmpty({ message: 'First name cannot be empty.' })
    @IsString({ message: 'First name must be a string.' })
    @Length(1, 255, { message: 'First name must be between 1 and 255 characters.' })
    private readonly name: string;

    @IsNotEmpty({ message: 'Email cannot be empty.' })
    private readonly email: string;

    constructor(name: string, email: string) {
        this.name = name;
        this.email = email;
    }

    public toString(): string {
        return `${this.name} (${this.email})`;
    }
}

export type AuditTrailStepStepNameType =
    | 'unknown'
    | 'update-application'
    | 'download-contract'
    | 'sign-contract-by-main-owner'
    | 'sign-contract-by-extra-owner'
    | 'get-contract-template-for-main-owner'
    | 'get-contract-template-for-extra-owner'
    | 'mfa-verification'
    | 'mfa-register'
    | 'email-sending-extra-owner-a-sign'
    | 'email-sending-contract-signed'
    | 'clicked-on-link-to-sign-contract';

export class AuditTrailLeadStepLogDto {
    @IsString()
    @Length(1, 255)
    private endpoint: string;

    @IsString()
    @Length(1, 255)
    private stepName: string;

    @IsString()
    @Length(1, 255)
    private phoneNumber: string;

    @IsOptional()
    @ValidateNested({ message: 'Owner name is invalid.' })
    @Type(() => AuditTrailOwnerName)
    private ownerName?: AuditTrailOwnerName;

    @IsNumber()
    private timestamp: number;

    @IsIP()
    private ipAddress: string;

    @IsString()
    @Length(1, 255)
    private deviceBrowser: string;

    @IsString()
    @Length(1, 36)
    private merchantId: string;

    @IsString()
    @Length(1, 36)
    private merchantSid: string;

    @IsString()
    @Length(1, 36)
    private leadSid: string;

    @IsOptional()
    @IsString()
    @Length(1, 36)
    private leadSignatureId?: string;

    @IsOptional()
    private emailStatus?: 'sent' | 'failed_to_send';

    @IsOptional()
    private emailRecipient?: string;

    @IsDefined()
    @Length(1, 255)
    private requestId: string;

    static async fromRequest(
        request: Request,
        merchant: Merchant = null,
        stepName: AuditTrailStepStepNameType = 'unknown',
    ): Promise<AuditTrailLeadStepLogDto> {
        const logDTO = new AuditTrailLeadStepLogDto();

        logDTO.requestId = <string>request.id;
        logDTO.stepName = stepName;
        logDTO.timestamp = new Date().getTime();
        logDTO.ipAddress = request.ip ?? '127.0.0.1';
        logDTO.merchantId = merchant?.id ?? 'unknown';
        logDTO.merchantSid = merchant?.sid.toString() ?? 'unknown';
        logDTO.leadSid = merchant?.lead?.sid.toString() ?? 'unknown';
        logDTO.phoneNumber = merchant?.phoneNumber ?? 'unknown';
        logDTO.deviceBrowser = request.headers['user-agent'] || 'unknown';
        logDTO.endpoint = request.originalUrl;

        const errors = await validate(logDTO);

        if (errors.length > 0) {
            throw new DomainError<OnboardingErrorCode>({ name: 'AUDIT_TRAIL_ERROR', message: `${errors.toString()}` });
        }

        return logDTO;
    }

    override(merchant: Merchant): AuditTrailLeadStepLogDto {
        const newObject = new AuditTrailLeadStepLogDto();
        Object.assign(newObject, this);
        newObject.merchantId = merchant.id;
        newObject.merchantSid = merchant.sid.toString();
        newObject.leadSid = merchant.lead?.sid.toString() || 'unknown';

        return newObject;
    }

    overrideWithEmail(
        emailRecipient: string,
        emailStatus: 'sent' | 'failed_to_send',
        stepName: AuditTrailStepStepNameType,
        ownerName: AuditTrailOwnerName,
        leadSignatureId: string,
    ): AuditTrailLeadStepLogDto {
        const newObject = new AuditTrailLeadStepLogDto();
        Object.assign(newObject, this);
        newObject.emailStatus = emailStatus;
        newObject.emailRecipient = emailRecipient;
        newObject.stepName = stepName;
        newObject.ownerName = ownerName;
        newObject.leadSignatureId = leadSignatureId;

        return newObject;
    }

    overrideWithOwnerName(ownerName: AuditTrailOwnerName, leadSignatureId: string): AuditTrailLeadStepLogDto {
        const newObject = new AuditTrailLeadStepLogDto();
        Object.assign(newObject, this);
        newObject.ownerName = ownerName;
        newObject.leadSignatureId = leadSignatureId;

        return newObject;
    }

    overrideWithPhoneNumber(phoneNumber: string): AuditTrailLeadStepLogDto {
        const newObject = new AuditTrailLeadStepLogDto();
        Object.assign(newObject, this);
        newObject.phoneNumber = phoneNumber;

        return newObject;
    }

    getStepName(): string {
        return this.stepName;
    }

    getTimestamp(): number {
        return this.timestamp;
    }

    getIpAddress(): string {
        return this.ipAddress;
    }

    getDeviceBrowser(): string {
        return this.deviceBrowser;
    }

    getMerchantId(): string {
        return this.merchantId;
    }

    getMerchantSid(): string {
        return this.merchantSid;
    }

    getEndpoint(): string {
        return this.endpoint;
    }

    getLeadSid(): string {
        return this.leadSid;
    }

    getRequestId(): string {
        return this.requestId;
    }

    getEmailStatus(): 'sent' | 'failed_to_send' | undefined {
        return this.emailStatus;
    }

    getEmailRecipient(): string | undefined {
        return this.emailRecipient;
    }

    getOwnerName(): AuditTrailOwnerName | undefined {
        return this.ownerName;
    }

    getLeadSignatureId(): string | undefined {
        return this.leadSignatureId;
    }
}
