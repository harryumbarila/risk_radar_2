import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { ContractResponseDto } from '@/onboarding/request/contract.response.dto';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { PDFTemplatesService } from '@/shared/pdf/templates.service';

@Injectable()
export class GetContractTemplateForExtraOwnersUseCase implements UseCaseInterface {
    constructor(
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly merchantRepository: MerchantRepository,
        private readonly pdfTemplateService: PDFTemplatesService,
        @InjectPinoLogger(GetContractTemplateForExtraOwnersUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(leadSignatureId: string, auditTrailDto: AuditTrailLeadStepLogDto): Promise<ContractResponseDto> {
        const leadSignature = await this.leadSignatureRepository.findOneBy({ id: leadSignatureId });

        if (!leadSignature) {
            throw new NotFoundException('Lead signature not found');
        }

        const merchant = await this.merchantRepository.findOne({ where: { lead: { id: leadSignature.lead.id } }, relations: ['lead'] });

        if (!merchant) {
            throw new NotFoundException('Merchant not found');
        }

        // Audit Trail step
        const withMerchant = auditTrailDto.override(merchant);

        await this.leadAuditTrailStepLogRepository.save(
            LeadAuditTrailStepLog.create(
                withMerchant.overrideWithOwnerName(
                    new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
                    leadSignature.id,
                ),
            ),
        );

        // Signed
        if (leadSignature && leadSignature.isSigned()) {
            return new ContractResponseDto();
        }

        const url = await this.pdfTemplateService.getFileWithSignedUrl(leadSignature.contractTemplateKey);

        // Not signed but generated
        return new ContractResponseDto(url, 'not_signed');
    }
}
