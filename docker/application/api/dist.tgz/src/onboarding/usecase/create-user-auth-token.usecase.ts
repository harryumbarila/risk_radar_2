import { UseCaseInterface } from '@/shared/usecase.interface';
import { Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { Merchant } from '@/shared/model/merchant.entity';
import { Account } from '@/shared/model/account.entity';
import { JwtToken } from '@/shared/auth/jwt-token';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { CouldNotFindUserForAccount } from '@/onboarding/usecase/create-user-auth-token/create-user-auth-token.error';
import { AuthService } from '@/shared/auth/auth.service';

@Injectable()
export class CreateUserAuthTokenUseCase implements UseCaseInterface {
    constructor(
        private readonly userRepository: MerchantRepository,
        private readonly authService: AuthService,
        @InjectPinoLogger(CreateUserAuthTokenUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(account: Account, userSid: string): Promise<JwtToken> {
        this.logger.info(`Creating user auth token for account ${account.sid} and user ${userSid}`);

        const existingUser: Merchant | null = await this.userRepository.findUserFromAccount(account.sid.toString(), userSid);

        if (!existingUser) {
            throw CouldNotFindUserForAccount.create(account.sid.toString(), userSid);
        }

        return this.authService.generateJwtToken(existingUser);
    }
}
