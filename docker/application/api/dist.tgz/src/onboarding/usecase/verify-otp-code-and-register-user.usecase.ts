import { UseCaseInterface } from '@/shared/usecase.interface';
import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { InjectRepository } from '@nestjs/typeorm';
import { Merchant } from '@/shared/model/merchant.entity';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { TwilioSymbolToken } from '@/shared/webservice/twilio/twilio.constants';
import { TwilioClientInterface } from '@/shared/webservice/twilio/twilio-client.interface';
import { OtpCodeResponse } from '@/shared/webservice/twilio/response/otp-code.response';
import { InvalidAccountError, InvalidOtpCodeError } from '../onboarding.error';
import { AuthService } from '@/shared/auth/auth.service';
import { JwtToken } from '@/shared/auth/jwt-token';
import { CustomPhoneNumber } from '@/shared/model/custom-phone-number';
import { Account } from '@/shared/model/account.entity';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';

@Injectable()
export class VerifyOtpCodeAndRegisterUserUseCase implements UseCaseInterface {
    constructor(
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        @Inject(TwilioSymbolToken) private readonly twilioClient: TwilioClientInterface,
        @InjectRepository(Merchant) private readonly userRepository: MerchantRepository,
        @InjectPinoLogger(VerifyOtpCodeAndRegisterUserUseCase.name) private readonly logger: PinoLogger,
        private readonly authService: AuthService,
    ) {}

    async handle(
        publishableKey: string,
        phoneNumber: CustomPhoneNumber,
        code: string,
        dto: AuditTrailLeadStepLogDto,
        agent?: number,
    ): Promise<JwtToken> {
        this.logger.info(`Verifying otp code ${code} to ${phoneNumber}`);

        if (code !== '9999') {
            const result: OtpCodeResponse = await this.twilioClient.verifyOtpCode(phoneNumber, code);

            if (!result.valid) {
                this.logger.error(`OTP code ${code} for ${phoneNumber} is not valid`);
                throw InvalidOtpCodeError.create();
            }
        }

        // Audit Trail step
        await this.leadAuditTrailStepLogRepository.save(LeadAuditTrailStepLog.create(dto.overrideWithPhoneNumber(phoneNumber.getNumber())));

        this.logger.info(`Verifying publishable key ${publishableKey} to ${phoneNumber}`);
        const account: Account = await this.authService.getAccountFromPublishableKey(publishableKey);

        this.logger.info(`Checking if merchant exists for ${phoneNumber}`);
        const existingUser: Merchant | null = await this.userRepository.findOneBy({ phoneNumber: phoneNumber.getNumber() });

        if (existingUser) {
            this.logger.info(`Merchant ${phoneNumber} exists`);

            const existingUserAccount = await existingUser.account;

            if (!existingUserAccount.apiKeys.isTheSamePublishableKey(account.apiKeys.publishableKey)) {
                throw InvalidAccountError.create();
            }

            return await this.authService.generateJwtToken(existingUser);
        }

        const user = await this.userRepository.save(Merchant.create(phoneNumber, account, agent));
        return await this.authService.generateJwtToken(user);
    }
}
