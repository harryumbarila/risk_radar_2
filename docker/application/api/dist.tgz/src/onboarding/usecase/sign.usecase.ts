import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadService } from '@/onboarding/service/lead.service';
import { SignRequestDto } from '@/onboarding/request/sign.request.dto';
import { Merchant } from '@/shared/model/merchant.entity';
import { SignResponseDto } from '@/onboarding/request/sign.response.dto';
import { SlackSymbolToken } from '@/shared/webservice/slack/slack.constant';
import { SlackInterface } from '@/shared/webservice/slack/slack.interface';

@Injectable()
export class SignUseCase implements UseCaseInterface {
    constructor(
        private readonly leadService: LeadService,
        @Inject(SlackSymbolToken) private readonly slackClient: SlackInterface,
        @InjectPinoLogger(SignUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(merchant: Merchant, auditTrailDto: AuditTrailLeadStepLogDto, dto: SignRequestDto): Promise<SignResponseDto> {
        // if (merchant.lead.onboardingStatus !== 'COMPLETED') {
        //     throw new DomainError<SignErrorCode>({
        //         name: 'ONBOARDING_SIGN_ERROR_ONBOARDING_STATUS_IS_NOT_COMPLETED',
        //         message: 'Onboarding application is different than completed',
        //     });
        // }

        try {
            await this.leadService.sign(merchant, dto.lead_signature_id, auditTrailDto);
            return { ...new SignResponseDto(), message: 'Signed' };
        } catch (e) {
            this.logger.error(e);
            await this.slackClient.postOnOnboarding(
                `Failed onboarding - signing contract ${dto.lead_signature_id} by main owner ${e.message}`,
            );
            throw e;
        }
    }
}
