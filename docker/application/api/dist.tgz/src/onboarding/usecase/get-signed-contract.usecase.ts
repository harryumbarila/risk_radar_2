import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from 'src/shared/usecase.interface';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { GetObjectCommandOutput } from '@aws-sdk/client-s3';
import { PDFTemplatesService } from '@/shared/pdf/templates.service';

/**
 * Get contract template for main owner
 */
@Injectable()
export class GetSignedContractUseCase implements UseCaseInterface {
    constructor(
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly merchantRepository: MerchantRepository,
        private readonly pdfTemplatesService: PDFTemplatesService,
        @InjectPinoLogger(GetSignedContractUseCase.name) private readonly logger: PinoLogger,
    ) {}

    async handle(leadSignatureId: string, auditTrailDto: AuditTrailLeadStepLogDto): Promise<GetObjectCommandOutput> {
        const leadSignature = await this.leadSignatureRepository.findOneBy({ id: leadSignatureId });

        if (!leadSignature) {
            throw new NotFoundException('Lead signature not found');
        }

        if (!leadSignature.isSigned()) {
            throw new NotFoundException('Lead signature is not signed');
        }

        const merchant = await this.merchantRepository.findOne({ where: { lead: { id: leadSignature.lead.id } }, relations: ['lead'] });

        if (!merchant) {
            throw new NotFoundException('Merchant not found');
        }

        // Audit Trail Step
        const auditTrailWithMerchant = auditTrailDto.override(merchant);
        const auditTrailWithOwner = auditTrailWithMerchant.overrideWithOwnerName(
            new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
            leadSignature.id,
        );

        await this.leadAuditTrailStepLogRepository.save(LeadAuditTrailStepLog.create(auditTrailWithOwner));

        return this.pdfTemplatesService.getFile(leadSignature.signedContractKey);
    }
}
