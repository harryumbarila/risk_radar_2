import { DomainError } from '@/shared/model/domain.error';
import { OnboardingErrorCode } from '@/shared/model/error.constants';

export class CreateUserAuthTokenError extends DomainError<OnboardingErrorCode> {}

export class CouldNotFindUserForAccount extends CreateUserAuthTokenError {
    public static create(accountSid: string, userSid: string): CreateUserAuthTokenError {
        return new this({
            name: 'COULD_NOT_FIND_USER_FROM_ACCOUNT',
            message: `Could not find user for account ${accountSid} using user sid ${userSid} - please contact CS`,
        });
    }
}
