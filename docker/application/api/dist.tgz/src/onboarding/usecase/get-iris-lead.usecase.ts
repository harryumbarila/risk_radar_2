import { Inject, Injectable } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { UseCaseInterface } from '@/shared/usecase.interface';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { InjectRepository } from '@nestjs/typeorm';
import { Lead } from '@/shared/model/lead.entity';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { GetLeadResponseDto } from '../response/get-lead-response.dto';

@Injectable()
export class GetIrisLeadUseCase implements UseCaseInterface {
    constructor(
        @InjectPinoLogger(GetIrisLeadUseCase.name) private readonly logger: PinoLogger,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        @InjectRepository(Lead) private readonly leadRepository: LeadRepository,
    ) {}

    async handle(id: number): Promise<GetLeadResponseDto> {
        this.logger.info('Getting lead information from IRIS', id);

        // todo add proper auth to fetch lead from auth merchant
        const lead: Lead | null = await this.leadRepository.findOneBy({ leadId: id });

        if (!lead) {
            this.logger.error(`Could not find lead id ${id}`);
            throw new Error('Could not find lead id');
        }

        const data = await this.irisClient.getLead(id);

        return new GetLeadResponseDto(id, lead.onboardingStatus, data);
    }
}
