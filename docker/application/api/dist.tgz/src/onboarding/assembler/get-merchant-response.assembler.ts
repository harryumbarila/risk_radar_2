import { AorakiPaymentsClientInterface, AorakiPaymentsSymbolToken } from '@/shared/webservice/aoraki-payments/aoraki-payments.client';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { Merchant } from '@/shared/model/merchant.entity';
import { GetMerchantResponseDto, MerchantPayment } from '@/onboarding/response/get-merchant-response.dto';
import { Inject, Injectable } from '@nestjs/common';

@Injectable()
export class GetMerchantResponseAssembler {
    constructor(@Inject(AorakiPaymentsSymbolToken) private readonly client: AorakiPaymentsClientInterface) {}

    async createDtoWithAdditionalInfo(merchant: Merchant, dto?: PublicLeadDto): Promise<GetMerchantResponseDto> {
        const response = dto
            ? GetMerchantResponseDto.createFromMerchantWithData(merchant, dto)
            : GetMerchantResponseDto.createFromMerchant(merchant);

        const account = await merchant.account;

        try {
            const aorakiMerchant = await this.client.getMerchant(
                account.sid.toString(),
                account.apiKeys.secretKey,
                merchant.sid.toString(),
            );

            response.payment = {
                tokenizer_publishable_key: aorakiMerchant.publishable_key,
                terminal_id: aorakiMerchant.terminal_id,
            } as MerchantPayment;
        } catch (e) {
            // and/or checking merchant status before calling this.client.getMerchant
        }

        return response;
    }
}
