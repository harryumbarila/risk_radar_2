import { ApiProperty } from '@nestjs/swagger';

export class SignResponseDto {
    @ApiProperty()
    message: string;
}
