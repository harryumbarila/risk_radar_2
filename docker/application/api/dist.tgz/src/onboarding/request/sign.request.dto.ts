import { IsString, IsNotEmpty, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SignRequestDto {
    @ApiProperty()
    @IsString({ message: 'md5 of contract template - signature must be a string' })
    @IsNotEmpty({ message: 'signature must not be empty' })
    @Matches(/^[a-fA-F0-9]{32}$/, {
        message: 'signature must be a valid MD5 hash (32-character hexadecimal string)',
    })
    contract_signature_hash: string;

    @ApiProperty()
    @IsString({ message: 'lead signature id must be a string' })
    @IsNotEmpty({ message: 'lead signature id must not be empty' })
    lead_signature_id: string;
}
