import { Allow, IsDefined, IsEnum, IsNumber, IsOptional, IsString, ValidateNested } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { Match } from '@/shared/validator/match.constraint';
import { SumOfPercentagesEquals100 } from '@/shared/validator/sum-of-percentages-equals-100.constraint';

export enum TinType {
    EIN = 'EIN',
    SSN = 'SSN',
    ITIN = 'ITIN',
}

export class MainContactPerson {
    @ApiProperty()
    @IsString()
    readonly name: string;

    @ApiProperty()
    @IsString()
    readonly email: string;
}

export class BankAccount {
    @ApiProperty()
    @IsString()
    readonly bank_name: string;

    @ApiProperty()
    @IsString()
    readonly routing_number: string;

    @ApiProperty()
    @IsString()
    readonly account_holder_name: string;

    @ApiProperty()
    @IsString()
    readonly account_number: string;

    @ApiProperty()
    @IsString()
    @Match<BankAccount>('account_number')
    readonly account_number_confirm: string;
}

export class SalesPercentage {
    @ApiProperty()
    card_swipe_percentage: string;

    @ApiProperty()
    moto_percentage: string;

    @ApiProperty()
    online_percentage: string;

    @ApiProperty()
    keyed_percentage: string;
}

export class Sales {
    @ApiProperty()
    @IsDefined()
    readonly average_monthly_in_credit_card: string;

    @ApiProperty()
    @IsDefined()
    readonly average_ticket_value: string;

    @ApiProperty()
    @IsDefined()
    readonly highest_amount_to_date: string;

    @ApiProperty()
    @IsDefined()
    @Type(() => SalesPercentage)
    @SumOfPercentagesEquals100()
    readonly sales_percentage: SalesPercentage;

    @ApiProperty()
    @IsDefined()
    readonly average_amex_monthly_sales: string;

    @ApiProperty()
    @IsDefined()
    readonly average_amex_ticket_value: string;
}

export class Product {
    @ApiProperty()
    @IsString()
    readonly description: string;

    @ApiProperty()
    @IsString()
    readonly category: string;

    @ApiProperty()
    @IsString()
    readonly subcategory: string;

    @ApiProperty()
    @IsString()
    readonly website: string;
}

export class Address {
    @ApiProperty()
    @IsString()
    readonly address: string;

    @ApiProperty()
    @IsString()
    readonly city: string;

    @ApiProperty()
    @IsString()
    readonly state: string;

    @ApiProperty()
    @IsString()
    readonly zip: string;
}

export class Authority {
    authorized_signer: boolean = true;
    manager_controller: boolean = false;
    personal_guarantee: boolean = false;
    authorized_contact: boolean = false;
}

export class Owner {
    @ApiProperty()
    @IsString()
    first_name: string;

    @ApiProperty()
    @IsString()
    last_name: string;

    @ApiPropertyOptional()
    @IsOptional()
    @IsString()
    readonly middle_name?: string;

    @ApiProperty()
    @IsString()
    readonly job_title: string;

    @Allow()
    @Type(() => Authority)
    authority: Authority;

    @ApiProperty()
    @IsNumber()
    readonly ownership_percentage: string;

    @ApiProperty()
    @IsString()
    email: string;

    @ApiProperty()
    @IsString()
    readonly date_of_birth: string;

    @ApiProperty()
    @IsDefined()
    @Type(() => Address)
    readonly home_address: Address;

    @ApiProperty()
    @IsString()
    readonly ssn: string;
}

export class PublicLeadDto {
    @ApiProperty()
    @IsString()
    legal_business_name: string;

    @ApiProperty()
    @IsString()
    legal_phone: string;

    @ApiPropertyOptional()
    @IsOptional()
    @IsString()
    readonly business_phone?: string;

    @ApiProperty()
    @IsString()
    readonly business_type: string;

    @ApiProperty()
    @IsDefined()
    @ValidateNested()
    @Type(() => BankAccount)
    readonly bank_account: BankAccount;

    @ApiProperty()
    @IsString()
    readonly tin: string;

    @ApiProperty({ enum: TinType, enumName: 'TinType' })
    @IsEnum(TinType)
    readonly tin_type: TinType;

    @ApiPropertyOptional()
    @IsOptional()
    @IsString()
    doing_business_as?: string;

    @ApiProperty()
    @IsString()
    readonly business_established_date: string;

    @ApiProperty()
    @IsDefined()
    @Type(() => Address)
    readonly legal_business_address: Address;

    @ApiPropertyOptional()
    @IsOptional()
    @Type(() => Address)
    readonly dba_address?: Address;

    @ApiProperty()
    @IsDefined()
    @Type(() => Owner)
    owner_one: Owner;

    @ApiPropertyOptional()
    @IsOptional()
    @Type(() => Owner)
    owner_two?: Owner;

    @ApiPropertyOptional()
    @IsOptional()
    @Type(() => Owner)
    owner_three?: Owner;

    @ApiPropertyOptional()
    @IsOptional()
    @Type(() => Owner)
    owner_four?: Owner;

    @ApiProperty()
    @IsDefined()
    @Type(() => Product)
    readonly main_product: Product;

    @ApiProperty()
    @IsDefined()
    @Type(() => MainContactPerson)
    main_contact_person: MainContactPerson;

    @ApiProperty()
    @IsDefined()
    @Type(() => Sales)
    @ValidateNested()
    current_sales: Sales;

    configureOwners() {
        if (this.owner_one) {
            this.owner_one.authority = new Authority();
            this.owner_one.authority.authorized_signer = true;
            this.owner_one.authority.manager_controller = true;
        }

        if (this.owner_two) {
            this.owner_two.authority = new Authority();
            this.owner_two.authority.authorized_signer = true;
        }

        if (this.owner_three) {
            this.owner_three.authority = new Authority();
            this.owner_three.authority.authorized_signer = true;
        }

        if (this.owner_four) {
            this.owner_four.authority = new Authority();
            this.owner_four.authority.authorized_signer = true;
        }
    }
}
