import { IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class PatchLeadRequestDto {
    @ApiProperty()
    @IsNotEmpty()
    readonly input: string;
}
