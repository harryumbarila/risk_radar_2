import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { RegisterNumberRequestDto } from './register-number.request.dto';

export class VerifyOtpCodeRequestDto extends RegisterNumberRequestDto {
    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    readonly publishable_key: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    readonly code: string;

    @ApiPropertyOptional()
    @IsOptional()
    @IsNumber()
    readonly agent?: number;
}
