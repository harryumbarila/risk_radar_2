import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class ContractResponseDto {
    @ApiProperty({
        description: 'Contract for main owner - URL to PDF for download. If contract was signed or still missing data its a null',
        examples: {
            unsigned: 'https://example.com/contract.pdf',
            signed: null,
        },
    })
    contract_url: string | null;

    @ApiProperty({ description: 'Describes the current signature status: "signed" or "not_signed"' })
    status: 'signed' | 'not_signed';

    @ApiPropertyOptional({ description: 'Generated signature for pdf template', example: 'uuidv7' })
    lead_signature_id?: string;

    constructor(signed: string | null = null, status: 'signed' | 'not_signed' = 'signed', leadSignatureId: string | null = null) {
        this.lead_signature_id = leadSignatureId;
        this.contract_url = signed;
        this.status = status;
    }
}
