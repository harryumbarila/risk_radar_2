import { IsMobilePhone, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { CustomPhoneNumber } from '@/shared/model/custom-phone-number';

export class RegisterNumberRequestDto {
    @ApiProperty()
    @IsMobilePhone()
    @MaxLength(11)
    readonly phone: string;

    getCustomPhoneNumber() {
        return new CustomPhoneNumber(this.phone);
    }
}
