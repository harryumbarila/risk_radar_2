import { IsOptional, ValidateNested } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { RegisterNumberRequestDto } from '@/onboarding/request/register-number.request.dto';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { Type } from 'class-transformer';

export class CreateMerchantRequestDto extends RegisterNumberRequestDto {
    @ApiPropertyOptional()
    @IsOptional()
    readonly agent?: number;

    /**
     * Represents optional merchant information. If passed we will create merchant with a lead and pass to it to the external system
     * @todo change name for PublicLeadDto
     */
    @ApiPropertyOptional()
    @IsOptional()
    @ValidateNested()
    @Type(() => PublicLeadDto)
    readonly merchant?: PublicLeadDto;
}
