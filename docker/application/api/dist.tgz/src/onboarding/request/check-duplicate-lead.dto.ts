import { IsDefined, IsNotEmpty, IsString, MaxLength, MinLength, ValidateNested } from 'class-validator';
import { ApiProperty, PickType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { Address, Owner, PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';

export class OwnerLeadDto extends PickType(Owner, ['first_name', 'last_name', 'email'] as const) {}

export class CheckDuplicateLeadDto extends PickType(PublicLeadDto, [
    'legal_business_name',
    'doing_business_as',
    'dba_address',
    'legal_phone',
] as const) {
    @ApiProperty({ description: 'Business address', type: Address, required: true })
    @IsDefined()
    @ValidateNested()
    @Type(() => Address)
    public dba_address: Address;

    @ApiProperty({ description: 'Doing business as', required: true })
    @IsString()
    @MaxLength(255)
    @MinLength(1)
    @IsNotEmpty()
    doing_business_as: string;

    @ApiProperty({ type: OwnerLeadDto })
    @IsDefined()
    @ValidateNested()
    @Type(() => OwnerLeadDto)
    owner: OwnerLeadDto;
}
