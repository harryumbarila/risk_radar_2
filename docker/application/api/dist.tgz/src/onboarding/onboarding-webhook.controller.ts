import { Controller, HttpCode, HttpStatus, Param, Post, Req } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { Request } from 'express';
import { ProcessIrisWebhookUseCase } from '@/onboarding/usecase/process-iris-webhook.usecase';

@ApiTags('onboarding-external-webhooks')
@Controller('/v1/onboarding/webhooks')
export class OnboardingWebhookController {
    constructor(
        private readonly processIrisWebhookUseCase: ProcessIrisWebhookUseCase,
        @InjectPinoLogger(OnboardingWebhookController.name) private readonly logger: PinoLogger,
    ) {}

    @ApiResponse({
        status: 200,
        description: 'Webhook receiver for external merchant services ex. IRIS',
    })
    @ApiOperation({ operationId: 'Webhook receiver' })
    @Public()
    @HttpCode(HttpStatus.OK)
    @Post('/iris')
    async index(@Req() request: Request) {
        await this.processIrisWebhookUseCase.handle(request.body);

        return {
            message: 'OK',
        };
    }
}
