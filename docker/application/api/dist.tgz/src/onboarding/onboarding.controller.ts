import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Inject,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Req,
    UnauthorizedException,
    UploadedFile,
    UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RegisterNumberRequestDto } from './request/register-number.request.dto';
import { SendOtpCodeUseCase } from './usecase/send-otp-code.usecase';
import { VerifyOtpCodeRequestDto } from './request/verify-otp-code.request.dto';
import { VerifyOtpCodeAndRegisterUserUseCase } from './usecase/verify-otp-code-and-register-user.usecase';
import { JwtToken } from '@/shared/auth/jwt-token';
import { RegisterNumberResponseDto } from './response/register-number.response.dto';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { CreateLeadResponseDto } from './response/create-lead.response.dto';
import { CurrentMerchant } from '@/shared/auth/decorator/current-user.decorator';
import { Merchant } from '@/shared/model/merchant.entity';
import { CreateLeadUseCase } from './usecase/create-lead.usecase';
import { PatchLeadUseCase } from './usecase/patch-lead.usecase';
import { Request } from 'express';
import { GetFieldsResponseDto } from './response/get-fields.response.dto';
import { GetLeadsFieldsUseCase } from './usecase/get-leads-fields.usecase';
import { CreateSignatureResponseDto } from './response/create-signature.response.dto';
import { CreateSignatureUseCase } from './usecase/create-signature.usecase';
import { GetIrisLeadUseCase } from './usecase/get-iris-lead.usecase';
import { GetLeadResponseDto } from './response/get-lead-response.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { CustomFileValidationPipe } from '@/shared/validator/custom-file-type-validator.pipe';
import { UploadDocumentForLeadUseCase } from './usecase/upload-document-for-lead.usecase';
import { LeadListDto } from './response/lead-list.response.dto';
import { PublicLeadDto } from './request/public-lead.request.dto';
import { IrisMapper } from '@/shared/irisMappings/iris-mapper';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { GetMerchantResponseDto } from '@/onboarding/response/get-merchant-response.dto';
import { CheckDuplicateLeadDto } from '@/onboarding/request/check-duplicate-lead.dto';
import { ConfigureOwnersPipeTransformer } from '@/shared/transformer/configure-owners.pipe.transformer';
import { CreateOnboardingSignatureUseCase } from '@/onboarding/usecase/create-onboarding-signature.usecase';
import { CheckSignedLeadResponse, CheckSignedLeadUseCase } from '@/onboarding/usecase/check-signed-lead.usecase';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { SignRequestDto } from '@/onboarding/request/sign.request.dto';
import { SignUseCase } from '@/onboarding/usecase/sign.usecase';
import { SignResponseDto } from '@/onboarding/request/sign.response.dto';
import { ContractResponseDto } from '@/onboarding/request/contract.response.dto';
import { GetContractTemplateUseCase } from '@/onboarding/usecase/get-contract-template.usecase';

@ApiTags('Onboarding')
@Controller(['/api/v1/onboarding', '/v1/onboarding'])
export class OnboardingController {
    constructor(
        private readonly sendOtpCodeUseCase: SendOtpCodeUseCase,
        private readonly verifyOtpCodeAndRegisterUserUseCase: VerifyOtpCodeAndRegisterUserUseCase,
        private readonly createLeadUseCase: CreateLeadUseCase,
        private readonly patchLeadUseCase: PatchLeadUseCase,
        private readonly getLeadsFieldsUseCase: GetLeadsFieldsUseCase,
        private readonly createSignatureUseCase: CreateSignatureUseCase,
        private readonly getIrisLeadUseCase: GetIrisLeadUseCase,
        private readonly signUseCase: SignUseCase,
        private readonly getContractTemplate: GetContractTemplateUseCase,
        private readonly uploadDocumentForLeadUseCase: UploadDocumentForLeadUseCase,
        private readonly createOnboardingSignatureUseCase: CreateOnboardingSignatureUseCase,
        private readonly checkSignedLeadUseCase: CheckSignedLeadUseCase,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        private readonly irisMapper: IrisMapper,
    ) {}

    @ApiResponse({
        status: 200,
        description: 'Send otp code to mobile number.',
        type: RegisterNumberResponseDto,
    })
    @Public()
    @HttpCode(HttpStatus.OK)
    @ApiOperation({ operationId: 'Send OTP Code' })
    @Post('/register_number')
    async sendOtpCode(@Req() request: Request, @Body() dto: RegisterNumberRequestDto): Promise<RegisterNumberResponseDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, null, 'mfa-register');
        await this.sendOtpCodeUseCase.handle(dto.getCustomPhoneNumber(), auditTrailDto);
        return new RegisterNumberResponseDto();
    }

    @ApiResponse({
        status: 201,
        description: 'Verification code with mobile number. If everything works we create merchant and return JWT token',
        type: JwtToken,
    })
    @ApiOperation({ operationId: 'Verify number' })
    @HttpCode(HttpStatus.CREATED)
    @Public()
    @Post('/verify_number')
    async verifyNumber(@Req() request: Request, @Body() dto: VerifyOtpCodeRequestDto): Promise<JwtToken> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, null, 'mfa-verification');
        return await this.verifyOtpCodeAndRegisterUserUseCase.handle(
            dto.publishable_key,
            dto.getCustomPhoneNumber(),
            dto.code,
            auditTrailDto,
            dto.agent,
        );
    }

    @ApiResponse({
        status: 200,
        description: 'Creates a lead with the phone number provided',
        type: CreateLeadResponseDto,
    })
    @ApiOperation({ operationId: 'Create a lead', deprecated: true })
    @ApiTags('deprecated-onboarding')
    @ApiBearerAuth('account-merchant-session-token')
    @Post('/lead')
    async createLead(@CurrentMerchant() user: Merchant): Promise<CreateLeadResponseDto | LeadListDto> {
        const lead = await this.createLeadUseCase.handle(user);
        if ('created_at' in lead) return { leads: [lead] };

        const response = new CreateLeadResponseDto(lead);
        return response;
    }

    @ApiResponse({
        status: 200,
        description: 'Patch a lead  with the phone number provided.',
        type: CreateLeadResponseDto,
    })
    @ApiOperation({ operationId: 'Patch a lead', deprecated: true })
    @ApiTags('deprecated-onboarding')
    @ApiBearerAuth('account-merchant-session-token')
    @Patch('/lead/:id')
    async patchLead(@CurrentMerchant() merchant: Merchant, @Param('id', ParseIntPipe) id: number, @Req() request: Request): Promise<void> {
        const dto = await AuditTrailLeadStepLogDto.fromRequest(request, merchant, 'update-application');
        return this.patchLeadUseCase.handle(id, dto, JSON.stringify(request.body));
    }

    @ApiResponse({
        status: 200,
        description: 'Calls the signature API, generating a link to sign the document',
        type: CreateSignatureResponseDto,
    })
    @ApiOperation({ operationId: 'Create signature', deprecated: true })
    @ApiTags('deprecated-onboarding')
    @ApiBearerAuth('account-merchant-session-token')
    @Post('/signature/:id')
    async createSignature(@Param('id') leadId: number): Promise<CreateSignatureResponseDto> {
        return await this.createSignatureUseCase.handle(leadId);
    }

    @ApiResponse({
        status: 200,
        description: 'Get lead fields',
        type: GetFieldsResponseDto,
    })
    @ApiOperation({ operationId: 'Get lead fields', deprecated: true })
    @ApiTags('deprecated-onboarding')
    @ApiBearerAuth('account-merchant-session-token')
    @Get('/lead/field/:id')
    async getFields(@Param('id', ParseIntPipe) id: number): Promise<GetFieldsResponseDto> {
        return await this.getLeadsFieldsUseCase.handle(id);
    }

    @ApiResponse({
        status: 200,
        description: 'Get lead',
        type: GetLeadResponseDto,
    })
    @ApiOperation({ operationId: 'Get lead', deprecated: true })
    @ApiTags('deprecated-onboarding')
    @ApiBearerAuth('account-merchant-session-token')
    @Get('/lead/:id')
    async getIrisLead(@Param('id', ParseIntPipe) id: number): Promise<GetLeadResponseDto> {
        return await this.getIrisLeadUseCase.handle(id);
    }

    @ApiBearerAuth('account-merchant-session-token')
    @ApiResponse({
        status: 200,
        description: 'Upload document for the lead',
    })
    @ApiOperation({ operationId: 'Upload document', deprecated: true })
    @Post('/lead/:id/document')
    @ApiTags('deprecated-onboarding')
    @UseInterceptors(FileInterceptor('file'))
    @HttpCode(HttpStatus.OK)
    async uploadDocument(
        @Param('id', ParseIntPipe) id: number,
        @UploadedFile(
            new CustomFileValidationPipe(
                [
                    'image/jpeg', // jpeg
                    'image/png', // png
                    'application/pdf', // pdf
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // docx
                    'application/msword', // doc
                    'image/tiff', // tiff
                ],
                /**
                 * Max size in bytes
                 */
                52_428_800,
            ),
        )
        file: Express.Multer.File,
        @CurrentMerchant() user: Merchant,
    ) {
        if (!(user.lead && user.lead.leadId === id)) {
            throw new UnauthorizedException('User does not belong to the lead');
        }

        await this.uploadDocumentForLeadUseCase.handle(id, file);
    }

    @ApiResponse({
        status: 200,
        description: 'Get onboarding application',
        type: PublicLeadDto,
    })
    @ApiOperation({ operationId: 'Get onboarding application' })
    @Get('/application/:application_id')
    async publicGetIrisLead(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) applicationId: number,
    ): Promise<PublicLeadDto> {
        const data = await this.irisClient.getLead(applicationId);
        return this.irisMapper.fromIrisToNormalizedDto(JSON.stringify(data));
    }

    @ApiResponse({
        status: 200,
        description: 'Create onboarding application',
        type: CreateLeadResponseDto,
    })
    @ApiOperation({ operationId: 'Create onboarding application' })
    @ApiBearerAuth('account-merchant-session-token')
    @Post('/application')
    async publicCreateIrisLead(
        @CurrentMerchant() merchant: Merchant,
        @Body() dto: CheckDuplicateLeadDto,
    ): Promise<CreateLeadResponseDto | LeadListDto> {
        const lead = await this.createLeadUseCase.handle(merchant, dto);
        if ('created_at' in lead) return { leads: [lead] };

        return new CreateLeadResponseDto(lead);
    }

    @ApiResponse({
        status: 200,
        description: 'Update onboarding application',
        type: PublicLeadDto,
    })
    @ApiOperation({ operationId: 'Update onboarding application' })
    @ApiBearerAuth('account-merchant-session-token')
    @Put('/application/:application_id')
    async publicUpdateIrisLead(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) id: number,
        @Body(ConfigureOwnersPipeTransformer) dto: PublicLeadDto,
        @Req() request: Request,
    ): Promise<PublicLeadDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, merchant, 'update-application');
        let str = this.irisMapper.fromNormalizedDtoToIris(dto);
        await this.patchLeadUseCase.handle(id, auditTrailDto, str);
        const data = await this.irisClient.getLead(id);
        return this.irisMapper.fromIrisToNormalizedDto(JSON.stringify(data));
    }

    @ApiResponse({
        status: 200,
        description: 'Sign the contract, by any owner',
        type: SignResponseDto,
    })
    @ApiOperation({ operationId: 'Sign the contract by owner' })
    @ApiBearerAuth('account-merchant-session-token')
    @Post('/application/:application_id/sign')
    async signApplication(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) id: number,
        @Body() dto: SignRequestDto,
        @Req() request: Request,
    ): Promise<SignResponseDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, merchant, 'sign-contract-by-main-owner');
        return this.signUseCase.handle(merchant, auditTrailDto, dto);
    }

    @ApiResponse({
        status: 200,
        description: 'Get the contract, by main owner to sign',
        type: ContractResponseDto,
    })
    @ApiOperation({ operationId: 'Sign the contract by any owner' })
    @ApiBearerAuth('account-merchant-session-token')
    @Get('/application/:application_id/contract')
    async getContract(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) applicationId: number,
        @Req() request: Request,
    ): Promise<ContractResponseDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, merchant, 'get-contract-template-for-main-owner');
        return this.getContractTemplate.handle(merchant, auditTrailDto);
    }

    @ApiResponse({
        status: 200,
        description: 'Create onboarding application signature, which is required to sign in web by first owner',
    })
    @ApiOperation({ operationId: 'Create onboarding application signature', deprecated: true })
    @Post('/application/:application_id/signature')
    async createApplicationSignature(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) id: number,
    ): Promise<CreateSignatureResponseDto> {
        // TODO: add leadId check
        return this.createOnboardingSignatureUseCase.handle(id);
    }

    /**
     * Temporary endpoint
     */
    @ApiResponse({
        status: 200,
        description: 'Check if application was signed by anyone - temporary endpoint',
    })
    @ApiOperation({ operationId: 'Application onboarding signed status', deprecated: true })
    @Get('/application/:application_id/signed')
    async signed(
        @CurrentMerchant() merchant: Merchant,
        @Param('application_id', ParseIntPipe) id: number,
    ): Promise<CheckSignedLeadResponse> {
        // TODO: add leadId check
        return this.checkSignedLeadUseCase.handle(id);
    }

    @ApiResponse({
        status: 200,
        description: 'Get merchant object',
        type: GetMerchantResponseDto,
    })
    @ApiOperation({ operationId: 'Get onboarding application status' })
    @ApiBearerAuth('account-merchant-session-token')
    @Get('/status')
    async status(@CurrentMerchant() merchant: Merchant): Promise<GetMerchantResponseDto> {
        return GetMerchantResponseDto.createFromMerchant(merchant);
    }
}
