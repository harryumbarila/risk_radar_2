import { EmailTemplateMessage } from '@/email/email-template-message';
import { EmailService } from '@/email/email.service';
import { CheckDuplicateLeadDto } from '@/onboarding/request/check-duplicate-lead.dto';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { CreateSignatureResponseDto } from '@/onboarding/response/create-signature.response.dto';
import { CreatedLead, LeadListDto } from '@/onboarding/response/lead-list.response.dto';
import { DidAllOwnersSignSpecification } from '@/onboarding/service/specification/did-all-owners-sign.specification';
import { CouldNotCreateLeadAlreadyExists } from '@/onboarding/usecase/create-lead/create-lead.error';
import { AuditTrailLeadStepLogDto, AuditTrailOwnerName } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { IrisMapper } from '@/shared/irisMappings/iris-mapper';
import { CustomPhoneNumber } from '@/shared/model/custom-phone-number';
import { DomainError } from '@/shared/model/domain.error';
import { SignErrorCode } from '@/shared/model/error.constants';
import { Lead, OnboardingStatus } from '@/shared/model/lead.entity';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { Merchant } from '@/shared/model/merchant.entity';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { PDFService } from '@/shared/pdf/pdf.service';
import { UrlGenerator } from '@/shared/url/url.generator';
import { IrisClientInterface } from '@/shared/webservice/iris/iris-client.interface';
import { CreateLeadResponse } from '@/shared/webservice/iris/iris.client';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { OwnerSignedMapperRequest } from '@/shared/webservice/iris/mapper/owner-signed.request';
import { Inject, Injectable } from '@nestjs/common';
import { RuntimeException } from '@nestjs/core/errors/exceptions';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { Readable } from 'stream';
import { LeadAppendixEvents } from '@/onboarding/service/lead-appendix-events';
import { ConfigService } from '@nestjs/config';
import { IrisClientConfig } from '@/shared/webservice/iris/iris-client-config';
import { PDFTemplatesService } from '@/shared/pdf/templates.service';

@Injectable()
// eslint-disable-next-line @darraghor/nestjs-typed/injectable-should-be-provided
export class LeadService {
    constructor(
        private readonly leadRepository: LeadRepository,
        private readonly emailService: EmailService,
        private readonly leadSignatureRepository: LeadSignatureRepository,
        private readonly leadAuditTrailStepLogRepository: LeadAuditTrailStepLogRepository,
        private readonly userRepository: MerchantRepository,
        private readonly irisMapper: IrisMapper,
        private readonly pDFService: PDFService,
        private readonly pdfTemplatesService: PDFTemplatesService,
        private readonly urlGenerator: UrlGenerator,
        private configService: ConfigService<IrisClientConfig>,
        @Inject(IrisSymbolToken) private readonly irisClient: IrisClientInterface,
        @InjectPinoLogger(LeadService.name) private readonly logger: PinoLogger,
    ) {}

    /**
     * Checks if a lead already exists based on the provided lead request data.
     *
     * @param {CheckDuplicateLeadDto} dto - The data transfer object containing information about the lead to be checked for duplicates.
     *
     * @return {Promise<CreatedLead | null>} A promise that resolves to the first duplicated lead if found, otherwise null.
     */
    async checkDuplicateLead(dto: CheckDuplicateLeadDto): Promise<CreatedLead | null> {
        this.logger.info(`Checking if lead exists`);

        const leadsData = (await this.irisClient.checkDuplicatedLead(dto)) ?? ({ leads: [] } as LeadListDto);

        if (leadsData.leads.length > 0) {
            return leadsData.leads[0];
        }

        return null;
    }

    /**
     * Creates a new lead for the given user (merchant) on the IRIS platform.
     *
     * @param {Merchant} user - The merchant for whom the lead is being created.
     * @returns {Promise<Lead>} - A promise that resolves to the newly created lead.
     * @throws {CouldNotCreateLeadAlreadyExists} - Thrown if a lead already exists for the given user.
     */
    async createLead(user: Merchant): Promise<Lead> {
        this.logger.info(`Creating new lead on IRIS with phone number ${user.phoneNumber}`);

        const existingLeadForUser: Lead | null = await this.leadRepository.findOne({
            where: { merchant: { id: user.id } },
            relations: { merchant: true },
        });

        if (existingLeadForUser) {
            this.logger.error(
                `Lead for phone number ${user.phoneNumber} and merchant ${user.getSid().toString()} exists lead id ${existingLeadForUser.sid.toString()}`,
            );
            throw CouldNotCreateLeadAlreadyExists.create();
        }

        const result: CreateLeadResponse = await this.irisClient.createLead(new CustomPhoneNumber(user.phoneNumber));

        if (user.agent) {
            try {
                await this.irisClient.assignAgentToLead(result.leadId, user.agent);
            } catch (e) {
                this.logger.error(`Could not assign agent to lead ${result.leadId} and agent ${user.agent}`);
            }
        }

        const lead = await this.leadRepository.save(Lead.create(user, result.leadId, OnboardingStatus.IN_PROGRESS, result.message));
        user.lead = lead;
        await this.userRepository.save(user);

        return lead;
    }

    /**
     * Retrieves the lead information based on the provided lead ID.
     *
     * @param {number} leadId - The unique identifier of the lead to be fetched.
     * @return {Promise<PublicLeadDto>} A promise that resolves to a PublicLeadDto object containing the normalized lead information.
     */
    async getLead(leadId: number): Promise<PublicLeadDto> {
        const data = await this.irisClient.getLead(leadId);
        return this.irisMapper.fromIrisToNormalizedDto(JSON.stringify(data));
    }

    /**
     * Updates an existing lead with new information and retrieves the updated lead data.
     *
     * @param {number} leadId - The unique identifier of the lead to be updated.
     * @param {PublicLeadDto} dto - The data transfer object containing the new lead information.
     * @return {Promise<PublicLeadDto>} A promise that resolves to the updated lead data.
     */
    async updateLead(leadId: number, dto: PublicLeadDto): Promise<PublicLeadDto> {
        const str = this.irisMapper.fromNormalizedDtoToIris(dto);
        await this.irisClient.patchLead(leadId, str);
        const data = await this.irisClient.getLead(leadId);

        return this.irisMapper.fromIrisToNormalizedDto(JSON.stringify(data));
    }

    /**
     * @deprecated
     * @see updateLead
     */
    async updateLeadRaw(leadId: number, input: string): Promise<void> {
        this.logger.info(`Patching lead to IRIS ${leadId}`);
        this.logger.info(`Input: ${input}`);
        await this.irisClient.patchLead(leadId, input);
    }

    /**
     * @deprecated
     * @param leadId
     */
    async createAndSendSignature(leadId: number): Promise<CreateSignatureResponseDto> {
        const publicLeadDto = await this.getLead(leadId);

        const owners: string[] = [];

        // for each owner
        owners.push(publicLeadDto.owner_one.first_name + ' ' + publicLeadDto.owner_one.last_name);

        if (publicLeadDto.owner_two !== undefined && publicLeadDto.owner_two.first_name) {
            owners.push(publicLeadDto.owner_two.first_name + ' ' + publicLeadDto.owner_two.last_name);
        }

        if (publicLeadDto.owner_three !== undefined && publicLeadDto.owner_three.first_name) {
            owners.push(publicLeadDto.owner_three.first_name + ' ' + publicLeadDto.owner_three.last_name);
        }

        if (publicLeadDto.owner_four !== undefined && publicLeadDto.owner_four.first_name) {
            owners.push(publicLeadDto.owner_four.first_name + ' ' + publicLeadDto.owner_four.last_name);
        }

        const createSignatureRequest = this.irisMapper.fromOwnersToCreateSignatureForLeadRequest(owners);

        return this.irisClient.createSignatureForLead(leadId, createSignatureRequest);
    }

    /**
     * @deprecated
     */
    async checkSignedLead(leadId: number): Promise<boolean> {
        const signatures = await this.irisClient.checkSignatures(leadId);
        return signatures.data?.some((signature) => signature.status === 'Signed' || signature.status === 'Pending');
    }

    async sign(merchant: Merchant, leadSignatureId: string, dto: AuditTrailLeadStepLogDto) {
        // check the lead signature id
        const leadSignature = await this.leadSignatureRepository.findOneBy({ id: leadSignatureId });

        if (!leadSignature) {
            throw new RuntimeException(`Lead signature not found for ${leadSignatureId}`);
        }

        if (leadSignature.isSigned()) {
            throw new DomainError<SignErrorCode>({ name: 'ALREADY_SIGNED', message: `Lead signature already signed ${leadSignatureId}` });
        }

        // Add a sign to contract and upload signed
        const file = await this.pdfTemplatesService.getFile(leadSignature.contractTemplateKey);

        // Convert the S3 response into a buffer
        const templateBuffer = await new Promise<Buffer>((resolve, reject) => {
            const chunks: Uint8Array[] = [];
            const stream = file.Body as Readable;
            stream.on('data', (chunk) => {
                chunks.push(chunk);
            });
            stream.on('end', () => {
                resolve(Buffer.concat(chunks));
            });
            stream.on('error', (err) => {
                reject(err);
            });
        });

        let withSign = null;

        switch (leadSignature.ownerNumber) {
            case 1:
                withSign = await this.pDFService.addFirstOwnerSignatures(templateBuffer, leadSignature.signatureName);
                break;
            case 2:
                withSign = await this.pDFService.addSecondOwnerSignatures(templateBuffer, leadSignature.signatureName);
                break;
            case 3:
                withSign = await this.pDFService.addThirdOwnerSignatures(templateBuffer, leadSignature.signatureName);
                break;
            case 4:
                withSign = await this.pDFService.addFourthOwnerSignatures(templateBuffer, leadSignature.signatureName);
                break;
            default:
                throw new RuntimeException(`Invalid owner number ${leadSignature.ownerNumber}`);
        }

        /**
         * Save the log
         */
        await this.leadAuditTrailStepLogRepository.save(
            LeadAuditTrailStepLog.create(
                dto.overrideWithOwnerName(
                    new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
                    leadSignature.id,
                ),
            ),
        );

        // Appendix events
        const events = await this.leadAuditTrailStepLogRepository.find({
            where: { leadSignatureId: leadSignature.id },
            order: { createdAt: 'ASC' },
        });

        const sortedEvents = LeadAppendixEvents.prepare(leadSignature, events, dto);

        withSign = await this.pDFService.addAppendixPage(withSign, 10);
        withSign = await this.pDFService.addAppendixEvents(withSign, sortedEvents);

        // Upload the signed contract
        const filename = merchant.sid.toString() + '/' + merchant.lead.sid.toString() + '/' + leadSignature.id + '.pdf';

        const uploadResult = await this.pdfTemplatesService.upload(withSign, filename);

        await this.irisClient.uploadSignDocument(leadSignature.lead.leadId, withSign);

        // Sign the signature
        leadSignature.sign(uploadResult.key, uploadResult.url, dto.getIpAddress(), dto.getDeviceBrowser());

        if (leadSignature.owner) {
            leadSignature.lead.onboardingStatus = OnboardingStatus.COMPLETED;
            await this.leadRepository.save(leadSignature.lead);
        }

        await this.leadSignatureRepository.save(leadSignature);

        // Mark iris owner signed
        const irisSignRequest = this.irisMapper.signOwner(
            new OwnerSignedMapperRequest({
                ownerNumber: leadSignature.ownerNumber,
                url: this.urlGenerator.generateDownloadContractUrl(leadSignature.id),
            }),
        );

        await this.irisClient.patchLead(leadSignature.lead.leadId, JSON.stringify(irisSignRequest));

        // Check if all signatures are signed
        const specification = new DidAllOwnersSignSpecification(this.leadSignatureRepository);
        const allSignaturesSigned = await specification.satisfy(leadSignature.lead.id);

        if (allSignaturesSigned) {
            const irisSignRequestAllOwners = this.irisMapper.signOwner(
                new OwnerSignedMapperRequest({
                    allOwnersSigned: true,
                }),
            );

            const irisSubmittedApplicationStatus = parseInt(this.configService.get('IRIS_SUBMITTED_APPLICATION_STATUS'));
            await this.irisClient.patchLead(leadSignature.lead.leadId, JSON.stringify({ status: irisSubmittedApplicationStatus }));

            await this.irisClient.patchLead(leadSignature.lead.leadId, JSON.stringify(irisSignRequestAllOwners));
        }

        // Send confirmation
        this.logger.info(`Sending contract signed to email ${leadSignature.signatureEmail}`);

        const emailLeadSignatureResponse = await this.emailService.send(
            new EmailTemplateMessage(leadSignature.signatureEmail, 'Talus Merchant Application', 'contract-signed', {
                name: leadSignature.signatureName,
                download_url: this.urlGenerator.generateDownloadContractUrl(leadSignature.id),
            }),
        );

        await this.leadAuditTrailStepLogRepository.save(
            LeadAuditTrailStepLog.create(
                dto.overrideWithEmail(
                    leadSignature.signatureEmail,
                    emailLeadSignatureResponse.status,
                    'email-sending-contract-signed',
                    new AuditTrailOwnerName(leadSignature.signatureName, leadSignature.signatureEmail),
                    leadSignature.id,
                ),
            ),
        );

        // if main owner signed send emails to all lead signatures if there are any
        if (leadSignature.owner) {
            const otherLeadsSignatures = await this.leadSignatureRepository.findBy({ lead: { id: leadSignature.lead.id }, owner: false });

            for (const otherLeadSignature of otherLeadsSignatures) {
                this.logger.info(`Sending sign contract to email ${otherLeadSignature.signatureEmail}`);

                const result = await this.emailService.send(
                    new EmailTemplateMessage(otherLeadSignature.signatureEmail, 'Sign contract', 'sign-contract', {
                        name: otherLeadSignature.signatureName,
                        main_owner_name: leadSignature.signatureName,
                        sign_url: this.urlGenerator.generateClickToSignTrackUrl({ leadSignatureId: otherLeadSignature.id }),
                    }),
                );

                await this.leadAuditTrailStepLogRepository.save(
                    LeadAuditTrailStepLog.create(
                        dto.overrideWithEmail(
                            otherLeadSignature.signatureEmail,
                            result.status,
                            'email-sending-extra-owner-a-sign',
                            new AuditTrailOwnerName(otherLeadSignature.signatureName, otherLeadSignature.signatureEmail),
                            otherLeadSignature.id,
                        ),
                    ),
                );
            }
        }
    }

    async checkIfMainOwnerSigned(lead: Lead): Promise<LeadSignature> {
        return await this.leadSignatureRepository.findOneBy({ lead: { id: lead.id }, owner: true });
    }
}
