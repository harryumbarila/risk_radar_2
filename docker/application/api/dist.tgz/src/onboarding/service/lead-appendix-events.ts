import { AuditTrailLeadStepLogDto, AuditTrailStepStepNameType } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { EventsToInclude } from '@/shared/pdf/appendix-events';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';

export class LeadAppendixEvents {
    static prepare(leadSignature: LeadSignature, events: LeadAuditTrailStepLog[], dto: AuditTrailLeadStepLogDto) {
        const firstMatchingEvent = events.find(
            (event) => event.stepName === 'sign-contract-by-extra-owner' || event.stepName === 'sign-contract-by-main-owner',
        );

        // If found, get its IP address
        const ipToFilter = firstMatchingEvent ? firstMatchingEvent.ipAddress : dto.getIpAddress();

        return events
            .filter((r) => EventsToInclude.includes(r.stepName as AuditTrailStepStepNameType))
            .filter((r) => r.ipAddress == ipToFilter)
            .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
            .map(({ stepName, createdAt }) => ({
                name: leadSignature.signatureName,
                email: leadSignature.signatureEmail,
                ip: ipToFilter,
                date: createdAt,
                device: dto.getDeviceBrowser(),
                event: stepName as AuditTrailStepStepNameType,
            }));
    }
}
