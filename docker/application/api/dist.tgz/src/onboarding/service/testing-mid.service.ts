import { Injectable } from '@nestjs/common';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';
import { WebhookBody } from '@/shared/model/iris-webhook-body';
import { ProcessIrisWebhookUseCase } from '@/onboarding/usecase/process-iris-webhook.usecase';
import { OnboardingStatus } from '@/shared/model/lead.entity';
import { ConfigService } from '@nestjs/config';

interface TestingMidServiceConfig {
    TESTING_MID: string;
}

@Injectable()
export class TestingMidService {
    constructor(
        private configService: ConfigService<TestingMidServiceConfig>,
        private readonly leadRepository: LeadRepository,
        private readonly processIrisWebhookUseCase: ProcessIrisWebhookUseCase,
        @InjectPinoLogger(TestingMidService.name) private readonly logger: PinoLogger,
    ) {}

    /**
     * Triggers auto approval
     */
    async triggerAutoApprove(): Promise<void> {
        const testingMid = <string>this.configService.get('TESTING_MID', '');

        /**
         * if there is testing mid we autoapprove otherwise we skip
         */
        if (testingMid.length > 0) {
            const leads = await this.leadRepository.find({
                where: { onboardingStatus: OnboardingStatus.IN_PROGRESS },
                relations: { merchant: true },
            });

            for (const lead of leads) {
                const webhookBody: WebhookBody = {
                    hook: {
                        event: 'turboapp.approved',
                    },
                    data: {
                        accounts: [
                            {
                                id: 9295,
                                dba: 'Dogfooding',
                                lid: 99560,
                                mid: '5611000000159681',
                            },
                        ],
                    },
                };

                const account = await lead.merchant.account;
                await this.processIrisWebhookUseCase.handleApproval(webhookBody, account.sid.toString());
            }
        }
    }
}
