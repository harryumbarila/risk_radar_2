import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';

export class DidAllOwnersSignSpecification {
    constructor(private leadSignatureRepository: LeadSignatureRepository) {}
    async satisfy(leadId: string): Promise<boolean> {
        // Are all owners signed if so update all signed field in iris
        const otherLeadsSignatures = await this.leadSignatureRepository.find({
            where: { lead: { id: leadId } },
            relations: { lead: true },
        });

        // Check if all signatures are signed
        return otherLeadsSignatures.length > 0 && otherLeadsSignatures.every((signature) => signature.isSigned());
    }
}
