import { Controller, Get, HttpCode, HttpStatus, NotFoundException, Param, Post, Req, UseGuards } from '@nestjs/common';
import { ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { ProcessIrisWebhookUseCase } from './usecase/process-iris-webhook.usecase';
import { Request } from 'express';
import { INTERNAL_API_HEADER_NAME, InternalApiKeyGuard } from '@/shared/auth/guard/internal-api-key.guard';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { Merchant } from '@/shared/model/merchant.entity';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { LeadService } from '@/onboarding/service/lead.service';
import { GetMerchantResponseAssembler } from '@/onboarding/assembler/get-merchant-response.assembler';
import { GetMerchantResponseDto } from '@/onboarding/response/get-merchant-response.dto';
import { RegisterAccountResponseDto } from '@/account/register-account.response.dto';

@ApiTags('internal-admin-onboarding')
@Controller(['/v1/admin/onboarding', '/v1/internal/onboarding'])
export class InternalAdminOnboardingController {
    constructor(
        private readonly processIrisWebhookUseCase: ProcessIrisWebhookUseCase,
        private readonly merchantRepository: MerchantRepository,
        private readonly leadService: LeadService,
        private readonly getMerchantResponseAssembler: GetMerchantResponseAssembler,
    ) {}

    @ApiResponse({
        status: 200,
        description: 'Create fluidpay merchant for existing IRIS merchant (boarding existing merchant)',
    })
    @Post('/:account_id')
    @Public()
    @UseGuards(InternalApiKeyGuard)
    async paymentOnboarding(@Req() request: Request, @Param('account_id') accountSid: string): Promise<void> {
        await this.processIrisWebhookUseCase.handleApproval(request.body, accountSid);
    }

    @ApiResponse({
        status: 200,
        description: 'Get merchant',
        type: GetMerchantResponseDto,
    })
    @ApiResponse({
        status: 404,
        description: 'Merchant not found',
    })
    @ApiHeader({
        name: INTERNAL_API_HEADER_NAME,
        description: 'Required internal api key',
        required: true,
    })
    @Get('/merchants/:merchant_id')
    @HttpCode(HttpStatus.OK)
    @Public()
    @UseGuards(InternalApiKeyGuard)
    async merchant(@Param('merchant_id') merchantId: string): Promise<GetMerchantResponseDto> {
        const merchant: Merchant | null = await this.merchantRepository.findOneBySid(merchantId);

        if (!merchant) {
            throw new NotFoundException('Merchant not found');
        }

        let leadDto: PublicLeadDto | undefined = undefined;

        if (merchant.lead?.leadId) {
            leadDto = await this.leadService.getLead(merchant.lead.leadId);
        }

        return this.getMerchantResponseAssembler.createDtoWithAdditionalInfo(merchant, leadDto);
    }
}
