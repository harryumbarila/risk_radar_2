import { ApiProperty } from '@nestjs/swagger';
import { OnboardingStatus } from '@/shared/model/lead.entity';
import { Merchant } from '@/shared/model/merchant.entity';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';

export class MerchantPayment {
    @ApiProperty({ example: 'pub_XXXXXXXXXXXXXX', description: 'Public key used for tokenizer' })
    public tokenizer_publishable_key: string;

    @ApiProperty({ example: 'Cx78a65ada9', description: 'Terminal ID' })
    public terminal_id: string;
}

export class GetMerchantResponseDto {
    @ApiProperty({ example: 'merchant_2x4y6z8a0b1c2d3e4f5g6h7j8k' })
    public id: string;
    @ApiProperty({ example: '12819374192' })
    public phone: string;
    @ApiProperty({ description: 'Merchant payouts status' })
    public automatic_payouts: boolean;
    @ApiProperty({ description: 'Merchant deactivation flag' })
    public deactivated: boolean;
    @ApiProperty()
    public created_at: Date;
    /**
     * @todo rename to application_id
     */
    @ApiProperty({ nullable: true, description: 'Onboarding application ID' })
    public lead_id: number | null;
    @ApiProperty({ enum: OnboardingStatus, enumName: 'OnboardingStatus', nullable: true, description: 'Merchant onboarding status' })
    public lead_onboarding_status: OnboardingStatus | null;
    @ApiProperty({ nullable: true, description: 'Merchant onboarding information' })
    public merchant: PublicLeadDto | null;
    @ApiProperty({ nullable: true, description: 'Merchant payment information' })
    public payment: MerchantPayment | null;

    public static createFromMerchant(merchant: Merchant): GetMerchantResponseDto {
        const response = new GetMerchantResponseDto();
        response.phone = merchant.phoneNumber;
        response.created_at = merchant.createdAt;
        response.automatic_payouts = merchant.automaticPayouts;
        response.deactivated = merchant.deactivated;
        response.id = merchant.sid.toString();
        response.lead_id = merchant.lead?.leadId ?? null;
        response.lead_onboarding_status = merchant.lead?.onboardingStatus ?? null;

        return response;
    }

    public static createFromMerchantWithData(merchant: Merchant, data: PublicLeadDto): GetMerchantResponseDto {
        const response = new GetMerchantResponseDto();
        response.phone = merchant.phoneNumber;
        response.created_at = merchant.createdAt;
        response.automatic_payouts = merchant.automaticPayouts;
        response.deactivated = merchant.deactivated;
        response.id = merchant.sid.toString();
        response.lead_id = merchant.lead?.leadId ?? null;
        response.lead_onboarding_status = merchant.lead?.onboardingStatus ?? OnboardingStatus.NOT_STARTED;
        response.merchant = data;

        return response;
    }
}
