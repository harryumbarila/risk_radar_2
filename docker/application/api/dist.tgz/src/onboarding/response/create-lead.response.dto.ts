import { Lead } from '@/shared/model/lead.entity';
import { ApiProperty } from '@nestjs/swagger';

export class CreateLeadResponseDto {
    @ApiProperty()
    public lead_id: number;
    @ApiProperty()
    public message: string;

    constructor(lead: Lead) {
        this.lead_id = lead.leadId;
        this.message = lead.data;
    }
}
