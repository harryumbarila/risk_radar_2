import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreatedLead {
    @ApiProperty()
    public id: number;
    public created_at: string;
}

export class LeadListDto {
    @ApiProperty({ isArray: true })
    @Type(() => CreatedLead)
    public leads: CreatedLead[];
}
