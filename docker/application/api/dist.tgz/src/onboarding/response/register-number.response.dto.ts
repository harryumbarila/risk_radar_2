import { ApiProperty } from '@nestjs/swagger';

export class RegisterNumberResponseDto {
    @ApiProperty()
    readonly message: string = 'Verification code sent to the number, please check out.';
}
