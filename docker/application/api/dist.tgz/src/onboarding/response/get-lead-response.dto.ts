import { OnboardingStatus } from '@/shared/model/lead.entity';
import { ApiProperty } from '@nestjs/swagger';

export class GetLeadResponseDto {
    @ApiProperty()
    public lead_id: number;
    @ApiProperty({ enum: OnboardingStatus, enumName: 'OnboardingStatus' })
    public status: OnboardingStatus;
    @ApiProperty()
    public data: any;

    constructor(leadId: number, status: OnboardingStatus, data: any) {
        this.lead_id = leadId;
        this.status = status;
        this.data = data;
    }
}
