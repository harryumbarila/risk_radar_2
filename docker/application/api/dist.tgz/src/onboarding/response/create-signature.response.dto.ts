import { ApiProperty } from '@nestjs/swagger';

export class CreateSignatureResponseDto {
    @ApiProperty()
    url: string;
}
