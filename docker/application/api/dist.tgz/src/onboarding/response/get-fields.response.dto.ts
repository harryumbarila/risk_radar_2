import { ApiProperty } from '@nestjs/swagger';

export interface Option {
    key: string;
    value: string;
}

export class GetFieldsResponseDto {
    constructor(options: Option[]) {
        this.dropdown = options;
    }

    @ApiProperty({ isArray: true })
    dropdown: Option[];
}
