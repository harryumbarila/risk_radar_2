import { Module } from '@nestjs/common';
import { OnboardingController } from './onboarding.controller';
import { SendOtpCodeUseCase } from './usecase/send-otp-code.usecase';
import { TwilioSymbolToken } from '@/shared/webservice/twilio/twilio.constants';
import { TwilioClient } from '@/shared/webservice/twilio/twilio.client';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { VerifyOtpCodeAndRegisterUserUseCase } from './usecase/verify-otp-code-and-register-user.usecase';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Merchant } from '@/shared/model/merchant.entity';
import { MerchantController } from './merchant.controller';
import { CreateLeadUseCase } from './usecase/create-lead.usecase';
import { IrisSymbolToken } from '@/shared/webservice/iris/iris.constants';
import { IrisClient } from '@/shared/webservice/iris/iris.client';
import { Lead } from '@/shared/model/lead.entity';
import { LeadRepository } from '@/shared/model/lead/lead.repository';
import { PatchLeadUseCase } from './usecase/patch-lead.usecase';
import { GetLeadsFieldsUseCase } from './usecase/get-leads-fields.usecase';
import { ProcessIrisWebhookUseCase } from './usecase/process-iris-webhook.usecase';
import { CreateSignatureUseCase } from './usecase/create-signature.usecase';
import { GetIrisLeadUseCase } from './usecase/get-iris-lead.usecase';
import { UploadDocumentForLeadUseCase } from '@/onboarding/usecase/upload-document-for-lead.usecase';
import { OnboardingWebhookController } from '@/onboarding/onboarding-webhook.controller';
import { BullModule } from '@nestjs/bullmq';
import { WebhookRepository } from '@/webhook/webhook.repository';
import { WebhookLogRepository } from '@/webhook/webhook-log.repository';
import { AccountRepository } from '@/shared/model/account/account.repository';
import { CreateUserAuthTokenUseCase } from '@/onboarding/usecase/create-user-auth-token.usecase';
import { CreateMerchantUseCase } from '@/onboarding/usecase/create-merchant.usecase';
import { WebhookModule } from '@/webhook/webhook.module';
import { AorakiPaymentsClient, AorakiPaymentsSymbolToken } from '@/shared/webservice/aoraki-payments/aoraki-payments.client';
import { IrisMapper } from '@/shared/irisMappings/iris-mapper';
import { NewStatusExtractorProcessor } from '@/onboarding/usecase/process-iris-webhook/new-status-extractor.processor';
import { Account } from '@/shared/model/account.entity';
import { LeadService } from '@/onboarding/service/lead.service';
import { InternalAdminOnboardingController } from '@/onboarding/internal-admin-onboarding.controller';
import { UsernameGenerator } from '@/onboarding/usecase/process-iris-webhook/username-generator';
import { CreateOnboardingSignatureUseCase } from '@/onboarding/usecase/create-onboarding-signature.usecase';
import { CheckSignedLeadUseCase } from '@/onboarding/usecase/check-signed-lead.usecase';
import { SlackClient } from '@/shared/webservice/slack/slack.client';
import { SlackSymbolToken } from '@/shared/webservice/slack/slack.constant';
import { SlackModule } from 'nestjs-slack';
import { slackConfigAsync } from '@/shared/config/slack.config';
import { GetMerchantResponseAssembler } from '@/onboarding/assembler/get-merchant-response.assembler';
import { TestingMidService } from '@/onboarding/service/testing-mid.service';
import { EmailModule } from '@/email/email.module';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';
import { LeadAuditTrailStepLogRepository } from '@/shared/model/lead/lead-audit-trail-step-log.repository';
import { LeadSignatureRepository } from '@/shared/model/lead/lead-signature.repository';
import { GetContractTemplateUseCase } from '@/onboarding/usecase/get-contract-template.usecase';
import { GetContractTemplateForExtraOwnersUseCase } from '@/onboarding/usecase/get-contract-template-for-extra-owners.usecase';
import { SignUseCase } from '@/onboarding/usecase/sign.usecase';
import { SignByExtraOwnersUseCase } from '@/onboarding/usecase/sign-by-extra-owners.usecase';
import { LeadSignatureFactory } from '@/shared/model/lead/lead-signature.factory';
import { AWSModule } from '@/shared/aws/aws.module';
import { PDFModule } from '@/shared/pdf/pdf.module';
import { GetSignedContractUseCase } from '@/onboarding/usecase/get-signed-contract.usecase';
import { ContractsController } from '@/onboarding/contracts.controller';
import { UrlGenerator } from '@/shared/url/url.generator';
import { CollectClickToSignUseCase } from '@/onboarding/usecase/collect-click-to-sign.usecase';

const useCases = [
    VerifyOtpCodeAndRegisterUserUseCase,
    SendOtpCodeUseCase,
    CreateSignatureUseCase,
    CreateLeadUseCase,
    ProcessIrisWebhookUseCase,
    PatchLeadUseCase,
    GetIrisLeadUseCase,
    GetLeadsFieldsUseCase,
    UploadDocumentForLeadUseCase,
    CreateUserAuthTokenUseCase,
    CreateMerchantUseCase,
    CreateOnboardingSignatureUseCase,
    CheckSignedLeadUseCase,
    GetContractTemplateUseCase,
    GetContractTemplateForExtraOwnersUseCase,
    SignUseCase,
    SignByExtraOwnersUseCase,
    GetSignedContractUseCase,
    CollectClickToSignUseCase,
];

const repositories = [
    MerchantRepository,
    LeadRepository,
    AccountRepository,
    WebhookRepository,
    WebhookLogRepository,
    LeadAuditTrailStepLogRepository,
    LeadSignatureRepository,
];

const entities = [Account, Merchant, Lead, LeadAuditTrailStepLog, LeadSignature];

const otherProviders = [
    {
        provide: TwilioSymbolToken,
        useClass: TwilioClient,
    },
    {
        provide: IrisSymbolToken,
        useClass: IrisClient,
    },
    {
        provide: AorakiPaymentsSymbolToken,
        useClass: AorakiPaymentsClient,
    },
    {
        provide: SlackSymbolToken,
        useClass: SlackClient,
    },
    NewStatusExtractorProcessor,
    IrisMapper,
    LeadService,
    UsernameGenerator,
    GetMerchantResponseAssembler,
    TestingMidService,
    LeadSignatureFactory,
    UrlGenerator,
];

@Module({
    controllers: [
        OnboardingController,
        MerchantController,
        OnboardingWebhookController,
        InternalAdminOnboardingController,
        ContractsController,
    ],
    providers: [...repositories, ...useCases, ...otherProviders],
    imports: [
        TypeOrmModule.forFeature(entities),
        BullModule.registerQueue({
            name: 'onboarding',
        }),
        WebhookModule,
        SlackModule.forRootAsync(slackConfigAsync),
        EmailModule,
        AWSModule,
        PDFModule,
    ],
})
export class OnboardingModule {}
