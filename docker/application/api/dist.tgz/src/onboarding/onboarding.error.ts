import { DomainError } from '@/shared/model/domain.error';
import { OnboardingErrorCode } from '@/shared/model/error.constants';

export class OnboardingError extends DomainError<OnboardingErrorCode> {}

export class InvalidAccountError extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'INVALID_ACCOUNT',
            message: `Invalid account used to verify this user phone number`,
        });
    }
}

export class InvalidOtpCodeError extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'INVALID_OTP_CODE',
            message: `Invalid or expired otp code`,
        });
    }
}

export class NoMerchantFoundForLead extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'IRIS_WEBHOOK_NO_MERCHANT_FOUND_FOR_LEAD',
            message: `There is no merchant found for lead`,
        });
    }
}

export class NotEventOnIrisWebhook extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'IRIS_WEBHOOK_DID_NOT_RETURN_EVENT',
            message: `Iris webhook did not return an event`,
        });
    }
}

export class ErrorGeneratingSignature extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'IRIS_DID_NOT_CREATE_A_SIGNATURE',
            message: `Iris did not generate a signature`,
        });
    }
}

export class IntervalServerError extends OnboardingError {
    public static create(): OnboardingError {
        return new this({
            name: 'INTERNAL_SERVER_ERROR',
            message: `Internal server error`,
        });
    }
}
