import { Controller, Get, Param, Res, HttpException, HttpStatus, Req, Post, Body } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiParam, ApiOkResponse, ApiResponse } from '@nestjs/swagger';
import { Response } from 'express';
import { GetSignedContractUseCase } from '@/onboarding/usecase/get-signed-contract.usecase';
import { AuditTrailLeadStepLogDto } from '@/onboarding/usecase/patch-lead/audit-trail-lead-step-log.dto';
import { Request } from 'express';
import { GetObjectCommandOutput } from '@aws-sdk/client-s3';
import { PassThrough, Readable } from 'stream';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { SignResponseDto } from '@/onboarding/request/sign.response.dto';
import { SignRequestDto } from '@/onboarding/request/sign.request.dto';
import { ContractResponseDto } from '@/onboarding/request/contract.response.dto';
import { SignByExtraOwnersUseCase } from '@/onboarding/usecase/sign-by-extra-owners.usecase';
import { GetContractTemplateForExtraOwnersUseCase } from '@/onboarding/usecase/get-contract-template-for-extra-owners.usecase';
import { CollectClickToSignUseCase } from '@/onboarding/usecase/collect-click-to-sign.usecase';
import { CONTRACTS_PREFIX, CONTRACTS_URL_CLICK_TO_SIGN_TRACK } from '@/shared/url/url.generator';

@ApiTags('Contracts')
@Controller(CONTRACTS_PREFIX)
export class ContractsController {
    constructor(
        private readonly getSignedContractUseCase: GetSignedContractUseCase,
        private readonly signByExtraOwnersUseCase: SignByExtraOwnersUseCase,
        private readonly getContractTemplateForExtraOwnersUseCase: GetContractTemplateForExtraOwnersUseCase,
        private readonly collectClickToSignUseCase: CollectClickToSignUseCase,
    ) {}
    @ApiOkResponse({ description: 'PDF file successfully downloaded' })
    @ApiResponse({
        status: 404,
        description: 'File not found or does not exist in the S3 bucket',
    })
    @ApiResponse({
        status: 500,
        description: 'Internal server error while downloading the file',
    })
    @ApiOperation({ summary: 'Download a contract PDF' })
    @ApiParam({ name: 'leadSignatureId', description: 'The unique key of the PDF file' })
    @Get('/download/:leadSignatureId')
    @Public()
    async download(@Param('leadSignatureId') leadSignatureId: string, @Req() req: Request, @Res() res: Response) {
        try {
            const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(req, null, 'download-contract');

            // Get the file's stream from S3
            const awsFile: GetObjectCommandOutput = await this.getSignedContractUseCase.handle(leadSignatureId, auditTrailDto);

            res.set({
                'Content-Type': 'application/pdf', // Define the content type
                'Content-Disposition': `attachment; filename=${leadSignatureId}.pdf`, // Download as attachment
            });

            // Convert S3 stream to Node.js readable stream if necessary
            let stream: PassThrough | Readable;
            if ((awsFile.Body as any).pipe) {
                stream = awsFile.Body as Readable; // Node.js readable stream
                // Pipe the file stream to the response
                stream.pipe(res);
            } else {
                throw new HttpException(
                    'Error downloading the file. File may not exist or there is an issue.',
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }
        } catch (error) {
            console.error(error);
            throw new HttpException(
                'Error downloading the file. File may not exist or there is an issue.',
                HttpStatus.INTERNAL_SERVER_ERROR,
            );
        }
    }

    @ApiResponse({
        status: 200,
        description: 'Sign the contract, by extra owners',
        type: SignResponseDto,
    })
    @ApiOperation({ operationId: 'Sign the contract by extra owners' })
    @Public()
    @Post('/sign')
    async signApplication(@Body() dto: SignRequestDto, @Req() request: Request): Promise<SignResponseDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, null, 'sign-contract-by-extra-owner');
        return this.signByExtraOwnersUseCase.handle(dto, auditTrailDto);
    }

    @ApiResponse({
        status: 200,
        description: 'Sign the contract, by extra owners',
        type: SignResponseDto,
    })
    @ApiOperation({ operationId: 'Sign the contract by extra owners' })
    @Public()
    @Get(CONTRACTS_URL_CLICK_TO_SIGN_TRACK)
    async track(@Req() request: Request, @Param('leadSignatureId') leadSignatureId: string, @Res() response: Response) {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, null, 'clicked-on-link-to-sign-contract');
        const redirectUrl = await this.collectClickToSignUseCase.handle(leadSignatureId, auditTrailDto);

        // Return a 302 redirect to the provided URL
        return response.redirect(302, redirectUrl);
    }

    @ApiResponse({
        status: 200,
        description: 'Get the contract template for extra owners',
        type: ContractResponseDto,
    })
    @ApiOperation({ operationId: 'Get the contract template for extra owners' })
    @Get(':leadSignatureId')
    @Public()
    async getContractTemplate(@Param('leadSignatureId') leadSignatureId: string, @Req() request: Request): Promise<ContractResponseDto> {
        const auditTrailDto = await AuditTrailLeadStepLogDto.fromRequest(request, null, 'get-contract-template-for-extra-owner');
        return this.getContractTemplateForExtraOwnersUseCase.handle(leadSignatureId, auditTrailDto);
    }
}
