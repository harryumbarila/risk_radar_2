import { ApiBasicAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Body, Controller, Get, NotFoundException, Param, Post, UseGuards } from '@nestjs/common';
import { Merchant } from '@/shared/model/merchant.entity';
import { GetMerchantResponseDto } from './response/get-merchant-response.dto';
import { CreateMerchantUseCase } from '@/onboarding/usecase/create-merchant.usecase';
import { CreateMerchantRequestDto } from '@/onboarding/request/create-merchant-request.dto';
import { CurrentAccount } from '@/shared/auth/decorator/current-account.decorator';
import { Account } from '@/shared/model/account.entity';
import { JwtToken } from '@/shared/auth/jwt-token';
import { Public } from '@/shared/auth/decorator/public.decorator';
import { AccountSecretAuthorizationBasicGuard } from '@/shared/auth/guard/account-secret-authorization-basic.guard';
import { CreateUserAuthTokenUseCase } from '@/onboarding/usecase/create-user-auth-token.usecase';
import { MerchantRepository } from '@/shared/model/merchant/merchant-repository.service';
import { LeadService } from '@/onboarding/service/lead.service';
import { ConfigureOwnersPipeTransformer } from '@/shared/transformer/configure-owners.pipe.transformer';
import { PublicLeadDto } from '@/onboarding/request/public-lead.request.dto';
import { GetMerchantResponseAssembler } from '@/onboarding/assembler/get-merchant-response.assembler';

@ApiTags('Merchants')
@Controller(['/api/v1/merchants', '/v1/merchants'])
export class MerchantController {
    constructor(
        private readonly merchantRepository: MerchantRepository,
        private readonly createMerchantUseCase: CreateMerchantUseCase,
        private readonly createUserAuthTokenUseCase: CreateUserAuthTokenUseCase,
        private readonly leadService: LeadService,
        private readonly getMerchantResponseAssembler: GetMerchantResponseAssembler,
    ) {}

    @ApiResponse({
        status: 201,
        description: 'Create merchant, it merchant exists for given phone number it will return the same merchant',
        type: GetMerchantResponseDto,
    })
    @Public()
    @ApiOperation({ operationId: 'Create merchant' })
    @ApiBasicAuth('account-secret')
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @Post()
    async create(
        @Body(ConfigureOwnersPipeTransformer) dto: CreateMerchantRequestDto,
        @CurrentAccount() account: Account,
    ): Promise<GetMerchantResponseDto> {
        return this.createMerchantUseCase.handle(account, dto);
    }

    @ApiResponse({
        status: 200,
        description: 'Create merchant session token to enable onboarding calls',
        type: JwtToken,
    })
    @Public()
    @ApiBasicAuth('account-secret')
    @ApiOperation({ operationId: 'Create merchant session token' })
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @Post(['/:merchant_id/session-token'])
    async createMerchantAuthToken(@Param('merchant_id') id: string, @CurrentAccount() account: Account): Promise<JwtToken> {
        return this.createUserAuthTokenUseCase.handle(account, id);
    }

    @ApiResponse({
        status: 200,
        description: 'Get merchant object',
        type: GetMerchantResponseDto,
    })
    @Public()
    @ApiOperation({ operationId: 'Get merchant' })
    @ApiBasicAuth('account-secret')
    @UseGuards(AccountSecretAuthorizationBasicGuard)
    @Get('/:merchant_id')
    async getMerchant(@Param('merchant_id') id: string, @CurrentAccount() account: Account): Promise<GetMerchantResponseDto> {
        const merchant: Merchant | null = await this.merchantRepository.findUserFromAccount(account.sid.toString(), id);

        if (!merchant) {
            throw new NotFoundException('Merchant not found');
        }

        let leadDto: PublicLeadDto | undefined = undefined;

        if (merchant.lead?.leadId) {
            leadDto = await this.leadService.getLead(merchant.lead.leadId);
        }

        return this.getMerchantResponseAssembler.createDtoWithAdditionalInfo(merchant, leadDto);
    }
}
