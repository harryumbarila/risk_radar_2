import './instrument';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as compression from 'compression';
import { useContainer } from 'class-validator';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { Logger, LoggerErrorInterceptor } from 'nestjs-pino';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { DomainErrorFilter } from './shared/error/domain-error.filter';
import { writeFileSync, readFileSync } from 'fs';
import { HttpExceptionFilter } from '@/shared/error/http-exception.filter';
import { Instrument } from '@/instrument';
import { ConfigService } from '@nestjs/config';
import { NestExpressApplication } from '@nestjs/platform-express/interfaces/nest-express-application.interface';

async function bootstrap() {
    const app = await NestFactory.create<NestExpressApplication>(AppModule, { bufferLogs: true, cors: true });

    // trust proxies from behind LB
    app.set('trust proxy', true);

    Instrument.init(app.get(ConfigService));

    app.useGlobalPipes(
        new ValidationPipe({
            transform: true,
            transformOptions: { enableImplicitConversion: true },
            forbidUnknownValues: true,
            skipMissingProperties: false,
        }),
    );
    app.useGlobalInterceptors(new LoggerErrorInterceptor());
    app.useLogger(app.get(Logger));
    app.use(helmet());
    app.useGlobalFilters(new DomainErrorFilter(), new HttpExceptionFilter());
    useContainer(app.select(AppModule), { fallbackOnErrors: true });
    app.use(compression());

    if (process.env.NODE_ENV !== 'production') {
        app.enableCors();

        const options = new DocumentBuilder()
            .setTitle('TalusPay API')
            .setDescription(readFileSync('./documentation/api-description.md', 'utf8'))
            .setVersion('v1')
            .addBearerAuth(
                { type: 'http', description: 'Current accounts merchant auth session token - using JWT' },
                'account-merchant-session-token',
            )
            .addBasicAuth(
                { type: 'http', scheme: 'basic', description: 'Combination of base64 encode of account_sid:account_secret_key' },
                'account-secret',
            )
            // Local setup
            .addServer('http://localhost:3000', 'Local environment endpoint')
            .addServer('https://api.taluspay-staging.com', 'Staging environment endpoint')
            .build();

        const document = SwaggerModule.createDocument(app, options);

        // Add x-logo extension
        document.info['x-logo'] = {
            url: 'https://apply.taluspay.com/assets/company-logo.svg', // URL of your logo image
            href: 'https://taluspay.com',
        };

        // Save the Swagger document as JSON
        writeFileSync('./swagger.json', JSON.stringify(document));

        SwaggerModule.setup('api/swagger', app, document);
    }

    await app.listen(3000);
}
bootstrap();
