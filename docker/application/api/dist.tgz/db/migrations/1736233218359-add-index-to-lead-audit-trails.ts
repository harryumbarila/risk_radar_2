import { MigrationInterface, QueryRunner } from "typeorm";

export class AddIndexToLeadAuditTrails1736233218359 implements MigrationInterface {
    name = 'AddIndexToLeadAuditTrails1736233218359'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ALTER COLUMN "lead_signature_id" DROP DEFAULT`);
        await queryRunner.query(`CREATE INDEX "IDX_3c81e80162c9dbfe63cbd113ee" ON "lead_audit_trail_step_logs" ("lead_signature_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_40d0f320af9a93dacfdaf13e0d" ON "lead_audit_trail_step_logs" ("created_at") `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."IDX_40d0f320af9a93dacfdaf13e0d"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_3c81e80162c9dbfe63cbd113ee"`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ALTER COLUMN "lead_signature_id" SET DEFAULT NULL`);
    }

}
