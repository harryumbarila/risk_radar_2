import { MigrationInterface, QueryRunner } from 'typeorm';

export class LeadAuditAddSignatureId1735933563765 implements MigrationInterface {
    name = 'LeadAuditAddSignatureId1735933563765';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ADD "lead_signature_id" character varying(36) DEFAULT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" DROP COLUMN "lead_signature_id"`);
    }
}
