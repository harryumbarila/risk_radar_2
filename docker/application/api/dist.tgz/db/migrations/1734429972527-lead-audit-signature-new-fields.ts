import { MigrationInterface, QueryRunner } from "typeorm";

export class LeadAuditSignatureNewFields1734429972527 implements MigrationInterface {
    name = 'LeadAuditSignatureNewFields1734429972527'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ADD "request_id" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ADD "email_status" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ADD "email_recipient" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" DROP COLUMN "email_recipient"`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" DROP COLUMN "email_status"`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" DROP COLUMN "request_id"`);
    }

}
