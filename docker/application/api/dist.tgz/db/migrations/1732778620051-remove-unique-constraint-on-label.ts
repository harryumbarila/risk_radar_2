import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveUniqueConstraintOnLabel1732778620051 implements MigrationInterface {
    name = 'RemoveUniqueConstraintOnLabel1732778620051'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "webhooks" DROP CONSTRAINT "UQ_5ef8ea47429a31bcf12146974c1"`);
        await queryRunner.query(`CREATE INDEX "IDX_5ef8ea47429a31bcf12146974c" ON "webhooks" ("label") `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."IDX_5ef8ea47429a31bcf12146974c"`);
        await queryRunner.query(`ALTER TABLE "webhooks" ADD CONSTRAINT "UQ_5ef8ea47429a31bcf12146974c1" UNIQUE ("label")`);
    }

}
