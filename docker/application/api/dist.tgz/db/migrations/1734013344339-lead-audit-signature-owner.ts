import { MigrationInterface, QueryRunner } from "typeorm";

export class LeadAuditSignatureOwner1734013344339 implements MigrationInterface {
    name = 'LeadAuditSignatureOwner1734013344339'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_signatures" ADD "owner_number" integer`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_signatures" DROP COLUMN "owner_number"`);
    }

}
