import { MigrationInterface, QueryRunner } from 'typeorm';

export class MerchantChanges1726665092317 implements MigrationInterface {
    name = 'MerchantChanges1726665092317';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "webhooks" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "webhooks" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "merchants" ADD "deactivated" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "merchants" ADD "automatic_payouts" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TYPE "public"."leads_onboarding_status_enum" ADD VALUE 'FAILED'`);
        await queryRunner.query(`ALTER TYPE "public"."webhooks_log_event_type_enum" RENAME TO "webhooks_log_event_type_enum_old"`);
        await queryRunner.query(
            `CREATE TYPE "public"."webhooks_log_event_type_enum" AS ENUM('merchant.created', 'merchant.updated', 'merchant.verification_failed', 'merchant.verification_approved', 'merchant.processing')`,
        );
        await queryRunner.query(
            `ALTER TABLE "webhooks_log" ALTER COLUMN "event_type" TYPE "public"."webhooks_log_event_type_enum" USING "event_type"::"text"::"public"."webhooks_log_event_type_enum"`,
        );
        await queryRunner.query(`DROP TYPE "public"."webhooks_log_event_type_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "merchants" DROP COLUMN "automatic_payouts"`);
        await queryRunner.query(`ALTER TABLE "merchants" DROP COLUMN "deactivated"`);
        await queryRunner.query(`ALTER TABLE "webhooks" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "webhooks" DROP COLUMN "created_at"`);
    }
}
