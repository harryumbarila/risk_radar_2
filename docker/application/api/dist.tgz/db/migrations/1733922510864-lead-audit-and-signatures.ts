import { MigrationInterface, QueryRunner } from 'typeorm';

export class LeadAuditAndSignatures1733922510864 implements MigrationInterface {
    name = 'LeadAuditAndSignatures1733922510864';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `CREATE TABLE "lead_signatures" ("id" character varying(36) NOT NULL, "sid" character varying(46), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "signed_at" TIMESTAMP DEFAULT NULL, "signed_ip_address" character varying(45), "signed_device_browser" character varying(255), "owner" boolean NOT NULL, "signature_name" character varying(255) NOT NULL, "signature_email" character varying(255) NOT NULL, "contract_template_url" character varying(255) NOT NULL, "signed_contract_url" character varying(255), "lead_id" character varying(36), CONSTRAINT "UQ_62142a86ad9e5f10454ac891e89" UNIQUE ("sid"), CONSTRAINT "PK_cccd70b78ff17dd9b1fa6f71b54" PRIMARY KEY ("id"))`,
        );
        await queryRunner.query(
            `CREATE TABLE "lead_audit_trail_step_logs" ("id" character varying(36) NOT NULL, "sid" character varying(46), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "endpoint" character varying(255) NOT NULL, "step_name" character varying(255) NOT NULL, "timestamp" TIMESTAMP NOT NULL, "ip_address" character varying(45) NOT NULL, "merchant_id" character varying(36) NOT NULL, "lead_sid" character varying(36) NOT NULL, "merchant_sid" character varying(36) NOT NULL, "device_browser" character varying(255) NOT NULL, CONSTRAINT "UQ_f9089765277df096da73e2f5139" UNIQUE ("sid"), CONSTRAINT "PK_911ae950aa7c13f858ce0aad01d" PRIMARY KEY ("id"))`,
        );
        await queryRunner.query(
            `ALTER TABLE "lead_signatures" ADD CONSTRAINT "FK_81194ae20d64d7a741fecb45ec5" FOREIGN KEY ("lead_id") REFERENCES "leads"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
        );

        await queryRunner.query(`ALTER TABLE "lead_signatures" ADD "contract_template_key" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "lead_signatures" ADD "signed_contract_key" character varying(255)`);

        await queryRunner.query(`ALTER TYPE "public"."webhooks_log_event_type_enum" ADD VALUE 'charge.succeeded'`);
        await queryRunner.query(`ALTER TYPE "public"."webhooks_log_event_type_enum" ADD VALUE 'charge.failed'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_signatures" DROP CONSTRAINT "FK_81194ae20d64d7a741fecb45ec5"`);
        await queryRunner.query(`DROP TABLE "lead_audit_trail_step_logs"`);
        await queryRunner.query(`DROP TABLE "lead_signatures"`);
    }
}
