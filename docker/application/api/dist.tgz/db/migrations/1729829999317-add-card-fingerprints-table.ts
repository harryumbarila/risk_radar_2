import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddCardFingerprintsTable1729829999317 implements MigrationInterface {
    name = 'AddCardFingerprintsTable1729829999317';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."card_fingerprints_funding_enum" AS ENUM('credit', 'debit', 'prepaid', 'unknown')`);
        await queryRunner.query(
            `CREATE TABLE "card_fingerprints" ("id" character varying(36) NOT NULL, "sid" character varying(46), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "token" character varying(200) NOT NULL, "fingerprint" character varying(200) NOT NULL, "funding" "public"."card_fingerprints_funding_enum" NOT NULL DEFAULT 'unknown', CONSTRAINT "UQ_a9ed9cbda2f1172b61c72b89aa8" UNIQUE ("sid"), CONSTRAINT "PK_d13a688063101d3da1267c57a75" PRIMARY KEY ("id"))`,
        );
        await queryRunner.query(`CREATE INDEX "IDX_73acf968819206e745c4b409b0" ON "card_fingerprints" ("token") `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."IDX_73acf968819206e745c4b409b0"`);
        await queryRunner.query(`DROP TABLE "card_fingerprints"`);
        await queryRunner.query(`DROP TYPE "public"."card_fingerprints_funding_enum"`);
    }
}
