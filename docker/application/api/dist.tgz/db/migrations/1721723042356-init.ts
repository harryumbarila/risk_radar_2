import { MigrationInterface, QueryRunner } from "typeorm";

export class Init1721723042356 implements MigrationInterface {
    name = 'Init1721723042356'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."leads_onboarding_status_enum" AS ENUM('NOT_STARTED', 'IN_PROGRESS', 'COMPLETED', 'APPROVED')`);
        await queryRunner.query(`CREATE TABLE "leads" ("created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "id" character varying(36) NOT NULL, "sid" character varying(46), "lead_id" integer NOT NULL, "onboarding_status" "public"."leads_onboarding_status_enum" NOT NULL, "data" jsonb NOT NULL, "merchant_id" character varying(36), CONSTRAINT "UQ_126a4ef827272cfbf3bcd1e67aa" UNIQUE ("sid"), CONSTRAINT "REL_1a74afad73b2d293d0ca83484d" UNIQUE ("merchant_id"), CONSTRAINT "PK_cd102ed7a9a4ca7d4d8bfeba406" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "webhooks" ("id" character varying(36) NOT NULL, "sid" character varying(46), "label" character varying NOT NULL, "is_active" boolean NOT NULL, "events" jsonb, "url" character varying NOT NULL, "secret" character varying NOT NULL, "http_headers" jsonb, "account_id" character varying(36), CONSTRAINT "UQ_1103ba2a44abfc2cb85dacad8e3" UNIQUE ("sid"), CONSTRAINT "UQ_5ef8ea47429a31bcf12146974c1" UNIQUE ("label"), CONSTRAINT "PK_9e8795cfc899ab7bdaa831e8527" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "accounts" ("created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "id" character varying(36) NOT NULL, "sid" character varying(46), "name" character varying(255), "email" character varying(320) NOT NULL, "publishable_key" character varying(255) NOT NULL, "secret_key" character varying(255) NOT NULL, "secret_key_created_at" TIMESTAMP NOT NULL DEFAULT now(), "publishable_key_created_at" TIMESTAMP NOT NULL DEFAULT now(), "secret_key_last_used_at" date, "publishable_key_last_used_at" date, CONSTRAINT "UQ_8b374d033b9b42c6a154cf62603" UNIQUE ("sid"), CONSTRAINT "UQ_ee66de6cdc53993296d1ceb8aa0" UNIQUE ("email"), CONSTRAINT "UQ_d6b0027f198be1223c373165680" UNIQUE ("publishable_key"), CONSTRAINT "UQ_614c036881279bc9767352beb65" UNIQUE ("secret_key"), CONSTRAINT "PK_5a7a02c20412299d198e097a8fe" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "merchants" ("created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "id" character varying(36) NOT NULL, "sid" character varying(46), "phone_number" character varying(11) NOT NULL, "agent" integer, "account_id" character varying(36), CONSTRAINT "UQ_848cc9156feb33fbd25b7095acf" UNIQUE ("sid"), CONSTRAINT "PK_4fd312ef25f8e05ad47bfe7ed25" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."webhooks_log_status_enum" AS ENUM('PENDING', 'PROCESSING', 'DELIVERED', 'FAILED')`);
        await queryRunner.query(`CREATE TYPE "public"."webhooks_log_event_type_enum" AS ENUM('lead.created', 'lead.document.uploaded', 'lead.updated', 'lead.status.updated', 'lead.signature.generated', 'lead.signature.signed')`);
        await queryRunner.query(`CREATE TABLE "webhooks_log" ("created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "id" character varying(36) NOT NULL, "sid" character varying(46), "event_sid" character varying(46), "status" "public"."webhooks_log_status_enum" NOT NULL, "target_url" character varying NOT NULL, "event_type" "public"."webhooks_log_event_type_enum" NOT NULL, "object" character varying NOT NULL, "payload" jsonb NOT NULL, "api_version" character varying NOT NULL, "delivered_on" date, "status_code" integer, "response_body" text, "request_id" character varying, "webhook_id" character varying(36) NOT NULL, CONSTRAINT "UQ_13931ac2e164e65df5601c17b32" UNIQUE ("sid"), CONSTRAINT "PK_c082e479beaefccbb3b369d9b0f" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_2933d91095bcf9ec35a8e53d34" ON "webhooks_log" ("event_sid") `);
        await queryRunner.query(`ALTER TABLE "leads" ADD CONSTRAINT "FK_1a74afad73b2d293d0ca83484d5" FOREIGN KEY ("merchant_id") REFERENCES "merchants"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "webhooks" ADD CONSTRAINT "FK_295b5a3ff343825baa12cfdcba0" FOREIGN KEY ("account_id") REFERENCES "accounts"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "merchants" ADD CONSTRAINT "FK_8b8b3f76bbc1f20ee9ed7f82d1d" FOREIGN KEY ("account_id") REFERENCES "accounts"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "webhooks_log" ADD CONSTRAINT "FK_44bd12866c66dc96db8a886b15c" FOREIGN KEY ("webhook_id") REFERENCES "webhooks"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "webhooks_log" DROP CONSTRAINT "FK_44bd12866c66dc96db8a886b15c"`);
        await queryRunner.query(`ALTER TABLE "merchants" DROP CONSTRAINT "FK_8b8b3f76bbc1f20ee9ed7f82d1d"`);
        await queryRunner.query(`ALTER TABLE "webhooks" DROP CONSTRAINT "FK_295b5a3ff343825baa12cfdcba0"`);
        await queryRunner.query(`ALTER TABLE "leads" DROP CONSTRAINT "FK_1a74afad73b2d293d0ca83484d5"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_2933d91095bcf9ec35a8e53d34"`);
        await queryRunner.query(`DROP TABLE "webhooks_log"`);
        await queryRunner.query(`DROP TYPE "public"."webhooks_log_event_type_enum"`);
        await queryRunner.query(`DROP TYPE "public"."webhooks_log_status_enum"`);
        await queryRunner.query(`DROP TABLE "merchants"`);
        await queryRunner.query(`DROP TABLE "accounts"`);
        await queryRunner.query(`DROP TABLE "webhooks"`);
        await queryRunner.query(`DROP TABLE "leads"`);
        await queryRunner.query(`DROP TYPE "public"."leads_onboarding_status_enum"`);
    }

}
