import { MigrationInterface, QueryRunner } from 'typeorm';

export class LeadAuditChanges1735824991426 implements MigrationInterface {
    name = 'LeadAuditChanges1735824991426';

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" ADD "owner_name" text`);
        await queryRunner.query(`
            ALTER TABLE "lead_signatures"
            ALTER COLUMN "signature_email" TYPE character varying(320),
    ALTER COLUMN "signature_email" SET NOT NULL
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "lead_signatures" DROP COLUMN "signature_email"`);
        await queryRunner.query(`ALTER TABLE "lead_signatures" ADD "signature_email" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "lead_audit_trail_step_logs" DROP COLUMN "owner_name"`);
    }
}
