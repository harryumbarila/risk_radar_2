import { DataSource } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { config } from 'dotenv';
import { Merchant } from '@/shared/model/merchant.entity';
import { Lead } from '@/shared/model/lead.entity';
import { Account } from '@/shared/model/account.entity';
import { Webhook } from '@/webhook/webhook.entity';
import { WebhookLog } from '@/webhook/webhook-log.entity';
import { Init1721723042356 } from './db/migrations/1721723042356-init';
import { MerchantChanges1726665092317 } from './db/migrations/1726665092317-merchant-changes';
import { CardFingerprint } from '@/shared/model/card-fingerprint.entity';
import { AddCardFingerprintsTable1729829999317 } from './db/migrations/1729829999317-add-card-fingerprints-table';
import { RemoveUniqueConstraintOnLabel1732778620051 } from './db/migrations/1732778620051-remove-unique-constraint-on-label';
import { LeadAuditTrailStepLog } from '@/shared/model/lead/lead-audit-trail-step-log.entity';
import { LeadSignature } from '@/shared/model/lead/lead-signature.entity';
import { LeadAuditAndSignatures1733922510864 } from './db/migrations/1733922510864-lead-audit-and-signatures';
import { LeadAuditSignatureOwner1734013344339 } from './db/migrations/1734013344339-lead-audit-signature-owner';
import { LeadAuditSignatureNewFields1734429972527 } from './db/migrations/1734429972527-lead-audit-signature-new-fields';
import { LeadAuditChanges1735824991426 } from './db/migrations/1735824991426-lead-audit-changes';
import { LeadAuditAddSignatureId1735933563765 } from './db/migrations/1735933563765-lead-audit-add-signature-id';
import { AddIndexToLeadAuditTrails1736233218359 } from './db/migrations/1736233218359-add-index-to-lead-audit-trails';

config();

const configService = new ConfigService();

export const AppMigrations = [
    Init1721723042356,
    MerchantChanges1726665092317,
    AddCardFingerprintsTable1729829999317,
    RemoveUniqueConstraintOnLabel1732778620051,
    LeadAuditAndSignatures1733922510864,
    LeadAuditSignatureOwner1734013344339,
    LeadAuditSignatureNewFields1734429972527,
    LeadAuditChanges1735824991426,
    LeadAuditAddSignatureId1735933563765,
    AddIndexToLeadAuditTrails1736233218359,
];

export const AppEntities = [Account, Merchant, Lead, Webhook, WebhookLog, CardFingerprint, LeadAuditTrailStepLog, LeadSignature];

export const AppDataSource: DataSource = new DataSource({
    type: 'postgres',
    host: configService.get('DATABASE_HOST'),
    port: configService.get('DATABASE_PORT'),
    username: configService.get('DATABASE_USERNAME'),
    password: configService.get('DATABASE_PASSWORD'),
    database: configService.get('DATABASE_NAME'),
    entities: AppEntities,
    migrations: AppMigrations,
    synchronize: false,
});
